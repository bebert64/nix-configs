create function needs_tpid(arg_id integer) returns boolean
    language plpgsql
as
$$
    DECLARE ret_val boolean:=FALSE;
BEGIN
        SELECT INTO ret_val (
            (has_url_official = true)
                AND (tpid is null)
                AND ((status = 'cut')
                    OR (url_official is not null))
            ) FROM videos WHERE videos.id = arg_id;
        RETURN ret_val;
    END
    $$;

alter function needs_tpid(integer) owner to master;

