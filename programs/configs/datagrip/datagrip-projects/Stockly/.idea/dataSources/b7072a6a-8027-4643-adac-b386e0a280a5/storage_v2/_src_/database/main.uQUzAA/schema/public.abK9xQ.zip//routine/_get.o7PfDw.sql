create function _get(text) returns integer
    strict
    language plpgsql
as
$$
DECLARE
    ret integer;
BEGIN
    EXECUTE 'SELECT value FROM __tcache__ WHERE label = ' || quote_literal($1) || ' LIMIT 1' INTO ret;
    RETURN ret;
END;
$$;

alter function _get(text) owner to rdsadmin;

