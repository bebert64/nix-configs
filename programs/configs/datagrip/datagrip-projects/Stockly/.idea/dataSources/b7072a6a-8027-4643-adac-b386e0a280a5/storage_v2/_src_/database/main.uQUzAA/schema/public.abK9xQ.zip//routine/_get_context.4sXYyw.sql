create function _get_context(name, name) returns "char"
    language sql
as
$$
   SELECT c.castcontext
     FROM pg_catalog.pg_cast c
    WHERE _cmp_types(castsource, $1)
      AND _cmp_types(casttarget, $2)
$$;

alter function _get_context(name, name) owner to rdsadmin;

