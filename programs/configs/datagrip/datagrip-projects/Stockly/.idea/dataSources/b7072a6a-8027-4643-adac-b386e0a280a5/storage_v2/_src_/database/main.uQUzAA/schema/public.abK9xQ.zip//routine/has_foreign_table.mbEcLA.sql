create function has_foreign_table(name, name) returns text
    language sql
as
$$
    SELECT ok(
        _rexists( 'f', $1, $2 ),
        'Foreign table ' || quote_ident($1) || '.' || quote_ident($2) || ' should exist'
    );
$$;

alter function has_foreign_table(name, name) owner to rdsadmin;

