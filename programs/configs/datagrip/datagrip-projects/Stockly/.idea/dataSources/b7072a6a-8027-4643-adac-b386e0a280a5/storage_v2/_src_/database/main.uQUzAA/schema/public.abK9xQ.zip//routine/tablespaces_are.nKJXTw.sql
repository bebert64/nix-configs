create function tablespaces_are(name[]) returns text
    language sql
as
$$
    SELECT tablespaces_are( $1, 'There should be the correct tablespaces' );
$$;

alter function tablespaces_are(name[]) owner to rdsadmin;

