create function _ckeys(name, name, character) returns name[]
    language sql
as
$$
    SELECT * FROM _keys($1, $2, $3) LIMIT 1;
$$;

alter function _ckeys(name, name, char) owner to rdsadmin;

