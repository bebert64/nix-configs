create function no_plan() returns SETOF boolean
    strict
    language plpgsql
as
$$
BEGIN
    PERFORM plan(0);
    RETURN;
END;
$$;

alter function no_plan() owner to rdsadmin;

