create function globally_banned_brands_cache__sync() returns trigger
    language plpgsql
as
$$
BEGIN
	IF NEW.is_banned THEN
		INSERT INTO globally_banned_brands_cache(brand_interned_id)
			VALUES(NEW.brand_interned_id)
			ON CONFLICT DO NOTHING;
	ELSE
		DELETE FROM globally_banned_brands_cache
			WHERE brand_interned_id = NEW.brand_interned_id;
	END IF;
	RETURN NULL;
END;
$$;

alter function globally_banned_brands_cache__sync() owner to master;

