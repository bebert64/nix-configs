create function col_isnt_fk(name, name[], text) returns text
    language sql
as
$$
    SELECT ok( NOT _fkexists( $1, $2 ), $3 );
$$;

alter function col_isnt_fk(name, name[], text) owner to rdsadmin;

