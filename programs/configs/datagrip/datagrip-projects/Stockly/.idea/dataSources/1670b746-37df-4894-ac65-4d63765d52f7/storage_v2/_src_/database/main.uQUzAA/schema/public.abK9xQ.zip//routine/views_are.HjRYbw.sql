create function views_are(name[], text) returns text
    language sql
as
$$
    SELECT _are( 'views', _extras('v', $1), _missing('v', $1), $2);
$$;

alter function views_are(name[], text) owner to rdsadmin;

