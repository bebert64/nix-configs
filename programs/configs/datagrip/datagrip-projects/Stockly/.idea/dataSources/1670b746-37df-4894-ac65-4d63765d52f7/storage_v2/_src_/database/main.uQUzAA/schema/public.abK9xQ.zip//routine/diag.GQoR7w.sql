create function diag(VARIADIC text[]) returns text
    language sql
as
$$
    SELECT diag(array_to_string($1, ''));
$$;

alter function diag(text[]) owner to rdsadmin;

