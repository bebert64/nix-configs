create function col_hasnt_default(name, name) returns text
    language sql
as
$$
    SELECT col_hasnt_default( $1, $2, 'Column ' || quote_ident($1) || '.' || quote_ident($2) || ' should not have a default' );
$$;

alter function col_hasnt_default(name, name) owner to rdsadmin;

