create function has_index(name, name, name, name, text) returns text
    language sql
as
$$
    SELECT has_index( $1, $2, $3, ARRAY[$4], $5 );
$$;

alter function has_index(name, name, name, name, text) owner to rdsadmin;

