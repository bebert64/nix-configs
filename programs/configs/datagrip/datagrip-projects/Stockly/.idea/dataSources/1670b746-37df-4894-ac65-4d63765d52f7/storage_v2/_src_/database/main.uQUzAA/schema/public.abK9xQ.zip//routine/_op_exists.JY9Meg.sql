create function _op_exists(name, name, name, name, name) returns boolean
    language sql
as
$$
    SELECT EXISTS (
       SELECT TRUE
         FROM pg_catalog.pg_operator o
         JOIN pg_catalog.pg_namespace n ON o.oprnamespace = n.oid
        WHERE n.nspname = $2
          AND o.oprname = $3
          AND CASE o.oprkind WHEN 'l' THEN $1 IS NULL
              ELSE _cmp_types(o.oprleft, _typename($1)) END
          AND CASE o.oprkind WHEN 'r' THEN $4 IS NULL
              ELSE _cmp_types(o.oprright, _typename($4)) END
          AND _cmp_types(o.oprresult, $5)
   );
$$;

alter function _op_exists(name, name, name, name, name) owner to rdsadmin;

