create function users_are(name[]) returns text
    language sql
as
$$
    SELECT users_are( $1, 'There should be the correct users' );
$$;

alter function users_are(name[]) owner to rdsadmin;

