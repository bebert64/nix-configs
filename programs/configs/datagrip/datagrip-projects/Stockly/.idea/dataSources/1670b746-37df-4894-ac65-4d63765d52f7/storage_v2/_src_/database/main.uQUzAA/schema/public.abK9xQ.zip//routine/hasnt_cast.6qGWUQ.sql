create function hasnt_cast(name, name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _cast_exists( $1, $2 ), $3 );
$$;

alter function hasnt_cast(name, name, text) owner to rdsadmin;

