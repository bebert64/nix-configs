create function _is_super(name) returns boolean
    strict
    language sql
as
$$
    SELECT rolsuper
      FROM pg_catalog.pg_roles
     WHERE rolname = $1
$$;

alter function _is_super(name) owner to rdsadmin;

