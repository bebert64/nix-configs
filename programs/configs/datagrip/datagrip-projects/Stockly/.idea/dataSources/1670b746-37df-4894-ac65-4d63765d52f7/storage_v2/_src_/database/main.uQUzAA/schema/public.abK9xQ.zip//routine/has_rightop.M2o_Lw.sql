create function has_rightop(name, name) returns text
    language sql
as
$$
    SELECT ok(
         _op_exists($1, $2, NULL ),
        'Right operator ' || $2 || '(' || $1 || ',NONE) should exist'
    );
$$;

alter function has_rightop(name, name) owner to rdsadmin;

