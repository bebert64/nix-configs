create function hasnt_enum(name, name) returns text
    language sql
as
$$
    SELECT hasnt_enum( $1, $2, 'Enum ' || quote_ident($1) || '.' || quote_ident($2) || ' should not exist' );
$$;

alter function hasnt_enum(name, name) owner to rdsadmin;

