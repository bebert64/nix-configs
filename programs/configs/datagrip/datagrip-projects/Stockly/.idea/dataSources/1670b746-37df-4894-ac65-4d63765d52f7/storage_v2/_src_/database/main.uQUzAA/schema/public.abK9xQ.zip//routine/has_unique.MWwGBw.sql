create function has_unique(text, text) returns text
    language sql
as
$$
    SELECT ok( _hasc( $1, 'u' ), $2 );
$$;

alter function has_unique(text, text) owner to rdsadmin;

