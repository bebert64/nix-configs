create function tables_are(name[]) returns text
    language sql
as
$$
    SELECT _are(
        'tables', _extras('{r,p}'::char[], $1), _missing('{r,p}'::char[], $1),
        'Search path ' || pg_catalog.current_setting('search_path') || ' should have the correct tables'
    );
$$;

alter function tables_are(name[]) owner to rdsadmin;

