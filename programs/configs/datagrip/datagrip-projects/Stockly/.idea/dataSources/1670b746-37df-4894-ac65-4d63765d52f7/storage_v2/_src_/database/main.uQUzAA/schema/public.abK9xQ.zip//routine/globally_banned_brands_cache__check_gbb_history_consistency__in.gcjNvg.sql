create function globally_banned_brands_cache__check_gbb_history_consistency__in() returns trigger
    language plpgsql
as
$$
BEGIN
	PERFORM globally_banned_brands_cache__check_gbb_history_consistency(NEW.brand_interned_id, TRUE);
	RETURN NEW;
END;
$$;

alter function globally_banned_brands_cache__check_gbb_history_consistency__in() owner to master;

