create function todo(why text, how_many integer) returns SETOF boolean
    language plpgsql
as
$$
BEGIN
    PERFORM _add('todo', COALESCE(how_many, 1), COALESCE(why, ''));
    RETURN;
END;
$$;

alter function todo(text, integer) owner to rdsadmin;

