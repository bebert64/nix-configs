create function item_matching_keys__set_item_updated_at() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE items SET updated_at = NOW() WHERE id = COALESCE(NEW.item_id, OLD.item_id) AND updated_at <> NOW();
    RETURN NULL;
END;
$$;

alter function item_matching_keys__set_item_updated_at() owner to master;

