create function indexes_are(name, name[]) returns text
    language sql
as
$$
    SELECT indexes_are( $1, $2, 'Table ' || quote_ident($1) || ' should have the correct indexes' );
$$;

alter function indexes_are(name, name[]) owner to rdsadmin;

