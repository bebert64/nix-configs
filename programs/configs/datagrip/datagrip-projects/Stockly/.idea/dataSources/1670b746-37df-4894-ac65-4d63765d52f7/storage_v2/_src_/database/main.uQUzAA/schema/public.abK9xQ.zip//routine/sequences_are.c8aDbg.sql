create function sequences_are(name[]) returns text
    language sql
as
$$
    SELECT _are(
        'sequences', _extras('S', $1), _missing('S', $1),
        'Search path ' || pg_catalog.current_setting('search_path') || ' should have the correct sequences'
    );
$$;

alter function sequences_are(name[]) owner to rdsadmin;

