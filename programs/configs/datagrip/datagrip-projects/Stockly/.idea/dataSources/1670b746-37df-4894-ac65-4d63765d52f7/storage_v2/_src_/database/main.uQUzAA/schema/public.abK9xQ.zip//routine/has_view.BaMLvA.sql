create function has_view(name, name) returns text
    language sql
as
$$
    SELECT has_view (
        $1, $2,
        'View ' || quote_ident($1) || '.' || quote_ident($2) || ' should exist'
    );
$$;

alter function has_view(name, name) owner to rdsadmin;

