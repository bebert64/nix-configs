create function has_tablespace(name) returns text
    language sql
as
$$
    SELECT has_tablespace( $1, 'Tablespace ' || quote_ident($1) || ' should exist' );
$$;

alter function has_tablespace(name) owner to rdsadmin;

