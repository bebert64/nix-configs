create function has_user(name, text) returns text
    language sql
as
$$
    SELECT ok( _has_user($1), $2 );
$$;

alter function has_user(name, text) owner to rdsadmin;

