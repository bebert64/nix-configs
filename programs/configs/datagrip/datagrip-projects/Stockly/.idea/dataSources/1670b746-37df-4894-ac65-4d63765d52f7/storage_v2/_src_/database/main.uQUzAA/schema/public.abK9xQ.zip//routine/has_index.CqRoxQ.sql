create function has_index(name, name, name, name[]) returns text
    language sql
as
$$
   SELECT has_index( $1, $2, $3, $4, 'Index ' || quote_ident($3) || ' should exist' );
$$;

alter function has_index(name, name, name, name[]) owner to rdsadmin;

