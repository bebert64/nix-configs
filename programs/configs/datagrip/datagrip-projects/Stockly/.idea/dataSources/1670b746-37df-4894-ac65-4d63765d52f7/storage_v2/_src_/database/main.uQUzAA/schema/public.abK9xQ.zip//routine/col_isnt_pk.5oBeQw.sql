create function col_isnt_pk(name, name, name[], text) returns text
    language sql
as
$$
    SELECT isnt( _ckeys( $1, $2, 'p' ), $3, $4 );
$$;

alter function col_isnt_pk(name, name, name[], text) owner to rdsadmin;

