create function hasnt_group(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _has_group($1), $2 );
$$;

alter function hasnt_group(name, text) owner to rdsadmin;

