create function globally_banned_brands_cache__check_gbb_history_consistency(affected_brand_interned_id integer, is_banned_in_cache boolean) returns void
    language plpgsql
as
$$
DECLARE
	is_banned_in_history BOOLEAN;
BEGIN
	SELECT is_banned INTO is_banned_in_history
	FROM globally_banned_brands_history
	WHERE brand_interned_id = affected_brand_interned_id
		ORDER BY created_at DESC
		LIMIT 1;

	IF is_banned_in_cache AND (is_banned_in_history IS NULL OR NOT is_banned_in_history) THEN
		RAISE EXCEPTION
			'New entry (interned id %) in `globally_banned_brands_cache`, but there is no corresponding record in `globally_banned_brands_history`. The `globally_banned_brands_cache` table should not be updated directly.',
			affected_brand_interned_id;
	ELSIF NOT is_banned_in_cache AND (is_banned_in_history IS NOT NULL AND is_banned_in_history) THEN
		RAISE EXCEPTION
			'An entry (interned id %) in `globally_banned_brands_cache` is being deleted, but there is no corresponding record in `globally_banned_brands_history`. The `globally_banned_brands_cache` table should not be updated directly.',
			affected_brand_interned_id;
	END IF;
END;
$$;

alter function globally_banned_brands_cache__check_gbb_history_consistency(integer, boolean) owner to master;

