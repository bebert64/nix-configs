create function can(name[]) returns text
    language sql
as
$$
    SELECT can( $1, 'Schema ' || _ident_array_to_string(current_schemas(true), ' or ') || ' can' );
$$;

alter function can(name[]) owner to rdsadmin;

