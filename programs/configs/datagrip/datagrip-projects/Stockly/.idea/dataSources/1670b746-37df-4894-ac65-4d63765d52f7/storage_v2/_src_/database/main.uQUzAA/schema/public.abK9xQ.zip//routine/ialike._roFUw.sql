create function ialike(anyelement, text, text) returns text
    language sql
as
$$
    SELECT _alike( $1 ~~* $2, $1, $2, $3 );
$$;

alter function ialike(anyelement, text, text) owner to rdsadmin;

