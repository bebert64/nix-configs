create function has_function(name) returns text
    language sql
as
$$
    SELECT ok( _got_func($1), 'Function ' || quote_ident($1) || '() should exist' );
$$;

alter function has_function(name) owner to rdsadmin;

