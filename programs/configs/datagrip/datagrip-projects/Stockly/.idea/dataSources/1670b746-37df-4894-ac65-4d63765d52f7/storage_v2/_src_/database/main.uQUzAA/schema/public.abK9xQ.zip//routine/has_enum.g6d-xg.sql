create function has_enum(name, text) returns text
    language sql
as
$$
    SELECT ok( _has_type( $1, ARRAY['e'] ), $2 );
$$;

alter function has_enum(name, text) owner to rdsadmin;

