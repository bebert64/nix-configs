create function items_set_updated_at() returns trigger
    language plpgsql
as
$$
BEGIN
	-- ignore these fields in the following diff
	OLD.refreshed_at := NEW.refreshed_at;
	OLD.item_characteristics_input_hash := NEW.item_characteristics_input_hash;
	OLD.item_unused_characteristics_input_hash := NEW.item_unused_characteristics_input_hash;
	IF (
		NEW IS DISTINCT FROM OLD AND
		NEW.updated_at IS NOT DISTINCT FROM OLD.updated_at
	) THEN
		NEW.updated_at := current_timestamp;
	END IF;
	RETURN NEW;
END;
$$;

alter function items_set_updated_at() owner to master;

