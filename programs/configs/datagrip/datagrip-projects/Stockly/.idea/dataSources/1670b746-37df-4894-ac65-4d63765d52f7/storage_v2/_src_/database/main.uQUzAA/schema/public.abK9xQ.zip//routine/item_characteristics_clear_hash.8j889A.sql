create function item_characteristics_clear_hash() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (
		NEW IS DISTINCT FROM OLD
	) THEN
		UPDATE items SET item_characteristics_input_hash = NULL WHERE id = NEW.item_id AND item_characteristics_input_hash IS NOT NULL;
	END IF;
	RETURN NULL;
END;
$$;

alter function item_characteristics_clear_hash() owner to master;

