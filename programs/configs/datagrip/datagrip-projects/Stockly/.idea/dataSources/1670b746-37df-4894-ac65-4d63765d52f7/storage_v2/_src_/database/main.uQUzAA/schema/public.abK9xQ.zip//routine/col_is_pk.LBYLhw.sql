create function col_is_pk(name, name, name[], text) returns text
    language sql
as
$$
    SELECT is( _ckeys( $1, $2, 'p' ), $3, $4 );
$$;

alter function col_is_pk(name, name, name[], text) owner to rdsadmin;

