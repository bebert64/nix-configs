create function hasnt_composite(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _rexists( 'c', $1 ), $2 );
$$;

alter function hasnt_composite(name, text) owner to rdsadmin;

