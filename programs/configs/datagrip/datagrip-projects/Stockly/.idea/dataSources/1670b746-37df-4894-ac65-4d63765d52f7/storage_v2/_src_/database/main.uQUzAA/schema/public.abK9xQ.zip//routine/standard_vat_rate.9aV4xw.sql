create function standard_vat_rate(country_alpha3 text, date_dt timestamp with time zone DEFAULT now()) returns double precision
    immutable
    parallel safe
    language plpgsql
as
$$
BEGIN
    IF country_alpha3 IS NULL OR date_dt IS NULL THEN
        RAISE null_value_not_allowed;
    END IF;
    CASE country_alpha3
    WHEN 'AUT' THEN
        RETURN 0.2;
    WHEN 'BEL' THEN
        RETURN 0.21;
    WHEN 'BGR' THEN
        RETURN 0.2;
    WHEN 'CHE' THEN
        IF date_part('year', date_dt) >= 2024 THEN
                RETURN 0.081;
            ELSE
                RETURN 0.077;
        END IF;
    WHEN 'CYP' THEN
        RETURN 0.19;
    WHEN 'CZE' THEN
        RETURN 0.21;
    WHEN 'DEU' THEN
        RETURN 0.19;
    WHEN 'DNK' THEN
        RETURN 0.25;
    WHEN 'ESP' THEN
        RETURN 0.21;
    WHEN 'EST' THEN
        IF date_part('year', date_dt) >= 2024 THEN
            RETURN 0.22;
        ELSE
            RETURN 0.2;
        END IF;
    WHEN 'FIN' THEN
        IF date_part('year', date_dt) >= 2025 THEN
            RETURN 0.255;
        ELSE
            RETURN 0.24;
        END IF;
    WHEN 'FRA' THEN
        RETURN 0.2;
    WHEN 'GBR' THEN
        RETURN 0.2;
    WHEN 'GRC' THEN
        RETURN 0.24;
    -- No VAT in Hong-Kong
    WHEN 'HKG' THEN
        RETURN 0;
    WHEN 'HRV' THEN
        RETURN 0.25;
    WHEN 'HUN' THEN
        RETURN 0.27;
    WHEN 'IRL' THEN
        RETURN 0.23;
    WHEN 'ISL' THEN
        RETURN 0.24;
    WHEN 'ITA' THEN
        RETURN 0.22;
    WHEN 'LTU' THEN
        RETURN 0.21;
    WHEN 'LUX' THEN
        IF date_part('year', date_dt) = 2023 THEN
            RETURN 0.16;
        ELSE
            RETURN 0.17;
        END IF;
    WHEN 'LVA' THEN
        RETURN 0.21;
    WHEN 'MCO' THEN
        RETURN 0.20;
    WHEN 'MLT' THEN
        RETURN 0.18;
    WHEN 'NLD' THEN
        RETURN 0.21;
    WHEN 'NOR' THEN
        RETURN 0.25;
    WHEN 'POL' THEN
        RETURN 0.23;
    WHEN 'PRT' THEN
        RETURN 0.23;
    WHEN 'ROU' THEN
        RETURN 0.19;
    WHEN 'SVK' THEN
        IF date_part('year', date_dt) >= 2025 THEN
            RETURN 0.23;
        ELSE
            RETURN 0.2;
        END IF;
    WHEN 'SVN' THEN
        RETURN 0.22;
    WHEN 'SWE' THEN
        RETURN 0.25;
    -- The VAT is different in each state of the USA, and so this country will never be supported. As such,
    -- we don't want to encourage users to create a ticket asking for it.
    WHEN 'USA' THEN
        RAISE 'USA is not supported, as the VAT can vary from one state to the other.';
    ELSE
        RAISE 'Country - % is missing. You can create a Notion ticket to ask for it to be added.', country_alpha3;
    END CASE;
END;
$$;

alter function standard_vat_rate(text, timestamp with time zone) owner to master;

