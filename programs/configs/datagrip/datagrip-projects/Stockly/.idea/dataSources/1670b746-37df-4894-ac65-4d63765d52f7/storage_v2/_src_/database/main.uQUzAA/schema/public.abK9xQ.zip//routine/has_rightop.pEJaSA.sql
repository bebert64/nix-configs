create function has_rightop(name, name, name, name, text) returns text
    language sql
as
$$
    SELECT ok( _op_exists( $1, $2, $3, NULL, $4), $5 );
$$;

alter function has_rightop(name, name, name, name, text) owner to rdsadmin;

