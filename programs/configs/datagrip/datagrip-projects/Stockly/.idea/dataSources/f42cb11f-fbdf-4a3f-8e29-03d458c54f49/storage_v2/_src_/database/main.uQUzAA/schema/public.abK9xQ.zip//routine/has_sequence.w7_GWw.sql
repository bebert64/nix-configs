create function has_sequence(name, text) returns text
    language sql
as
$$
    SELECT ok( _rexists( 'S', $1 ), $2 );
$$;

alter function has_sequence(name, text) owner to rdsadmin;

