create function smpb__message_id_not_present_on_purchase_submission() returns trigger
    language plpgsql
as
$$
BEGIN
	IF non_unique_message_id_on_purchase_and_purchase_submission (NEW.supplier_message_id, NULL) THEN
		RAISE 'Message id (%) is already bound to a purchase submission', NEW.supplier_message_id
		USING ERRCODE = 'unique_violation', CONSTRAINT = 'smpb__message_id_not_present_on_purchase_submission', TABLE = 'supplier_message_purchases_bindings';
	END IF;
		RETURN NULL;
END
$$;

alter function smpb__message_id_not_present_on_purchase_submission() owner to master;

