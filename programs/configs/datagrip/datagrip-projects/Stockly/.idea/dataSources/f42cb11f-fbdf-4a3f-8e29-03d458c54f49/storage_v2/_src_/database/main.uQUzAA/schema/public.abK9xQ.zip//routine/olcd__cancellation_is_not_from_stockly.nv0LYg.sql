create function olcd__cancellation_is_not_from_stockly(arg_order_line_cancellation_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT * FROM "order_line_cancellations" olc
		WHERE
			olc.id = arg_order_line_cancellation_id
			AND NOT olc.from_stockly
	);

	RETURN ret_val;
END
$$;

alter function olcd__cancellation_is_not_from_stockly(integer) owner to master;

