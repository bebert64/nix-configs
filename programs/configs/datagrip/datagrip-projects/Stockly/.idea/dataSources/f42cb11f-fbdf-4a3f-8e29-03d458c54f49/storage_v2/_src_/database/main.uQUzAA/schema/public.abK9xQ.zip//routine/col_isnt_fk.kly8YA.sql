create function col_isnt_fk(name, name, name, text) returns text
    language sql
as
$$
    SELECT col_isnt_fk( $1, $2, ARRAY[$3], $4 );
$$;

alter function col_isnt_fk(name, name, name, text) owner to rdsadmin;

