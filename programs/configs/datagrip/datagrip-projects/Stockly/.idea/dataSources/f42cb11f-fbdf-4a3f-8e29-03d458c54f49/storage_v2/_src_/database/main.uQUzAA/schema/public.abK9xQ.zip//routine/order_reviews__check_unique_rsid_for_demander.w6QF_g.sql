create function order_reviews__check_unique_rsid_for_demander() returns trigger
    language plpgsql
as
$$
DECLARE
   check_failed boolean := FALSE;
BEGIN
   SELECT
      INTO check_failed EXISTS (
         SELECT
            *
         FROM
            "order_reviews" old_or
            INNER JOIN "orders" old_o ON old_or.order_id = old_o.id
            INNER JOIN "demander_persons" old_dp ON old_o.owner_id = old_dp.id
            INNER JOIN "orders" new_o ON NEW.order_id = new_o.id
            INNER JOIN "demander_persons" new_dp ON new_o.owner_id = new_dp.id
         WHERE
            old_or.id != NEW.id
            AND old_dp.demander_id = new_dp.demander_id
            AND old_or.retailer_specific_id = NEW.retailer_specific_id);
   IF check_failed THEN
      RAISE 'Order review RSID (%) already exists for demander linked to order_id (%)', NEW.retailer_specific_id, NEW.order_id
      USING ERRCODE = 'unique_violation', CONSTRAINT = 'order_reviews__check_unique_rsid_for_demander', TABLE = 'order_reviews';
   END IF;
      RETURN NULL;
END
$$;

alter function order_reviews__check_unique_rsid_for_demander() owner to master;

