create function has_tablespace(name, text) returns text
    language sql
as
$$
    SELECT ok(
        EXISTS(
            SELECT true
              FROM pg_catalog.pg_tablespace
             WHERE spcname = $1
        ), $2
    );
$$;

alter function has_tablespace(name, text) owner to rdsadmin;

