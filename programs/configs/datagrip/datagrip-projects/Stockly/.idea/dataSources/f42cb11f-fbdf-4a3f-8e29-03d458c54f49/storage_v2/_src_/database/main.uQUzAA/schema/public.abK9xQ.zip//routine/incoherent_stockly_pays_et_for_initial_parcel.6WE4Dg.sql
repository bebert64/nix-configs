create function incoherent_stockly_pays_et_for_initial_parcel(arg_parcel_id integer, arg_purchase_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val Boolean := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT
			1
		FROM
			parcels p
			INNER JOIN
			(
				SELECT DISTINCT ON(pi.purchase_id) parcel_id
				FROM parcel_items pi
				WHERE (
					(pi.purchase_id = arg_purchase_id OR arg_purchase_id IS NULL)
					AND
					pi.flagged_as_erroneous_at IS NULL
				)
				ORDER BY pi.purchase_id, pi.created_at, pi.id
			) first_pis_for_purchase
			ON
			p.id = first_pis_for_purchase.parcel_id
		WHERE (
			(p.id = arg_parcel_id OR arg_parcel_id IS NULL)
			AND
			p.stockly_pays_et != 0
		)
	);
	RETURN ret_val;
END
$$;

alter function incoherent_stockly_pays_et_for_initial_parcel(integer, integer) owner to master;

