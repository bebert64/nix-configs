create function ensure_no_bound_invoice__delete() returns trigger
    language plpgsql
as
$$
BEGIN
	IF OLD.invoice_id IS NOT NULL
		OR OLD.demander_commission_invoice_id IS NOT NULL
	THEN
		RAISE EXCEPTION 'You can''t delete a refund that has been bound to an invoice because it wouldn''t be rebound on its own afterwards. Unbind first, delete, re-import, and be sure to rebind manually afterwards. Refund Id: %', OLD.id;
	END IF;
	RETURN OLD;
END;
$$;

alter function ensure_no_bound_invoice__delete() owner to master;

