create function order_shippings__check_unique_rsid_for_order() returns trigger
    language plpgsql
as
$$
BEGIN
	IF order_shippings__retailer_specific_id__already_exists (NEW.retailer_specific_id) THEN
		RAISE 'order_shipping RSID (%) already exists for demander linked to order_id (%)', NEW.retailer_specific_id, NEW.order_id
		USING ERRCODE = 'unique_violation', CONSTRAINT = 'order_shippings__check_unique_rsid_for_order', TABLE = 'order_shippings';
	END IF;
		RETURN NULL;
END
$$;

alter function order_shippings__check_unique_rsid_for_order() owner to master;

