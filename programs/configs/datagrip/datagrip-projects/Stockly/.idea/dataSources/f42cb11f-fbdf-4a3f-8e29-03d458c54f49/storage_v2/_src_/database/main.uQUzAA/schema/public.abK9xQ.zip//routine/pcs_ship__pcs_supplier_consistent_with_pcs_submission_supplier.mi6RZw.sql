create function pcs_ship__pcs_supplier_consistent_with_pcs_submission_supplier() returns trigger
    language plpgsql
as
$$
BEGIN
	IF purchases__supplier_inconsistent_with_pcs_submission (NULL, NEW.id, NEW.submission_id) THEN
		RAISE EXCEPTION 'pcs_ship__pcs_supplier_consistent_with_pcs_submission_supplier';
	END IF;
	RETURN NULL;
END
$$;

alter function pcs_ship__pcs_supplier_consistent_with_pcs_submission_supplier() owner to master;

