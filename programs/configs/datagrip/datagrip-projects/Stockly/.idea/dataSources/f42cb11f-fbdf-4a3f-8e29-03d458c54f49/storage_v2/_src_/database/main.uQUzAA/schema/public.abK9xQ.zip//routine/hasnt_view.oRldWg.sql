create function hasnt_view(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _rexists( 'v', $1 ), $2 );
$$;

alter function hasnt_view(name, text) owner to rdsadmin;

