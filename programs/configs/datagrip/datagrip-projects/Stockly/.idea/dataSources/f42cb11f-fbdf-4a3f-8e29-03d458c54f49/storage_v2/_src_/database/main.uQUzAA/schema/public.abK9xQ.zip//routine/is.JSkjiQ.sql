create function is(anyelement, anyelement) returns text
    language sql
as
$$
    SELECT is( $1, $2, NULL);
$$;

alter function is(anyelement, anyelement) owner to rdsadmin;

