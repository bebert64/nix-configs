create function hasnt_table(name, name) returns text
    language sql
as
$$
    SELECT ok(
        NOT _rexists( '{r,p}'::char[], $1, $2 ),
        'Table ' || quote_ident($1) || '.' || quote_ident($2) || ' should not exist'
    );
$$;

alter function hasnt_table(name, name) owner to rdsadmin;

