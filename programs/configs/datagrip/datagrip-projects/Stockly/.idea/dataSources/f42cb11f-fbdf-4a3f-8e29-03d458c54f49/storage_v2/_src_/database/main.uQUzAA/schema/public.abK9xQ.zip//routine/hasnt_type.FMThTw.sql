create function hasnt_type(name, name) returns text
    language sql
as
$$
    SELECT hasnt_type( $1, $2, 'Type ' || quote_ident($1) || '.' || quote_ident($2) || ' should not exist' );
$$;

alter function hasnt_type(name, name) owner to rdsadmin;

