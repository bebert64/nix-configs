create function messages__retailer_specific_id__already_exists(arg_retailer_specific_id character varying) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val boolean := FALSE;
BEGIN
	SELECT
		INTO ret_val EXISTS (
			SELECT
				COUNT(*) AS count
			FROM
				"order_messages" om
				INNER JOIN "orders" o ON o.id = om.order_id
				INNER JOIN "demander_persons" dp ON dp.id = o.owner_id
			WHERE (om.retailer_specific_id = arg_retailer_specific_id
				OR arg_retailer_specific_id IS NULL)
		GROUP BY
			om.retailer_specific_id,
			dp.demander_id
		HAVING
			COUNT(*) > 1);
	RETURN ret_val;
END
$$;

alter function messages__retailer_specific_id__already_exists(varchar) owner to master;

