create function parcels__repackage_group_parcel_without_from_address() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NEW.from_address_id IS NULL)
	THEN
		ASSERT NOT repackage_group_parcel_without_from_address(NEW.id);
	END IF;
	RETURN NULL;
END
$$;

alter function parcels__repackage_group_parcel_without_from_address() owner to master;

