create function exists_incoherent_order_line_refund(arg_order_line_id integer, arg_order_line_refund_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val boolean := FALSE;
BEGIN
	SELECT
		INTO ret_val EXISTS (
			SELECT
				*
			FROM
				"order_lines" ol
				LEFT JOIN "order_line_cancellations" olc ON ol.cancellation_id = olc.id
				LEFT JOIN "order_line_cancellation_decisions" olcd ON olc.decision_id = olcd.id
				LEFT JOIN "order_line_refunds" olr ON ol.id = olr.order_line_id
		WHERE
			olr.reason = 'cancellation'
			AND NOT (olc.stockly_reason IS NOT NULL
				OR (olcd.id IS NOT NULL
					AND olcd.refused_reason IS NULL))
			AND ("arg_order_line_id" IS NULL
				OR "arg_order_line_id" = ol.id)
			AND ("arg_order_line_refund_id" IS NULL
				OR "arg_order_line_refund_id" = olr.id));
	RETURN ret_val;
END
$$;

alter function exists_incoherent_order_line_refund(integer, integer) owner to master;

