create function parcel_items__stockly_pays_et_for_initial_parcel_insert_check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF incoherent_stockly_pays_et_for_initial_parcel(NEW.parcel_id, NEW.purchase_id) THEN
		RAISE 'inserting parcel_item_id = % causes parcel_id = % to become initial for purchase_id = %, but it has stockly_pays_et != 0', NEW.id, NEW.parcel_id, NEW.purchase_id
		USING
			ERRCODE = 'check_violation',
			TABLE = 'parcel_items';
	END IF;
	RETURN NULL;
END
$$;

alter function parcel_items__stockly_pays_et_for_initial_parcel_insert_check() owner to master;

