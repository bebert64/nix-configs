create function _set(text, integer) returns integer
    language sql
as
$$
    SELECT _set($1, $2, '')
$$;

alter function _set(text, integer) owner to rdsadmin;

