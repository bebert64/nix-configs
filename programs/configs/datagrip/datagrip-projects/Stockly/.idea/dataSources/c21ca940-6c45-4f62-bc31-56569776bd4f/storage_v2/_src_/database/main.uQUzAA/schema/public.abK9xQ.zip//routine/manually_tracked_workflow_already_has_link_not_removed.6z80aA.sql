create function manually_tracked_workflow_already_has_link_not_removed(arg_id integer, arg_manually_tracked_workflow_id integer, arg_url text, arg_notion_id uuid, arg_order_line_id integer, arg_purchase_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT * FROM "public"."manually_tracked_workflow_links"
		WHERE
			"id" != arg_id
			AND "manually_tracked_workflow_id" = arg_manually_tracked_workflow_id
			AND "url" = arg_url
			AND "notion_id" = arg_notion_id
			AND "order_line_id" = arg_order_line_id
			AND "purchase_id" = arg_purchase_id
			AND "removed_at" IS NULL
	);

	RETURN ret_val;
END
$$;

alter function manually_tracked_workflow_already_has_link_not_removed(integer, integer, text, uuid, integer, integer) owner to master;

