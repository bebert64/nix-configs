create function diag(VARIADIC anyarray) returns text
    language sql
as
$$
    SELECT diag(array_to_string($1, ''));
$$;

alter function diag(anyarray) owner to rdsadmin;

