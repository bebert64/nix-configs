create function has_type(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _has_type( $1, $2, NULL ), $3 );
$$;

alter function has_type(name, name, text) owner to rdsadmin;

