create function mtw_purchases__not_workflow_already_has_purchase_not_removed() returns trigger
    language plpgsql
as
$$
BEGIN
	IF
		NEW.removed_at IS NULL
		AND manually_tracked_workflow_already_has_purchase_not_removed(NEW.id, NEW.manually_tracked_workflow_id, NEW.purchase_id)
	THEN
		RAISE 'ManuallyTrackedWorkflow (%) already has purchase (%)', NEW.manually_tracked_workflow_id, NEW.purchase_id
		USING ERRCODE = 'integrity_constraint_violation',
		CONSTRAINT = 'not_manually_tracked_workflow_already_has_purchase_not_removed',
		TABLE = 'manually_tracked_workflow_purchases';
	END IF;

	RETURN NULL;
END
$$;

alter function mtw_purchases__not_workflow_already_has_purchase_not_removed() owner to master;

