create function thread_is_not_empty(arg_thread_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT * FROM comments_threads threads
			INNER JOIN comments ON threads.id = comments.thread_id
	);

	RETURN ret_val;
END
$$;

alter function thread_is_not_empty(integer) owner to master;

