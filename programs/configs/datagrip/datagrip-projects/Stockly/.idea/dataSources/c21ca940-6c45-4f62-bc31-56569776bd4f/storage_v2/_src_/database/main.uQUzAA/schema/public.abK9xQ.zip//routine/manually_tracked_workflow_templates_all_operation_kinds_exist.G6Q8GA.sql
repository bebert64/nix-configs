create procedure manually_tracked_workflow_templates_all_operation_kinds_exist()
    language plpgsql
as
$$
	DECLARE operations_name_enum record;
	DECLARE operations_name_exists BOOLEAN;
BEGIN
	FOR operations_name_enum IN SELECT * FROM unnest(enum_range(NULL::operations_name)) AS t(name) LOOP
		SELECT INTO operations_name_exists EXISTS(
			SELECT * FROM manually_tracked_workflow_templates AS mtwt
			WHERE
				mtwt.operations_name = operations_name_enum.name AND
				removed_at IS NULL
		);

		IF NOT operations_name_exists THEN
			RAISE 'operations_name (%) has no template', operations_name_enum.name USING
				ERRCODE = 'integrity_constraint_violation',
				CONSTRAINT = 'not_operations_name_exists2',
				TABLE = 'manually_tracked_workflow_templates';
		END IF;
	END LOOP;
END $$;

alter procedure manually_tracked_workflow_templates_all_operation_kinds_exist() owner to master;

