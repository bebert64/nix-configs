create function _pg_sv_type_array(oid[]) returns name[]
    stable
    language sql
as
$$
    SELECT ARRAY(
        SELECT t.typname
          FROM pg_catalog.pg_type t
          JOIN generate_series(1, array_upper($1, 1)) s(i) ON t.oid = $1[i]
         ORDER BY i
    )
$$;

alter function _pg_sv_type_array(oid[]) owner to rdsadmin;

