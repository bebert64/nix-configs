create function hasnt_trigger(name, name, name) returns text
    language sql
as
$$
    SELECT ok(
        NOT _trig($1, $2, $3),
        'Table ' || quote_ident($1) || '.' || quote_ident($2) || ' should not have trigger ' || quote_ident($3)
    );
$$;

alter function hasnt_trigger(name, name, name) owner to rdsadmin;

