create function manually_tracked_workflow_already_has_purchase_not_removed(arg_id integer, arg_manually_tracked_workflow_id integer, arg_purchase_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT * FROM "public"."manually_tracked_workflow_purchases"
		WHERE
			"id" != arg_id
			AND "manually_tracked_workflow_id" = arg_manually_tracked_workflow_id
			AND "purchase_id" = arg_purchase_id
			AND "removed_at" IS NULL
	);

	RETURN ret_val;
END
$$;

alter function manually_tracked_workflow_already_has_purchase_not_removed(integer, integer, integer) owner to master;

