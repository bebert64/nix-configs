create function row_eq(text, anyelement) returns text
    language sql
as
$$
    SELECT row_eq($1, $2, NULL );
$$;

alter function row_eq(text, anyelement) owner to rdsadmin;

