create function entity_snippet_already_exists(arg_snippet_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT
			*
		FROM
			snippets s1
			INNER JOIN entities_snippets es1 ON es1.snippet_id = s1.id
			INNER JOIN snippets s2 ON (s2.id != s1.id AND s2.trigger = s1.trigger)
			INNER JOIN entities_snippets es2 ON (es2.snippet_id = s2.id AND es2.entity_id = es1.entity_id)
		WHERE
			s1.id = arg_snippet_id
	);

	RETURN ret_val;
END
$$;

alter function entity_snippet_already_exists(integer) owner to master;

