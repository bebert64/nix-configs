create function threads__thread_has_comment() returns trigger
    language plpgsql
as
$$
BEGIN
	IF
		NOT thread_is_not_empty(NEW.id)
	THEN
		RAISE 'Thread (%) has no comment in it', NEW.id
		USING ERRCODE = 'integrity_constraint_violation',
		CONSTRAINT = 'thread_has_comment',
		TABLE = 'comments_threads';
	END IF;
	RETURN NULL;
END
$$;

alter function threads__thread_has_comment() owner to master;

