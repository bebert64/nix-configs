create function comments__unique_draft_per_thread_and_user() returns trigger
    language plpgsql
as
$$
BEGIN
	IF
		NEW.posted_at IS NULL
		AND user_has_other_draft_in_thread(NEW.id, NEW.thread_id, NEW.created_by)
	THEN
		RAISE 'User (%) already has a draft in thread (%)', NEW.created_by, NEW.thread_id
		USING ERRCODE = 'integrity_constraint_violation',
		CONSTRAINT = 'unique_draft_per_thread_and_user',
		TABLE = 'comments';
	END IF;

	RETURN NULL;
END
$$;

alter function comments__unique_draft_per_thread_and_user() owner to master;

