create function hasnt_inherited_tables(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _inherited( $1 ), $2 );
$$;

alter function hasnt_inherited_tables(name, text) owner to rdsadmin;

