create function message_templates_visible_on_supplier_messages__no_not_removed_() returns trigger
    language plpgsql
as
$$
BEGIN
	IF EXISTS(SELECT *
			FROM "message_templates_visible_on_supplier_messages"
			WHERE "message_template_id" = NEW.message_template_id
			AND "id" != new.id
			AND "removed_at" IS NULL)
	THEN
		RAISE EXCEPTION 'message_templates_visible_on_supplier_messages__no_not_removed_duplicates FAILED';
	END IF;
	RETURN NULL;
END
$$;

alter function message_templates_visible_on_supplier_messages__no_not_removed_() owner to master;

