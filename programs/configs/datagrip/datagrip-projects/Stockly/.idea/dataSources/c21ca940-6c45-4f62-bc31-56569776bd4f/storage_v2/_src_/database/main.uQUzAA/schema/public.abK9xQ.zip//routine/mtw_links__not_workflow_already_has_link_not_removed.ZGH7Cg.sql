create function mtw_links__not_workflow_already_has_link_not_removed() returns trigger
    language plpgsql
as
$$
BEGIN
	IF
		NEW.removed_AT IS NULL
		AND manually_tracked_workflow_already_has_link_not_removed(
			NEW.id,
			NEW.manually_tracked_workflow_id,
			NEW.url,
			NEW.notion_id,
			NEW.order_line_id,
			NEW.purchase_id
		)
	THEN
		RAISE 'Manually tracked workflow (%) already has link (url=`%`, notion_id=`%`, order_line_id=%, purchase_id=%)',
			NEW.manually_tracked_workflow_id,
			NEW.url,
			NEW.notion_id,
			NEW.order_line_id,
			NEW.purchase_id
		USING ERRCODE = 'integrity_constraint_violation',
		CONSTRAINT = 'not_manually_tracked_workflow_already_has_link_not_removed',
		TABLE = 'manually_tracked_workflow_links';
	END IF;

	RETURN NULL;
END
$$;

alter function mtw_links__not_workflow_already_has_link_not_removed() owner to master;

