create function hasnt_column(name, name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _cexists( $1, $2 ), $3 );
$$;

alter function hasnt_column(name, name, text) owner to rdsadmin;

