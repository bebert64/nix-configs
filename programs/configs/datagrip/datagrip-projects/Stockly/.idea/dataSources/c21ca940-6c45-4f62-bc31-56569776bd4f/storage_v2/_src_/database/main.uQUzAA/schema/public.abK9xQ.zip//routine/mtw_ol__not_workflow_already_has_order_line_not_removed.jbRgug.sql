create function mtw_ol__not_workflow_already_has_order_line_not_removed() returns trigger
    language plpgsql
as
$$
BEGIN
	IF
		NEW.removed_at IS NULL
		AND manually_tracked_workflow_already_has_order_line_not_removed(NEW.id, NEW.manually_tracked_workflow_id, NEW.order_line_id)
	THEN
		RAISE 'ManuallyTrackedWorkflow (%) already has order_line (%)', NEW.manually_tracked_workflow_id, NEW.order_line_id
		USING ERRCODE = 'integrity_constraint_violation',
		CONSTRAINT = 'not_manually_tracked_workflow_already_has_order_line_not_removed',
		TABLE = 'manually_tracked_workflow_order_lines';
	END IF;

	RETURN NULL;
END
$$;

alter function mtw_ol__not_workflow_already_has_order_line_not_removed() owner to master;

