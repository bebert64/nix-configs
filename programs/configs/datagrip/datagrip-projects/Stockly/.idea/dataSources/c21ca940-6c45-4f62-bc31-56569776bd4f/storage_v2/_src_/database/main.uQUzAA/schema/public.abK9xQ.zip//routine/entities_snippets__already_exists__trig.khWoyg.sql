create function entities_snippets__already_exists__trig() returns trigger
    language plpgsql
as
$$
BEGIN
	IF
		entity_snippet_already_exists(NEW.snippet_id)
	THEN
		RAISE unique_violation USING
			CONSTRAINT = 'entities_snippets__already_exists',
			TABLE = 'entities_snippets',
			MESSAGE = 'entities_snippets__already_exists__trig FAILED';
	END IF;
	RETURN NULL;
END
$$;

alter function entities_snippets__already_exists__trig() owner to master;

