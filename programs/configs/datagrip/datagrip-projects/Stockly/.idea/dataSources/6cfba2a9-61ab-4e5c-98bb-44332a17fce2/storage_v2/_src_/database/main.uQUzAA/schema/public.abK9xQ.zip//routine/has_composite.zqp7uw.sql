create function has_composite(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _rexists( 'c', $1, $2 ), $3 );
$$;

alter function has_composite(name, name, text) owner to rdsadmin;

