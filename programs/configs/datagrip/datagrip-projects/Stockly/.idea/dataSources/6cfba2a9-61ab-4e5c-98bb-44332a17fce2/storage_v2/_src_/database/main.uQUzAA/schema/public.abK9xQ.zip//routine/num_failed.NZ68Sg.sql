create function num_failed() returns integer
    strict
    language sql
as
$$
    SELECT _get('failed');
$$;

alter function num_failed() owner to rdsadmin;

