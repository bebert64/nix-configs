create function _is_schema(name) returns boolean
    language sql
as
$$
    SELECT EXISTS(
        SELECT true
          FROM pg_catalog.pg_namespace
          WHERE nspname = $1
    );
$$;

alter function _is_schema(name) owner to rdsadmin;

