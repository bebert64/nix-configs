create function hasnt_rightop(name, name, name, name) returns text
    language sql
as
$$
    SELECT ok(
         NOT _op_exists($1, $2, $3, NULL, $4 ),
        'Right operator ' || quote_ident($2) || '.' || $3 || '('
        || $1 || ',NONE) RETURNS ' || $4 || ' should not exist'
    );
$$;

alter function hasnt_rightop(name, name, name, name) owner to rdsadmin;

