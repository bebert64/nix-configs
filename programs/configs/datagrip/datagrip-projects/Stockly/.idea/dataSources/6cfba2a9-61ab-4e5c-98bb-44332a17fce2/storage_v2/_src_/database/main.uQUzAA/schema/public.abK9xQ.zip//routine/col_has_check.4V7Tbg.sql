create function col_has_check(name, name[]) returns text
    language sql
as
$$
    SELECT col_has_check( $1, $2, 'Columns ' || quote_ident($1) || '(' || _ident_array_to_string($2, ', ') || ') should have a check constraint' );
$$;

alter function col_has_check(name, name[]) owner to rdsadmin;

