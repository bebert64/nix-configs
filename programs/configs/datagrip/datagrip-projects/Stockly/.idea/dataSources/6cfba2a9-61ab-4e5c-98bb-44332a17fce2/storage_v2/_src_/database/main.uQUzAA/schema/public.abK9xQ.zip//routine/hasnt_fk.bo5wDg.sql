create function hasnt_fk(name) returns text
    language sql
as
$$
    SELECT hasnt_fk( $1, 'Table ' || quote_ident($1) || ' should not have a foreign key constraint' );
$$;

alter function hasnt_fk(name) owner to rdsadmin;

