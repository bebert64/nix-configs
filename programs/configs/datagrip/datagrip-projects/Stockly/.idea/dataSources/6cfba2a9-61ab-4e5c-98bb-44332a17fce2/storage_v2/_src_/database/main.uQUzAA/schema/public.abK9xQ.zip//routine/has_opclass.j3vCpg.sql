create function has_opclass(name, text) returns text
    language sql
as
$$
    SELECT ok( _opc_exists( $1 ), $2)
$$;

alter function has_opclass(name, text) owner to rdsadmin;

