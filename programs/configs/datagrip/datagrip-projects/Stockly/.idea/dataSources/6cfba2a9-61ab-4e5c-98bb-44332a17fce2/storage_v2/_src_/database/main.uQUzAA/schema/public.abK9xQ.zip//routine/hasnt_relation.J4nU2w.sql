create function hasnt_relation(name, name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _relexists( $1, $2 ), $3 );
$$;

alter function hasnt_relation(name, name, text) owner to rdsadmin;

