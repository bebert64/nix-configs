create function results_eq(refcursor, text) returns text
    language sql
as
$$
    SELECT results_eq( $1, $2, NULL::text );
$$;

alter function results_eq(refcursor, text) owner to rdsadmin;

