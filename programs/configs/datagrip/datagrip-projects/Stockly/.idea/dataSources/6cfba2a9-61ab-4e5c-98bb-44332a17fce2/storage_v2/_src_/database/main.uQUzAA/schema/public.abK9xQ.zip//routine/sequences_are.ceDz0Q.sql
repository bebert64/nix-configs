create function sequences_are(name, name[], text) returns text
    language sql
as
$$
    SELECT _are( 'sequences', _extras('S', $1, $2), _missing('S', $1, $2), $3);
$$;

alter function sequences_are(name, name[], text) owner to rdsadmin;

