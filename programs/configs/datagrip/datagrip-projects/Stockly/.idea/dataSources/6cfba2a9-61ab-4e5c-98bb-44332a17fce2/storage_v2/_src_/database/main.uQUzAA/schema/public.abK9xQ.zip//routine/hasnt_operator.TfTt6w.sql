create function hasnt_operator(name, name, name, name, name) returns text
    language sql
as
$$
    SELECT ok(
         NOT _op_exists($1, $2, $3, $4, $5 ),
        'Operator ' || quote_ident($2) || '.' || $3 || '(' || $1 || ',' || $4
        || ') RETURNS ' || $5 || ' should not exist'
    );
$$;

alter function hasnt_operator(name, name, name, name, name) owner to rdsadmin;

