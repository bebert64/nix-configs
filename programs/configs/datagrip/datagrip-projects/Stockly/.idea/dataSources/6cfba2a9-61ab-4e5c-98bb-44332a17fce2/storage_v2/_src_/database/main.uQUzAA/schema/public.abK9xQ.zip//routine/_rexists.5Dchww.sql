create function _rexists(character, name, name) returns boolean
    language sql
as
$$
    SELECT _rexists(ARRAY[$1], $2, $3);
$$;

alter function _rexists(char, name, name) owner to rdsadmin;

