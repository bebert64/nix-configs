create function col_isnt_fk(name, name[]) returns text
    language sql
as
$$
    SELECT col_isnt_fk( $1, $2, 'Columns ' || quote_ident($1) || '(' || _ident_array_to_string($2, ', ') || ') should not be a foreign key' );
$$;

alter function col_isnt_fk(name, name[]) owner to rdsadmin;

