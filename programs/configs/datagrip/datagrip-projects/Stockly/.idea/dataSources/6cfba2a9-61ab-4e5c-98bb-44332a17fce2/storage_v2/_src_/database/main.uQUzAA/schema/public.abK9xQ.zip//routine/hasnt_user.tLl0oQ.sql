create function hasnt_user(name) returns text
    language sql
as
$$
    SELECT ok( NOT _has_user( $1 ), 'User ' || quote_ident($1) || ' should not exist');
$$;

alter function hasnt_user(name) owner to rdsadmin;

