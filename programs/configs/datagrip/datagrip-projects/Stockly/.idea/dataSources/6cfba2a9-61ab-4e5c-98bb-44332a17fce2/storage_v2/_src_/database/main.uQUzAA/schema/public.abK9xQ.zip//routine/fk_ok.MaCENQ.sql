create function fk_ok(name, name, name[], name, name, name[]) returns text
    language sql
as
$$
    SELECT fk_ok( $1, $2, $3, $4, $5, $6,
        quote_ident($1) || '.' || quote_ident($2) || '(' || _ident_array_to_string( $3, ', ' )
        || ') should reference ' ||
        $4 || '.' || $5 || '(' || _ident_array_to_string( $6, ', ' ) || ')'
    );
$$;

alter function fk_ok(name, name, name[], name, name, name[]) owner to rdsadmin;

