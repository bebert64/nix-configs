create function ols_margin(ol_ids integer[]) returns double precision
    stable
    parallel safe
    language plpgsql
as
$$
BEGIN
    RETURN (SELECT
    SUM(
    COALESCE(
        t.ol_total_client_price_et + t.ol_attributed_shipping_price_et + t.refund_ol_dmd_commission_et + t.refund_ol_attributed_dmd_shipping_commision_et
        - (t.refund_ol_total_price_et + t.refund_ol_attributed_shipping_price_et + t.ol_dmd_commission_et + t.ol_attributed_dmd_shipping_commision_et)
        + t.refund_total_pcs_price_et + t.refund_total_pcs_attributed_shipping_price_et
        - (t.pcs_price_et + t.pcs_attributed_pcs_shipping_price_et + t.total_pcs_attributed_additional_shipping_price_et)
        ::float,
        0
    ))
    FROM (
         SELECT
            (ol.client_price_et + ol.client_extra_shipping_price_et) as ol_total_client_price_et,
            COALESCE(CASE
                WHEN dmd_com_cfg.source = 'price_et' THEN ol.client_price_et
                WHEN dmd_com_cfg.source = 'price_it' THEN (ol.client_price_et * (1 + ol.client_vat_rate))
            END * dmd_com_cfg.value, 0) as ol_dmd_commission_et,
            (os.client_price_et / os.nb_order_lines) as ol_attributed_shipping_price_et,
            COALESCE((CASE
                WHEN dmd_os_com_cfg.source = 'price_et' THEN (os.client_price_et / os.nb_order_lines) + ol.client_extra_shipping_price_et
                WHEN dmd_os_com_cfg.source = 'price_it' THEN ((os.client_price_et / os.nb_order_lines) + ol.client_extra_shipping_price_et) * (1. + os.client_vat_rate)
            END) * dmd_os_com_cfg.value, 0) as ol_attributed_dmd_shipping_commision_et,
            COALESCE(olr.price_et + olr.extra_shipping_price_et, 0) as refund_ol_total_price_et,
            COALESCE((CASE
                WHEN dmd_com_cfg.source = 'price_et' THEN olr.price_et
                WHEN dmd_com_cfg.source = 'price_it' THEN olr.price_et * (1. + ol.client_vat_rate)
            END) * dmd_com_cfg.value, 0) as refund_ol_dmd_commission_et,
            COALESCE(osr.price_et / os.nb_order_lines, 0) as refund_ol_attributed_shipping_price_et,
            COALESCE((CASE
                WHEN dmd_os_com_cfg.source = 'price_et' THEN COALESCE(osr.price_et, 0) / os.nb_order_lines  + olr.extra_shipping_price_et
                WHEN dmd_os_com_cfg.source = 'price_it' THEN (COALESCE(osr.price_et, 0) / os.nb_order_lines + olr.extra_shipping_price_et) * (1.+os.client_vat_rate)
            END) * dmd_os_com_cfg.value, 0) as refund_ol_attributed_dmd_shipping_commision_et,
            CASE WHEN  pcs.purchases_shipping_id IS NOT NULL THEN COALESCE(pcs.price_et, 0) ELSE 0 END as pcs_price_et,
            COALESCE(purchases_shippings.price_et / purchases_shippings.nb_purchases, 0) as pcs_attributed_pcs_shipping_price_et,
            COALESCE(total_pcs_attributed_additional_shipping.price_et, 0) as total_pcs_attributed_additional_shipping_price_et,
            COALESCE(tpr.price_et, 0) as refund_total_pcs_price_et,
            COALESCE(tpsr.price_et / purchases_shippings.nb_purchases, 0) as refund_total_pcs_attributed_shipping_price_et
        FROM
            order_lines ol
            LEFT JOIN demander_commission_configs dmd_com_cfg ON dmd_com_cfg.id = ol.demander_commission_config_id
            INNER JOIN (
                SELECT
                    os.*,
                    COUNT(*) as nb_order_lines
                FROM
                    order_shippings os
                    INNER JOIN order_lines ol_inner on os.id = ol_inner.order_shipping_id
                GROUP BY os.id
            ) os on ol.order_shipping_id = os.id
            INNER JOIN orders o ON (
                os.order_id = o.id
                AND o.confirmed_at IS NOT NULL
            )
            LEFT JOIN (
                SELECT
                    olr.order_line_id,
                    SUM(olr.price_et),
                    SUM(olr.extra_shipping_price_et)
               FROM order_line_refunds olr
               GROUP BY olr.order_line_id
            ) olr(order_line_id,price_et,extra_shipping_price_et) ON ol.id = olr.order_line_id
            LEFT JOIN (
                SELECT
                    osr.order_shipping_id,
                    SUM(price_et)
                FROM order_shipping_refunds osr
                GROUP BY osr.order_shipping_id
            ) osr(order_shipping_id, price_et) on os.id = osr.order_shipping_id
            LEFT JOIN demander_commission_configs dmd_os_com_cfg ON dmd_os_com_cfg.id = os.demander_commission_config_id
            LEFT JOIN demander_persons dp on dp.id = o.owner_id
            LEFT JOIN purchases pcs on pcs.id = ol.purchase_id
            LEFT JOIN (
                SELECT
                    pr.purchase_id,
                    SUM(pr.price_et)
                FROM purchase_refunds pr
                GROUP BY pr.purchase_id
            ) tpr(purchase_id, price_et) ON tpr.purchase_id = pcs.id
            LEFT JOIN (
                SELECT
                    pcss.id,
                    pcss.price_et,
                    COUNT(*) as nb_purchases
                FROM
                    purchases_shippings pcss
                    INNER JOIN purchases p_inner ON p_inner.purchases_shipping_id = pcss.id
                GROUP BY pcss.id
            ) purchases_shippings(pcs_shipping_id, price_et, nb_purchases) on pcs.purchases_shipping_id = purchases_shippings.pcs_shipping_id
            LEFT JOIN (
                SELECT
                    psr.purchases_shipping_id,
                    sum(psr.price_et)
                FROM
                    purchases_shipping_refunds psr
                GROUP BY psr.purchases_shipping_id
            ) tpsr(purchases_shipping_id, price_et) on tpsr.purchases_shipping_id = pcs.purchases_shipping_id
            LEFT JOIN (
                SELECT
                    pi.purchase_id,
                    SUM(pcl.stockly_pays_et / pcl.nb_parcel_items) as price_et
                FROM
                    parcel_items pi
                    INNER JOIN (
                        SELECT
                            pcl.id,
                            pcl.stockly_pays_et,
                            COUNT(*) as nb_parcel_items
                        FROM
                            parcel_items pi
                            INNER JOIN parcels pcl ON pcl.id = pi.parcel_id
                        WHERE
                            pi.flagged_as_erroneous_at IS NULL
                        GROUP BY pcl.id
                    ) pcl(id, stockly_pays_et, nb_parcel_items) ON pcl.id = pi.parcel_id
                WHERE
                    pi.flagged_as_erroneous_at IS NULL
                    AND pi.created_at != (SELECT MIN(pi_inner.created_at)
                        FROM parcel_items pi_inner
                        WHERE pi_inner.purchase_id = pi.purchase_id
                            AND pi_inner.flagged_as_erroneous_at IS NULL
                        GROUP BY pi.purchase_id
                    )
                GROUP BY pi.purchase_id
            ) as total_pcs_attributed_additional_shipping on total_pcs_attributed_additional_shipping.purchase_id = pcs.id
        WHERE
            ol.id = ANY (ol_ids)
    ) t);
END;
$$;

alter function ols_margin(integer[]) owner to master;

