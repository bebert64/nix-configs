create function next_working_day_start(start_dt timestamp with time zone, time_zone text) returns timestamp with time zone
    language plpgsql
as
$$
BEGIN RETURN next_time_occurrence(start_dt, time_zone, 9, 0, '{6, 7}'); END;
$$;

alter function next_working_day_start(timestamp with time zone, text) owner to master;

