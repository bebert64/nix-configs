create function prev_day_start(start_dt timestamp with time zone, time_zone text) returns timestamp with time zone
    language plpgsql
as
$$
BEGIN RETURN prev_time_occurrence(start_dt, time_zone, 9, 0, '{}'); END;
$$;

alter function prev_day_start(timestamp with time zone, text) owner to master;

