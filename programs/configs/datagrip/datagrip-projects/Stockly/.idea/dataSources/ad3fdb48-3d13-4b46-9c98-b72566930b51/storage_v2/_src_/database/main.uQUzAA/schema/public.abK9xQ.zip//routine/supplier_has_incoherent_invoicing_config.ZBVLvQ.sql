create function supplier_has_incoherent_invoicing_config(arg_retailer_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
	RETURN (SELECT EXISTS (
		SELECT
				*
			FROM
				"retailers" r
			LEFT JOIN "suppliers" s ON s.retailer_id = r.id
		WHERE
			(r.id = arg_retailer_id OR arg_retailer_id IS NULL)
			AND s.periodic_invoicing_config_id IS NOT NULL
			AND r.invoices_legal_entity_id IS NULL
	));
END;
$$;

alter function supplier_has_incoherent_invoicing_config(integer) owner to master;

