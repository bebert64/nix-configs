create view order_line_purchase_bindings_intervals_partial2(order_line_id, purchase_id, bound_at, unbound_at) as
SELECT DISTINCT ON (ol.id) ol.id                          AS order_line_id,
                           ol.purchase_id,
                           olpbh_latest.created_at        AS bound_at,
                           NULL::timestamp with time zone AS unbound_at
FROM order_lines ol
         LEFT JOIN order_lines_purchase_id_history olpbh_latest ON olpbh_latest.order_line_id = ol.id
ORDER BY ol.id, olpbh_latest.created_at DESC, olpbh_latest.id DESC;

alter table order_line_purchase_bindings_intervals_partial2
    owner to master;

grant select on order_line_purchase_bindings_intervals_partial2 to accounting;

grant select on order_line_purchase_bindings_intervals_partial2 to ro;

grant delete, insert, select, update on order_line_purchase_bindings_intervals_partial2 to rw;

grant select on order_line_purchase_bindings_intervals_partial2 to epsio_user;

