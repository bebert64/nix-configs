create function purchase_cancellations__fully_refunded_with_refused_cancellatio() returns trigger
    language plpgsql
as
$$
BEGIN
    IF purchase_fully_refunded_with_refused_cancellation(NULL, NEW.id, NULL)
	THEN
		RAISE EXCEPTION 'purchase_cancellations__fully_refunded_with_refused_cancellation FAILED';
	END IF;
    RETURN NULL;
END
$$;

alter function purchase_cancellations__fully_refunded_with_refused_cancellatio() owner to master;

