create function parcel_items__stockly_pays_et_for_initial_parcel_delete_check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF incoherent_stockly_pays_et_for_initial_parcel(NULL, OLD.purchase_id) THEN
		RAISE 'deleting parcel_item_id = % causes some parcel to become initial for purchase_id = %, but that parcel has stockly_pays_et != 0', OLD.id, OLD.purchase_id
		USING
			ERRCODE = 'check_violation',
			TABLE = 'parcel_items';
	END IF;
	RETURN NULL;
END
$$;

alter function parcel_items__stockly_pays_et_for_initial_parcel_delete_check() owner to master;

