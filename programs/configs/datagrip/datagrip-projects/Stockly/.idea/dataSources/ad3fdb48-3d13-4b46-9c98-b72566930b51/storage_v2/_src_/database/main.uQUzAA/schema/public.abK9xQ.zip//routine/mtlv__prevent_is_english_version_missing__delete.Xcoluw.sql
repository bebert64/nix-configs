create function mtlv__prevent_is_english_version_missing__delete() returns trigger
    language plpgsql
as
$$
BEGIN
	IF is_english_version_missing(OLD.message_template_id) THEN
		RAISE EXCEPTION 'Deleting message_template_language_version = % will cause a missing English version for message_template = %.', OLD.id, OLD.message_template_id;
	END IF;
	RETURN OLD;
END;
$$;

alter function mtlv__prevent_is_english_version_missing__delete() owner to master;

