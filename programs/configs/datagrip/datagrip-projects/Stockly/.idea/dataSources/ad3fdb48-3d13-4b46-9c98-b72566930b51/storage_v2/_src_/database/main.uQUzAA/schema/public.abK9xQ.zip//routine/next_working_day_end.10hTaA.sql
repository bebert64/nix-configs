create function next_working_day_end(start_dt timestamp with time zone, time_zone text) returns timestamp with time zone
    language plpgsql
as
$$
BEGIN RETURN next_time_occurrence(start_dt, time_zone, 18, 30, '{6, 7}'); END;
$$;

alter function next_working_day_end(timestamp with time zone, text) owner to master;

