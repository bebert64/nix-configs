create function pcs_cancellation_decisions__check_is_in_incoherent_refund_state() returns trigger
    language plpgsql
as
$$
BEGIN
	IF purchases__is_in_incoherent_refund_state(NULL, NULL, NEW.id, NULL) THEN
		RAISE EXCEPTION 'pcs_cancellation_decisions__check_is_in_incoherent_refund_state';
	END IF;
	RETURN NULL;
END
$$;

alter function pcs_cancellation_decisions__check_is_in_incoherent_refund_state() owner to master;

