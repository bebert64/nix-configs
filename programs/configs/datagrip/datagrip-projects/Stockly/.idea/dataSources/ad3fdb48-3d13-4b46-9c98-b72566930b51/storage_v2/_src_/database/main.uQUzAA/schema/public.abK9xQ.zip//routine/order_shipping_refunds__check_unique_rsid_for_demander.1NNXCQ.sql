create function order_shipping_refunds__check_unique_rsid_for_demander() returns trigger
    language plpgsql
as
$$
BEGIN
	IF EXISTS(SELECT *
			FROM order_shipping_refunds osr
				INNER JOIN order_shippings os ON osr.order_shipping_id = os.id
				INNER JOIN orders o ON os.order_id = o.id
				INNER JOIN demander_persons dp ON o.owner_id = dp.id
				INNER JOIN demander_persons dp2 ON dp2.demander_id = dp.demander_id
				INNER JOIN orders o2 ON o2.owner_id = dp2.id
				INNER JOIN order_shippings os2 ON os2.order_id = o2.id
			WHERE osr.retailer_specific_id = NEW.retailer_specific_id
				AND osr.id != NEW.id
				AND os2.id = NEW.order_shipping_id)
	THEN
		RAISE EXCEPTION 'order_shipping_refunds__check_unique_rsid_for_demander FAILED';
	END IF;
	RETURN NULL;
END
$$;

alter function order_shipping_refunds__check_unique_rsid_for_demander() owner to master;

