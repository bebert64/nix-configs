create function pc__no_cancellation_decision_on_not_submitted_purchases() returns trigger
    language plpgsql
as
$$
BEGIN
	IF cancellation_decision_on_not_submitted_purchases (NULL, NEW.id) THEN
		RAISE 'Impossible to register a purchase_cancellation with a decision when no purchase has yet been submitted'
		USING ERRCODE = 'integrity_constraint_violation', CONSTRAINT = 'no_cancellation_decision_on_not_submitted_purchases', TABLE = 'purchase_cancellations';
	END IF;
	RETURN NULL;
END
$$;

alter function pc__no_cancellation_decision_on_not_submitted_purchases() owner to master;

