create function has_domain(name) returns text
    language sql
as
$$
    SELECT ok( _has_type( $1, ARRAY['d'] ), ('Domain ' || quote_ident($1) || ' should exist')::text );
$$;

alter function has_domain(name) owner to rdsadmin;

