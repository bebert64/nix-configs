create function order_line__save_purchase_binding_history() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NEW.id != OLD.id) THEN
		RAISE EXCEPTION '% You can''t change an order line ID', NEW.id;
	END IF;
	IF (NEW.purchase_id IS DISTINCT FROM OLD.purchase_id) THEN
		INSERT INTO order_lines_purchase_id_history (order_line_id, previous_purchase_id)
			VALUES (OLD.id, OLD.purchase_id);
	END IF;
	RETURN NULL;
END;
$$;

alter function order_line__save_purchase_binding_history() owner to master;

