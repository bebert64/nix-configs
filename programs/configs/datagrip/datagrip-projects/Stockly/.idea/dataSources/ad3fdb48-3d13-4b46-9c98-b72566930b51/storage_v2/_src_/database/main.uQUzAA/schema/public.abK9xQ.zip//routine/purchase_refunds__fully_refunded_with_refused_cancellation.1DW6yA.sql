create function purchase_refunds__fully_refunded_with_refused_cancellation() returns trigger
    language plpgsql
as
$$
BEGIN
    IF purchase_fully_refunded_with_refused_cancellation(NEW.purchase_id, NULL, NULL)
    THEN
		RAISE EXCEPTION 'purchase_refunds__fully_refunded_with_refused_cancellation FAILED';
	END IF;
	RETURN NULL;
END
$$;

alter function purchase_refunds__fully_refunded_with_refused_cancellation() owner to master;

