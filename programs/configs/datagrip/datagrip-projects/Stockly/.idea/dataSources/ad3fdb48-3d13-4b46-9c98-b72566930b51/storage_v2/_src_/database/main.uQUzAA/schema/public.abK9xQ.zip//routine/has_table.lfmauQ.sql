create function has_table(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _rexists( '{r,p}'::char[], $1, $2 ), $3 );
$$;

alter function has_table(name, name, text) owner to rdsadmin;

