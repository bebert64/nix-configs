create function open_manual_process_exists(arg_order_line_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val boolean := FALSE;
BEGIN
	SELECT
		INTO ret_val EXISTS (
			SELECT
				COUNT(*) AS count
			FROM
				manual_order_line_purchase_binding_process
			WHERE (order_line_id = arg_order_line_id
				OR arg_order_line_id IS NULL)
			AND handled_by IS NULL
		GROUP BY
			order_line_id
		HAVING
			COUNT(*) > 1);
	RETURN ret_val;
END
$$;

alter function open_manual_process_exists(integer) owner to master;

