create function order_shippings__retailer_specific_id__exists(arg_retailer_specific_id character varying, arg_order_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT
			*
		FROM
			"order_shippings" old_os
			INNER JOIN
				"orders" old_o
			ON
				old_o.id = old_os.order_id
			INNER JOIN
				"demander_consumers" old_dc
			ON
				old_dc.id = old_o.demander_consumer_id
			INNER JOIN
				"orders" new_o
			ON
				new_o.id = arg_order_id
			INNER JOIN
				"demander_consumers" new_dc
			ON
				new_dc.id = new_o.demander_consumer_id
		WHERE
			old_dc.retailer_id = new_dc.retailer_id
			AND old_os.retailer_specific_id = arg_retailer_specific_id
	);

	RETURN ret_val;
END
$$;

alter function order_shippings__retailer_specific_id__exists(varchar, integer) owner to master;

