create function sum_of_pship_refunds_exceeds_pship_price_et(arg_purchases_shipping_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
	RETURN (SELECT EXISTS (
		SELECT * FROM purchases_shippings pship
			INNER JOIN (SELECT psr.purchases_shipping_id, SUM(psr.price_et) as refunds_sum_et FROM purchases_shipping_refunds psr GROUP BY psr.purchases_shipping_id) psr_sum on pship.id = psr_sum.purchases_shipping_id
			WHERE (pship.id = arg_purchases_shipping_id OR arg_purchases_shipping_id IS NULL) AND psr_sum.refunds_sum_et > pship.price_et + 1e-9
	));
END;
$$;

alter function sum_of_pship_refunds_exceeds_pship_price_et(integer) owner to master;

