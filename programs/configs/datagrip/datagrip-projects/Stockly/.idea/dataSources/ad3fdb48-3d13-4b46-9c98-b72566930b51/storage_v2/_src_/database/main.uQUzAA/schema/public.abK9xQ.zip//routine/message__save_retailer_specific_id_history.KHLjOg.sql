create function message__save_retailer_specific_id_history() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NEW.id != OLD.id) THEN
		RAISE EXCEPTION '% You can''t change a message ID', NEW.id;
	END IF;
	IF (NEW.retailer_specific_id IS DISTINCT FROM OLD.retailer_specific_id) THEN
		INSERT INTO public.order_messages_retailer_specific_id_history (order_message_id, previous_retailer_specific_id)
			VALUES (OLD.id, OLD.retailer_specific_id);
	END IF;
	RETURN NULL;
END;
$$;

alter function message__save_retailer_specific_id_history() owner to master;

