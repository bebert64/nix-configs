create function order_line_refunds__conflicting_cancellation_and_order_line(arg_order_line_cancellation_id integer, arg_order_line_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT
			*
		FROM
			"order_line_cancellations" olc
		WHERE
			olc.id = arg_order_line_cancellation_id
			AND olc.order_line_id != arg_order_line_id
	);

	RETURN ret_val;
END
$$;

alter function order_line_refunds__conflicting_cancellation_and_order_line(integer, integer) owner to master;

