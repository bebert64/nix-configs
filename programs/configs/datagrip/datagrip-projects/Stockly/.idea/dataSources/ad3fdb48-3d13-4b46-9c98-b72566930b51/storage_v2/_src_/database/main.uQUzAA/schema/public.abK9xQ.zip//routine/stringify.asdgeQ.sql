create function stringify(txt text, cap_all_words boolean DEFAULT true, splitter text DEFAULT '_'::text) returns text
    immutable
    parallel safe
    language plpgsql
as
$$
DECLARE
    output_array Text[];
BEGIN
    CASE
        WHEN cap_all_words THEN
            txt = REPLACE(txt, splitter, ' ');
            RETURN INITCAP(txt);
        ELSE
            output_array = STRING_TO_ARRAY(LOWER(txt), splitter);
            output_array[1] = INITCAP(output_array[1]);
            RETURN ARRAY_TO_STRING(output_array, ' ');
    END CASE;
END;
$$;

alter function stringify(text, boolean, text) owner to master;

