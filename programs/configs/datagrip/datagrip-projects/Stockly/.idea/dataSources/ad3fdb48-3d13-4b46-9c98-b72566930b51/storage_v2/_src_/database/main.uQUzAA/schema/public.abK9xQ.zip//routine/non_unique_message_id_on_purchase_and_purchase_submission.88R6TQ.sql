create function non_unique_message_id_on_purchase_and_purchase_submission(arg_purchase_message_id integer, arg_purchase_submission_message_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
	RETURN (
		SELECT
			EXISTS (
				SELECT
					*
				FROM
					"supplier_message_purchases_bindings" smpb
					INNER JOIN supplier_message_purchases_submissions_bindings smpsb ON smpsb.supplier_message_id = smpb.supplier_message_id
				WHERE (smpb.supplier_message_id = arg_purchase_submission_message_id
					OR arg_purchase_submission_message_id IS NULL)
				AND (smpsb.supplier_message_id = arg_purchase_message_id
					OR arg_purchase_message_id IS NULL)));
END
$$;

alter function non_unique_message_id_on_purchase_and_purchase_submission(integer, integer) owner to master;

