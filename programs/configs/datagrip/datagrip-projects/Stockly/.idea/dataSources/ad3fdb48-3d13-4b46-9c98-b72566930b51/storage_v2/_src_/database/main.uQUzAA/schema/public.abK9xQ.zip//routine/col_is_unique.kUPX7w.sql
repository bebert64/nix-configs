create function col_is_unique(name, name[], text) returns text
    language sql
as
$$
    SELECT _constraint( $1, 'u', $2, $3, 'unique' );
$$;

alter function col_is_unique(name, name[], text) owner to rdsadmin;

