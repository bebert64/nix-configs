create function _get_note(text) returns text
    strict
    language plpgsql
as
$$
DECLARE
    ret text;
BEGIN
    EXECUTE 'SELECT note FROM __tcache__ WHERE label = ' || quote_literal($1) || ' LIMIT 1' INTO ret;
    RETURN ret;
END;
$$;

alter function _get_note(text) owner to rdsadmin;

