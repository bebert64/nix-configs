create function incoherent_stocks_item_id_in_matching_checks(arg_matching_check_id integer, arg_order_line_id integer, arg_purchase_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
	RETURN (
		SELECT (
			EXISTS (
					SELECT
						*
					FROM
						validated_matchings
						INNER JOIN matching_checks ON validated_matchings.id = matching_checks.validated_matching_id
						INNER JOIN order_lines ON order_lines.id = matching_checks.order_line_id
						INNER JOIN purchases ON purchases.id = matching_checks.purchase_id
					WHERE
						(
							((matching_checks.id = arg_matching_check_id) OR arg_matching_check_id IS NULL)
							AND((order_lines.id = arg_order_line_id) OR arg_order_line_id IS NULL)
							AND((purchases.id = arg_purchase_id) OR arg_purchase_id IS NULL)
						) 
						AND NOT
						(
							(validated_matchings.demander_stocks_item_id = order_lines.stocks_item_id)
							AND(validated_matchings.supplier_stocks_item_id = purchases.stocks_item_id)
						)
					)
				)
			);
END
$$;

alter function incoherent_stocks_item_id_in_matching_checks(integer, integer, integer) owner to master;

