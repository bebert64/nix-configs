create function order_shippings__order_owner_represents_demander__check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NOT demand__order_owner_represents_demander__check(NULL, NULL, NEW.id, NULL)) THEN
		RAISE EXCEPTION 'order_shippings__order_owner_represents_demander__check FAILED';
	END IF;
	RETURN NULL;
END
$$;

alter function order_shippings__order_owner_represents_demander__check() owner to master;

