create function todo_start(text) returns SETOF boolean
    language plpgsql
as
$$
BEGIN
    PERFORM _add('todo', -1, COALESCE($1, ''));
    RETURN;
END;
$$;

alter function todo_start(text) owner to rdsadmin;

