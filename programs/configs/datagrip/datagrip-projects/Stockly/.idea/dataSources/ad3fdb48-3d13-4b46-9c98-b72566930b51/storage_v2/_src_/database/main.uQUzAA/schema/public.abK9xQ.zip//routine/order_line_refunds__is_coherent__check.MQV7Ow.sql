create function order_line_refunds__is_coherent__check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (exists_incoherent_order_line_refund(NEW.order_line_id, NEW.id)) THEN
		RAISE EXCEPTION 'order_line_refunds__is_coherent__check FAILED';
	END IF;
	RETURN NULL;
END
$$;

alter function order_line_refunds__is_coherent__check() owner to master;

