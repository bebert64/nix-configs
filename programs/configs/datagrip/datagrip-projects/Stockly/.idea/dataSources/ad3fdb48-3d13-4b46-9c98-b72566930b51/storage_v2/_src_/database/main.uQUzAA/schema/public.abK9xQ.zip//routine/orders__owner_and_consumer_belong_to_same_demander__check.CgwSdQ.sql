create function orders__owner_and_consumer_belong_to_same_demander__check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (
		NEW.consumer_id IS NOT NULL
		AND (
			OLD IS NULL
			OR (
				NEW.consumer_id != OLD.consumer_id OR NEW.owner_id != OLD.owner_id
			)
		)
		AND NOT orders__owner_and_consumer_belong_to_same_demander(NEW.owner_id, NEW.consumer_id)
	) THEN
		RAISE EXCEPTION 'orders__owner_and_consumer_belong_to_same_demander__check FAILED';
	END IF;
	RETURN NULL;
END
$$;

alter function orders__owner_and_consumer_belong_to_same_demander__check() owner to master;

