create function molpbp__check_molpbp_handled_by_coherent_with_order_line_state() returns trigger
    language plpgsql
as
$$ BEGIN
	IF NOT molpbp_handled_by_coherent_with_order_line_state(NEW.order_line_id) THEN RAISE
	EXCEPTION
		'handled_by is incoherent with order_line state';

	END IF;

	RETURN NULL;

END$$;

alter function molpbp__check_molpbp_handled_by_coherent_with_order_line_state() owner to master;

