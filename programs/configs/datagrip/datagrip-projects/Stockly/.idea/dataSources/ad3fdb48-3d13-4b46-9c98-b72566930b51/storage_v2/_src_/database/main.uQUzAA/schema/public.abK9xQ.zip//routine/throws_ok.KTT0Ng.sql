create function throws_ok(text, text) returns text
    language plpgsql
as
$$
BEGIN
    IF octet_length($2) = 5 THEN
        RETURN throws_ok( $1, $2::char(5), NULL, NULL );
    ELSE
        RETURN throws_ok( $1, NULL, $2, NULL );
    END IF;
END;
$$;

alter function throws_ok(text, text) owner to rdsadmin;

