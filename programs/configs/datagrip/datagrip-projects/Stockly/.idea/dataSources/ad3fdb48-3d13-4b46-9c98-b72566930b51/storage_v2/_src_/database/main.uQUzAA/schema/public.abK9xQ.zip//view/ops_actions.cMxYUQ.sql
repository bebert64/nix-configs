create view ops_actions(action_type, created_by, created_at) as
SELECT action_type,
       created_by,
       created_at
FROM (SELECT 'purchases_submission'::text AS "?column?",
             purchases_submissions.created_by,
             purchases_submissions.created_at
      FROM purchases_submissions
      WHERE purchases_submissions.created_by::text <> 'Operations'::text
      UNION ALL
      SELECT 'purchase_cancellation'::text AS text,
             purchase_cancellations.created_by,
             purchase_cancellations.created_at
      FROM purchase_cancellations
      WHERE purchase_cancellations.created_by::text <> ALL
            (ARRAY ['Operations'::character varying::text, 'Retailer (by API)'::character varying::text])
      UNION ALL
      SELECT 'purchase_cancellation_decision'::text AS text,
             purchase_cancellation_decisions.created_by,
             purchase_cancellation_decisions.created_at
      FROM purchase_cancellation_decisions
      WHERE purchase_cancellation_decisions.created_by::text <> 'Operations'::text
      UNION ALL
      SELECT 'order_line_cancellation'::text AS text,
             order_line_cancellations.created_by,
             order_line_cancellations.created_at
      FROM order_line_cancellations
      WHERE order_line_cancellations.created_by::text <> ALL
            (ARRAY ['Operations'::character varying::text, 'Retailer (by API)'::character varying::text])
      UNION ALL
      SELECT 'order_line_cancellation_decision'::text AS text,
             order_line_cancellation_decisions.created_by,
             order_line_cancellation_decisions.created_at
      FROM order_line_cancellation_decisions
      WHERE order_line_cancellation_decisions.created_by::text <> 'Operations'::text
      UNION ALL
      SELECT 'tracking_info_registration'::text AS text,
             parcels.shipments_parcel_updated_by,
             parcels.shipments_parcel_updated_at
      FROM parcels
      WHERE parcels.shipments_parcel_updated_by::text <> ALL
            (ARRAY ['Operations'::character varying::text, 'Repackages'::character varying::text, 'Retailer (by API)'::character varying::text])
      UNION ALL
      SELECT 'submission_parcel_tracking_info_snooze'::text AS text,
             s.created_by,
             s.created_at
      FROM submission_parcel_tracking_info_snoozes sptis
               JOIN snoozes s ON sptis.snooze_id = s.id
      UNION ALL
      SELECT 'problem_acknowledgement'::text AS text,
             problems.acknowledged_by,
             problems.acknowledged_at
      FROM problems
      WHERE problems.acknowledged_by::text <> ALL
            (ARRAY ['Problem migration'::character varying::text, 'Bulk handle script'::character varying::text, 'Operations'::character varying::text])
      UNION ALL
      SELECT 'problem_resolution'::text AS text,
             problems.resolved_by,
             problems.resolved_at
      FROM problems
      WHERE problems.resolved_by::text <> ALL
            (ARRAY ['Bulk handle script'::character varying::text, 'Auto resolve script'::character varying::text, 'Problem migration'::character varying::text, 'Operations'::character varying::text, 'Retailer (by API)'::character varying::text])
      UNION ALL
      SELECT 'order_message_sending'::text AS text,
             som.triggered_by,
             order_messages.sent_at
      FROM order_messages
               JOIN sent_order_messages som ON order_messages.id = som.order_message_id
      WHERE COALESCE(som.triggered_by, ''::character varying)::text <> ALL
            (ARRAY ['Operations'::character varying::text, 'Retailer (by API)'::character varying::text])
      UNION ALL
      SELECT 'order_message_answered_by_templated_flag'::text AS text,
             received_order_messages.flagged_by,
             received_order_messages.flagged_as_answered_by_one_of_next_templated_at
      FROM received_order_messages
      WHERE received_order_messages.flagged_as_answered_by_one_of_next_templated_at IS NOT NULL
        AND received_order_messages.flagged_by::text <> 'Operations'::text
      UNION ALL
      SELECT 'order_message_no_answer_required_flag'::text AS text,
             received_order_messages.flagged_by,
             received_order_messages.flagged_as_no_answer_required_at
      FROM received_order_messages
      WHERE received_order_messages.flagged_by::text <> 'Retailer (by API)'::text
        AND received_order_messages.flagged_as_no_answer_required_at IS NOT NULL
      UNION ALL
      SELECT 'demander_delivery_dispute_opening'::text AS text,
             demand_delivery_disputes.created_by,
             demand_delivery_disputes.created_at
      FROM demand_delivery_disputes
      UNION ALL
      SELECT 'demander_delivery_dispute_confirmation'::text AS text,
             demand_delivery_disputes.confirmed_by,
             demand_delivery_disputes.confirmed_at
      FROM demand_delivery_disputes
      WHERE demand_delivery_disputes.confirmed_at IS NOT NULL
      UNION ALL
      SELECT 'demander_delivery_dispute_closure'::text AS text,
             demand_delivery_disputes.closed_by,
             demand_delivery_disputes.closed_at
      FROM demand_delivery_disputes
      WHERE demand_delivery_disputes.closed_at IS NOT NULL
        AND demand_delivery_disputes.closed_by::text <> 'Operations'::text
      UNION ALL
      SELECT 'supplier_delivery_dispute_decision'::text AS text,
             sddo.created_by,
             sddo.created_at
      FROM supply_delivery_disputes sdd
               JOIN supply_delivery_dispute_outcomes sddo ON sdd.outcome_id = sddo.id
      UNION ALL
      SELECT 'acceptable_loss_registration'::text AS text,
             acceptable_losses.created_by,
             acceptable_losses.created_at
      FROM acceptable_losses
      WHERE acceptable_losses.created_by::text <> 'Operations'::text
      UNION ALL
      SELECT 'return_parcel_label_file_request'::text AS text,
             asked_return_parcel_labels.created_by,
             asked_return_parcel_labels.created_at
      FROM asked_return_parcel_labels
      WHERE (asked_return_parcel_labels.created_by::text <> ALL
             (ARRAY ['Operations'::character varying::text, 'Retailer (by API)'::character varying::text]))
        AND asked_return_parcel_labels.created_at <> asked_return_parcel_labels.file_registered_at
      UNION ALL
      SELECT 'return_parcel_label_file_registration'::text AS text,
             asked_return_parcel_labels.file_registered_by,
             asked_return_parcel_labels.file_registered_at
      FROM asked_return_parcel_labels
      WHERE (asked_return_parcel_labels.file_registered_by::text <> ALL
             (ARRAY ['Operations'::character varying::text, 'Retailer (by API)'::character varying::text]))
        AND asked_return_parcel_labels.file_registered_at IS NOT NULL
      UNION ALL
      SELECT 'ask_for_return_parcel_label_snooze'::text AS text,
             s.created_by,
             s.created_at
      FROM ask_for_return_parcel_label_snoozes afrpls
               JOIN snoozes s ON afrpls.snooze_id = s.id
      UNION ALL
      SELECT 'ask_for_supplier_return_identification_label_snooze'::text AS text,
             s.created_by,
             s.created_at
      FROM ask_for_supplier_return_identification_label_snoozes afsrils
               JOIN snoozes s ON afsrils.snooze_id = s.id
      UNION ALL
      SELECT 'register_return_parcel_label_snooze'::text AS text,
             s.created_by,
             s.created_at
      FROM register_return_parcel_label_snoozes rrpls
               JOIN snoozes s ON rrpls.snooze_id = s.id
      UNION ALL
      SELECT 'register_supplier_return_identification_label_snooze'::text AS text,
             s.created_by,
             s.created_at
      FROM register_supplier_return_identification_label_snoozes rsrils
               JOIN snoozes s ON rsrils.snooze_id = s.id
      UNION ALL
      SELECT 'return_identification_label_file_request'::text AS text,
             asked_supplier_return_identification_labels.created_by,
             asked_supplier_return_identification_labels.created_at
      FROM asked_supplier_return_identification_labels
      WHERE (asked_supplier_return_identification_labels.created_by::text <> ALL
             (ARRAY ['Operations'::character varying::text, 'Retailer (by API)'::character varying::text]))
        AND asked_supplier_return_identification_labels.created_at <>
            asked_supplier_return_identification_labels.file_registered_at
      UNION ALL
      SELECT 'return_identification_label_file_registration'::text AS text,
             asked_supplier_return_identification_labels.file_registered_by,
             asked_supplier_return_identification_labels.file_registered_at
      FROM asked_supplier_return_identification_labels
      WHERE (asked_supplier_return_identification_labels.file_registered_by::text <> ALL
             (ARRAY ['Operations'::character varying::text, 'Retailer (by API)'::character varying::text]))
        AND asked_supplier_return_identification_labels.file_registered_at IS NOT NULL
      UNION ALL
      SELECT 'return_ship_label_transmission'::text AS text,
             return_ship_label_planned_transmissions.transmitted_by,
             return_ship_label_planned_transmissions.transmitted_at
      FROM return_ship_label_planned_transmissions
      WHERE return_ship_label_planned_transmissions.transmitted_by::text <> 'Operations'::text
        AND return_ship_label_planned_transmissions.transmitted_at IS NOT NULL) action(action_type, created_by, created_at);

alter table ops_actions
    owner to master;

grant select on ops_actions to accounting;

grant select on ops_actions to ro;

grant delete, insert, select, update on ops_actions to rw;

grant select on ops_actions to epsio_user;

