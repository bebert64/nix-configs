create function display_date(date_time timestamp with time zone, time_zone text, use_short_format boolean) returns text
    language plpgsql
as
$$
DECLARE
	date_time_in_time_zone timestamp with time zone;
	date_time_in_time_zone_plus_1_day timestamp with time zone;
	date_time_in_time_zone_minus_1_day timestamp with time zone;
	doy_of_date_time_in_time_zone_plus_1_day numeric;
	doy_of_date_time_in_time_zone_minus_1_day numeric;

	now_in_time_zone timestamp with time zone;
	doy_of_now_in_time_zone numeric;
	year_of_now_in_time_zone numeric;

	is_same_year boolean;
	is_yesterday boolean;
	is_tomorrow boolean;
BEGIN
	date_time_in_time_zone := date_time at time zone time_zone;
	date_time_in_time_zone_plus_1_day := date_time_in_time_zone + '1 day'::interval;
	date_time_in_time_zone_minus_1_day := date_time_in_time_zone - '1 day'::interval;
	doy_of_date_time_in_time_zone_plus_1_day := extract(doy FROM date_time_in_time_zone_plus_1_day);
	doy_of_date_time_in_time_zone_minus_1_day := extract(doy FROM date_time_in_time_zone_minus_1_day);

	now_in_time_zone := now() at time zone time_zone;
	doy_of_now_in_time_zone := extract( doy FROM now_in_time_zone);
	year_of_now_in_time_zone := extract( year FROM now_in_time_zone);

	is_same_year := year_of_now_in_time_zone = extract(year FROM date_time_in_time_zone);
	is_yesterday := (is_same_year AND doy_of_now_in_time_zone = doy_of_date_time_in_time_zone_plus_1_day)
		OR (year_of_now_in_time_zone = extract(year FROM date_time_in_time_zone_plus_1_day)
			AND doy_of_date_time_in_time_zone_plus_1_day = 1 AND doy_of_now_in_time_zone = 1);
	is_tomorrow := (is_same_year AND doy_of_now_in_time_zone = doy_of_date_time_in_time_zone_minus_1_day)
		OR (year_of_now_in_time_zone = extract(year FROM date_time_in_time_zone_minus_1_day) AND doy_of_now_in_time_zone = 1);

	CASE
		WHEN is_yesterday AND use_short_format
			THEN return 'Ytd';
		WHEN is_yesterday AND NOT use_short_format
			THEN return 'Yesterday';
		WHEN doy_of_now_in_time_zone = extract(doy FROM date_time_in_time_zone)
			THEN return 'Today';
		WHEN is_tomorrow AND use_short_format
			THEN return 'Tmw';
		WHEN is_tomorrow AND NOT use_short_format
			THEN return 'Tomorrow';
		WHEN is_same_year AND use_short_format
			THEN return to_char(date_time_in_time_zone, 'MM/DD');
		WHEN is_same_year AND NOT use_short_format
			THEN return to_char(date_time_in_time_zone, 'MonthDD');
		ELSE
			return to_char(date_time_in_time_zone, 'YYYY/MM/DD');
	END CASE;
END;
$$;

alter function display_date(timestamp with time zone, text, boolean) owner to master;

