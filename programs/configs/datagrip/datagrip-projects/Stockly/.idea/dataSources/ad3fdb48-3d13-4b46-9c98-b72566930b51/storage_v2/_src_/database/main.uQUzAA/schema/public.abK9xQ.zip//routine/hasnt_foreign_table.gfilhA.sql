create function hasnt_foreign_table(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _rexists( 'f', $1 ), $2 );
$$;

alter function hasnt_foreign_table(name, text) owner to rdsadmin;

