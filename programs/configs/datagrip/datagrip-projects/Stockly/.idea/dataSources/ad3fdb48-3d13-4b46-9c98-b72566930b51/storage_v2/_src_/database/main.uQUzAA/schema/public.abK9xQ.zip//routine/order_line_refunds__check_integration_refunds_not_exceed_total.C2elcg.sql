create function order_line_refunds__check_integration_refunds_not_exceed_total() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (order_line_refunds__integration_refunds_exceed_total(NEW.order_line_id)) THEN
		RAISE EXCEPTION 'Integration refunds of order_line % exceed total (order_line_refund trigger)', NEW.order_line_id;
	END IF;
	RETURN NULL;
END
$$;

alter function order_line_refunds__check_integration_refunds_not_exceed_total() owner to master;

