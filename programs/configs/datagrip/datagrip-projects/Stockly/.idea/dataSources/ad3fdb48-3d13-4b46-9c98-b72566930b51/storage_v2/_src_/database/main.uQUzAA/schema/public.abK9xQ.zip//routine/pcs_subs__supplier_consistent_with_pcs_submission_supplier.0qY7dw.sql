create function pcs_subs__supplier_consistent_with_pcs_submission_supplier() returns trigger
    language plpgsql
as
$$
BEGIN
	IF purchases__supplier_inconsistent_with_pcs_submission (NULL, NULL, NEW.id) THEN
		RAISE EXCEPTION 'pcs_subs__supplier_consistent_with_pcs_submission_supplier';
	END IF;
	RETURN NULL;
END
$$;

alter function pcs_subs__supplier_consistent_with_pcs_submission_supplier() owner to master;

