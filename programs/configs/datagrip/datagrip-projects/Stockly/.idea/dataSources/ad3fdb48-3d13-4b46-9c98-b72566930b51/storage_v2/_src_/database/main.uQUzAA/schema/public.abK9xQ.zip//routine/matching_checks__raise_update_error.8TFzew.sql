create function matching_checks__raise_update_error() returns trigger
    language plpgsql
as
$$
BEGIN
	RAISE
		'Can''t update order_line_id or purchase_id on matching_checks table'
	USING
		ERRCODE = 'check_violation',
		CONSTRAINT = 'matching_checks__prevent_update',
		TABLE = 'matching_checks';
END
$$;

alter function matching_checks__raise_update_error() owner to master;

