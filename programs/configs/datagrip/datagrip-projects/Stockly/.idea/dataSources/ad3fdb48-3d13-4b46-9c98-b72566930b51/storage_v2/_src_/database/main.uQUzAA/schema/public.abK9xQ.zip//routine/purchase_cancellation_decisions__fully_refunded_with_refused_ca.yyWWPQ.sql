create function purchase_cancellation_decisions__fully_refunded_with_refused_ca() returns trigger
    language plpgsql
as
$$
BEGIN
    IF purchase_fully_refunded_with_refused_cancellation(NULL, NULL, NEW.id)
	THEN
		RAISE EXCEPTION 'purchase_cancellation_decisions__fully_refunded_with_refused_cancellation FAILED';
	END IF;
    RETURN NULL;
END
$$;

alter function purchase_cancellation_decisions__fully_refunded_with_refused_ca() owner to master;

