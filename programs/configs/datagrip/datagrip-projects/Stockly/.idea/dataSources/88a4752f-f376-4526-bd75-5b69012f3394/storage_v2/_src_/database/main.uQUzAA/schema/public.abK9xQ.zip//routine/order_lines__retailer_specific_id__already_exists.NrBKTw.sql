create function order_lines__retailer_specific_id__already_exists(arg_retailer_specific_id character varying) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val boolean := FALSE;
BEGIN
	SELECT
		INTO ret_val EXISTS (
			SELECT
				COUNT(*) AS count
			FROM
				"order_lines" ol
				INNER JOIN "order_shippings" os ON os.id = ol.order_shipping_id
				INNER JOIN "orders" o ON o.id = os.order_id
				INNER JOIN "demander_persons" dp ON dp.id = o.owner_id
			WHERE (ol.retailer_specific_id = arg_retailer_specific_id
				OR arg_retailer_specific_id IS NULL)
		GROUP BY
			ol.retailer_specific_id,
			dp.demander_id
		HAVING
			COUNT(*) > 1);
	RETURN ret_val;
END
$$;

alter function order_lines__retailer_specific_id__already_exists(varchar) owner to master;

