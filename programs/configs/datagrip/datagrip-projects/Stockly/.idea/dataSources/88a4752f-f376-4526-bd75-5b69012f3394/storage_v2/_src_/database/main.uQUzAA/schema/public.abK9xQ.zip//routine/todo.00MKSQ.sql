create function todo(how_many integer) returns SETOF boolean
    language plpgsql
as
$$
BEGIN
    PERFORM _add('todo', COALESCE(how_many, 1), '');
    RETURN;
END;
$$;

alter function todo(integer) owner to rdsadmin;

