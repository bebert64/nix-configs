create function order_shipping_refunds__integration_refunds_exceed_total(arg_order_shipping_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS(
		SELECT *
		FROM (
			SELECT SUM(osr.price_et) - os.client_price_et AS refunds_diff
			FROM
				order_shipping_refunds osr
				INNER JOIN order_shippings os ON (
					os.id = osr.order_shipping_id
					AND osr.retailer_specific_id IS NOT NULL
				)
				WHERE
					osr.order_shipping_id = arg_order_shipping_id
					OR arg_order_shipping_id IS NULL
				GROUP BY
					osr.order_shipping_id, os.client_price_et
		) refunds_diffs
		WHERE
			refunds_diff > 1e-9
	);
	RETURN ret_val;
END
$$;

alter function order_shipping_refunds__integration_refunds_exceed_total(integer) owner to master;

