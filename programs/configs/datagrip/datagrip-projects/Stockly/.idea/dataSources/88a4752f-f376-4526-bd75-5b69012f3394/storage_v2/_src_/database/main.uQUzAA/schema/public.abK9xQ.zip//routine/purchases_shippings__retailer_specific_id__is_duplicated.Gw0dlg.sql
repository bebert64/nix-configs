create function purchases_shippings__retailer_specific_id__is_duplicated(arg_supplier_id integer, arg_retailer_specific_id character varying) returns boolean
    language plpgsql
as
$$
BEGIN
	IF arg_retailer_specific_id IS NULL OR arg_supplier_id IS NULL THEN
		RAISE not_null_violation USING MESSAGE = 'Arguments passed to this function must not be NULL';
	END IF;
	RETURN
		(SELECT COUNT(*)
		FROM
			"purchases_shippings" pship
			INNER JOIN "purchases_submissions" psub ON pship.submission_id = psub.id
			WHERE pship.retailer_specific_id = arg_retailer_specific_id
			AND psub.supplier_id = arg_supplier_id) > 1;
END
$$;

alter function purchases_shippings__retailer_specific_id__is_duplicated(integer, varchar) owner to master;

