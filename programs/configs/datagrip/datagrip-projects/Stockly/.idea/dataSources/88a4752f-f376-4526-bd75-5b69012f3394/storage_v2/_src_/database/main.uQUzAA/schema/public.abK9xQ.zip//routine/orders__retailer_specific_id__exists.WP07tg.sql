create function orders__retailer_specific_id__exists(arg_retailer_specific_id character varying, arg_demander_consumer_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT
			*
		FROM
			"orders" old_o
			INNER JOIN
				"demander_consumers" old_dc
			ON
				old_dc.id = old_o.demander_consumer_id
			INNER JOIN
				"demander_consumers" new_dc
			ON
				new_dc.id = arg_demander_consumer_id
		WHERE
			old_dc.retailer_id = new_dc.retailer_id
			AND old_o.retailer_specific_id = arg_retailer_specific_id
	);

	RETURN ret_val;
END
$$;

alter function orders__retailer_specific_id__exists(varchar, integer) owner to master;

