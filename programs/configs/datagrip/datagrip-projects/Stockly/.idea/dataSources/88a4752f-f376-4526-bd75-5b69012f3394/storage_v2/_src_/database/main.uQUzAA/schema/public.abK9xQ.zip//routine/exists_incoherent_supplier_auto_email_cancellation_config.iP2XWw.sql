create function exists_incoherent_supplier_auto_email_cancellation_config(arg_supplier_id integer, arg_supplier_messages_config_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT
			*
		FROM
			"suppliers" s
		LEFT JOIN
			"automated_supplier_messages_configs" asmc
		ON s.automated_messages_config_id = asmc.id
		WHERE
			asmc.action__cancel_to_supplier IS NULL
			AND s.auto_stockly_cancellation_method = 'email'
			AND ("arg_supplier_id" IS NULL OR "arg_supplier_id" = s.retailer_id)
			AND ("arg_supplier_messages_config_id" IS NULL OR "arg_supplier_messages_config_id" = asmc.id)
	);
	RETURN ret_val;
END
$$;

alter function exists_incoherent_supplier_auto_email_cancellation_config(integer, integer) owner to master;

