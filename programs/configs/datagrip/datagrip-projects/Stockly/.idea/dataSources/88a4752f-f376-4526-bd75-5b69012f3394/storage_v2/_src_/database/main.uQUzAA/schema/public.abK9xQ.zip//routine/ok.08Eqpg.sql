create function ok(boolean) returns text
    language sql
as
$$
    SELECT ok( $1, NULL );
$$;

alter function ok(boolean) owner to rdsadmin;

