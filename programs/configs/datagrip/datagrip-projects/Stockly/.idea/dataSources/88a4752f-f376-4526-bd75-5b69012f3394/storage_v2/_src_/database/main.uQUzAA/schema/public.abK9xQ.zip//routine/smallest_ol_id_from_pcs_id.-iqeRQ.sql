create function smallest_ol_id_from_pcs_id(pcs_id integer) returns integer
    language plpgsql
as
$$ BEGIN
    RETURN (
        SELECT
            MIN(ol.id)
        FROM
            order_lines ol
            INNER JOIN order_shippings os ON os.id = ol.order_shipping_id
            INNER JOIN orders o ON o.id = os.order_id
        WHERE
            ol.purchase_id = pcs_id
    );
END; $$;

alter function smallest_ol_id_from_pcs_id(integer) owner to rw;

