create function test_purchases__order_line_is_bound_to_test_purchase() returns trigger
    language plpgsql
as
$$
BEGIN
	IF order_line_is_bound_to_test_purchase(NULL, NEW.purchase_id) THEN
		RAISE 'Order line should not be bound to test purchase %s', NEW.purchase_id
		USING ERRCODE = 'integrity_constraint_violation', CONSTRAINT = 'order_line_is_bound_to_test_purchase', TABLE = 'test_purchases';
	END IF;
		RETURN NULL;
END
$$;

alter function test_purchases__order_line_is_bound_to_test_purchase() owner to master;

