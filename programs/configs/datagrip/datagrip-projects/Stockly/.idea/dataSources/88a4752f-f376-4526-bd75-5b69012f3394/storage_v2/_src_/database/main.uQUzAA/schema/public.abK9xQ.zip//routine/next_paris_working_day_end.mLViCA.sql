create function next_paris_working_day_end(start_dt timestamp with time zone) returns timestamp with time zone
    language plpgsql
as
$$
BEGIN RETURN next_time_occurrence(start_dt, 'Europe/Paris', 18, 30, '{6, 7}'); END;
$$;

alter function next_paris_working_day_end(timestamp with time zone) owner to master;

