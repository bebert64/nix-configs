create function orders__check_unique_rsid_for_demander() returns trigger
    language plpgsql
as
$$
BEGIN
	IF orders__retailer_specific_id__already_exists(NEW.id, NEW.retailer_specific_id, NEW.owner_id) THEN
		RAISE 'Order RSID (%) already exists for demander linked to owner_id (%)', NEW.retailer_specific_id, NEW.owner_id
		USING
			ERRCODE = 'unique_violation',
			CONSTRAINT = 'orders__check_unique_rsid_for_demander',
			TABLE = 'orders';
	END IF;
	RETURN NULL;
END
$$;

alter function orders__check_unique_rsid_for_demander() owner to master;

