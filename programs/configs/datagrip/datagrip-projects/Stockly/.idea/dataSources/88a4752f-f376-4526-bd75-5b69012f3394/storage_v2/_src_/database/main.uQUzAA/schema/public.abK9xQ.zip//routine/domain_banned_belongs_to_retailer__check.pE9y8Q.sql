create function domain_banned_belongs_to_retailer__check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (domain_banned_belongs_to_retailer(NEW.domain)) THEN
		RAISE EXCEPTION 'domain_banned_is_a_retailer_domain';
	END IF;
	RETURN NULL;
END
$$;

alter function domain_banned_belongs_to_retailer__check() owner to master;

