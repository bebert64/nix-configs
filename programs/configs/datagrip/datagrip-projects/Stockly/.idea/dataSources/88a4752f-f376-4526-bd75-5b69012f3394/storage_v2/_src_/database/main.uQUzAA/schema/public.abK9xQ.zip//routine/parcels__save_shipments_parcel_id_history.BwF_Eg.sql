create function parcels__save_shipments_parcel_id_history() returns trigger
    language plpgsql
as
$$
BEGIN
	IF(NEW.shipments_parcel_id IS DISTINCT FROM OLD.shipments_parcel_id) THEN
		INSERT INTO parcels_shipments_parcel_id_history(
			parcel_id,
			previous_shipments_parcel_id,
			previously_updated_by,
			previously_updated_at
		)
		VALUES(
			OLD.id,
			OLD.shipments_parcel_id,
			OLD.shipments_parcel_updated_by,
			OLD.shipments_parcel_updated_at
		);
	END IF;
	RETURN NULL;
END;
$$;

alter function parcels__save_shipments_parcel_id_history() owner to master;

