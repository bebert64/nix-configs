create function order_line_refunds__integration_refunds_exceed_total(arg_order_line_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS(
		SELECT *
		FROM (
			SELECT SUM(olr.price_et + olr.extra_shipping_price_et) - (ol.client_price_et + ol.client_extra_shipping_price_et) AS refunds_diff
			FROM
				order_line_refunds olr
				INNER JOIN ordeR_lines ol ON (
					ol.id = olr.order_line_id
					AND olr.retailer_specific_id IS NOT NULL
				)
				WHERE
					olr.order_line_id = arg_order_line_id
					OR arg_order_line_id IS NULL
				GROUP BY
					olr.order_line_id, ol.client_price_et, ol.client_extra_shipping_price_et
		) refunds_diffs
		WHERE
			refunds_diff > 1e-9
	);
	RETURN ret_val;
END
$$;

alter function order_line_refunds__integration_refunds_exceed_total(integer) owner to master;

