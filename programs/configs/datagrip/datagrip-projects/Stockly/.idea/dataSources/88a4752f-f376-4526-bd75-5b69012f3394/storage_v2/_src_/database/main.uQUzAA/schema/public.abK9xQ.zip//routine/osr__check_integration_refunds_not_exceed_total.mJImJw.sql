create function osr__check_integration_refunds_not_exceed_total() returns trigger
    language plpgsql
as
$$
BEGIN
	IF order_shipping_refunds__integration_refunds_exceed_total(NEW.order_shipping_id) THEN
		RAISE 'The refund of (%) ET (in addition to eventual already existing integration refunds) is exceeding total price for order shipping (%)', NEW.price_et, NEW.order_shipping_id
			USING ERRCODE = 'invalid_parameter_value', CONSTRAINT =
					'osr__check_integration_refunds_not_exceed_total', TABLE = 'order_shipping_refunds';
	END IF;
	RETURN NULL;
END
$$;

alter function osr__check_integration_refunds_not_exceed_total() owner to master;

