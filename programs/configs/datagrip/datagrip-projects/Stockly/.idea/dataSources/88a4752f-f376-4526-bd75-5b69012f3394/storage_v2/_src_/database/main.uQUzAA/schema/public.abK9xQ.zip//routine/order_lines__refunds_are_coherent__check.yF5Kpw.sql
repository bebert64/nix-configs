create function order_lines__refunds_are_coherent__check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (exists_incoherent_order_line_refund(NEW.id, NULL)) THEN
		RAISE EXCEPTION 'order_lines__refunds_are_coherent__check FAILED';
	END IF;
	RETURN NULL;
END
$$;

alter function order_lines__refunds_are_coherent__check() owner to master;

