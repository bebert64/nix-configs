create function pc__not_rejected_cancellation_already_exists(arg_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT * FROM
			"purchase_cancellations" pc
			LEFT JOIN "purchase_cancellation_decisions" pcd ON pcd.purchase_cancellation_id = pc.id
		WHERE
			pc.id != arg_id
			AND pcd.accepted = TRUE
	);

	RETURN ret_val;
END
$$;

alter function pc__not_rejected_cancellation_already_exists(integer) owner to master;

