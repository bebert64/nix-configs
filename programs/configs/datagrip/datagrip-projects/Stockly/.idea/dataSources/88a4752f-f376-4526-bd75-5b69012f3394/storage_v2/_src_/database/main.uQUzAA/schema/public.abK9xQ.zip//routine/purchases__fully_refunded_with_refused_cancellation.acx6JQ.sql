create function purchases__fully_refunded_with_refused_cancellation() returns trigger
    language plpgsql
as
$$
BEGIN
	IF purchase_fully_refunded_with_refused_cancellation(NEW.id, NULL, NULL)
	THEN
		RAISE EXCEPTION 'purchases__fully_refunded_with_refused_cancellation FAILED';
	END IF;
    RETURN NULL;
END
$$;

alter function purchases__fully_refunded_with_refused_cancellation() owner to master;

