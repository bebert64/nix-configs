create function purchases__save_public_price_et_history() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NEW.id != OLD.id) THEN
		RAISE EXCEPTION '% You can''t change a purchase ID', NEW.id;
	END IF;
	IF NEW.public_price_et IS DISTINCT FROM OLD.public_price_et THEN
		INSERT INTO purchases_public_price_et_history (purchase_id, previous_public_price_et)
			VALUES (OLD.id, OLD.public_price_et);
	END IF;
	RETURN NULL;
END;
$$;

alter function purchases__save_public_price_et_history() owner to master;

