create function domain_banned_belongs_to_retailer(arg_domain character varying) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT
			*
		FROM
			banned_domains bd
		INNER JOIN retailer_domains rd ON rd.domain=bd.domain
		WHERE
			bd.domain="arg_domain"
	);
	RETURN ret_val;
END
$$;

alter function domain_banned_belongs_to_retailer(varchar) owner to master;

