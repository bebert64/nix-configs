create function unialike(anyelement, text, text) returns text
    language sql
as
$$
    SELECT _unalike( $1 !~~* $2, $1, $2, $3 );
$$;

alter function unialike(anyelement, text, text) owner to rdsadmin;

