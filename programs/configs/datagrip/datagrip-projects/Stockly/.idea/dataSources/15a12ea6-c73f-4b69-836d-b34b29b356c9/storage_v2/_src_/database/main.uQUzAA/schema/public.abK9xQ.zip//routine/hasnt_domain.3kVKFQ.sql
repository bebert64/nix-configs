create function hasnt_domain(name, name) returns text
    language sql
as
$$
    SELECT hasnt_domain( $1, $2, 'Domain ' || quote_ident($1) || '.' || quote_ident($2) || ' should not exist' );
$$;

alter function hasnt_domain(name, name) owner to rdsadmin;

