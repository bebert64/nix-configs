create function hasnt_schema(name) returns text
    language sql
as
$$
    SELECT hasnt_schema( $1, 'Schema ' || quote_ident($1) || ' should not exist' );
$$;

alter function hasnt_schema(name) owner to rdsadmin;

