create function has_cast(name, name) returns text
    language sql
as
$$
    SELECT ok(
        _cast_exists( $1, $2 ),
        'Cast (' || quote_ident($1) || ' AS ' || quote_ident($2)
        || ') should exist'
    );
$$;

alter function has_cast(name, name) owner to rdsadmin;

