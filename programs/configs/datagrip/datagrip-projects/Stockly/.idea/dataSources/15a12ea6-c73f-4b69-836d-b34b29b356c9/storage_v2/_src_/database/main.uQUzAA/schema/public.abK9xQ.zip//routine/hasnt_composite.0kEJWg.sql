create function hasnt_composite(name) returns text
    language sql
as
$$
    SELECT hasnt_composite( $1, 'Composite type ' || quote_ident($1) || ' should not exist' );
$$;

alter function hasnt_composite(name) owner to rdsadmin;

