create function has_fk(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _hasc( $1, $2, 'f' ), $3 );
$$;

alter function has_fk(name, name, text) owner to rdsadmin;

