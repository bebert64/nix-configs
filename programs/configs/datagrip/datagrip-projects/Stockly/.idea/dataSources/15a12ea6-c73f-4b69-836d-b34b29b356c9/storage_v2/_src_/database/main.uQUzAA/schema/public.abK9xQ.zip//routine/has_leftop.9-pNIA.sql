create function has_leftop(name, name, name) returns text
    language sql
as
$$
    SELECT ok(
         _op_exists(NULL, $1, $2, $3 ),
        'Left operator ' || $1 || '(NONE,' || $2 || ') RETURNS ' || $3 || ' should exist'
    );
$$;

alter function has_leftop(name, name, name) owner to rdsadmin;

