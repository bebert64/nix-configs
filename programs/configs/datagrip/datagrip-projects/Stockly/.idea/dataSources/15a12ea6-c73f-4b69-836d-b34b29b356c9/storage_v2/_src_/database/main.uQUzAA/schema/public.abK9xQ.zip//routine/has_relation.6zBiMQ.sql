create function has_relation(name) returns text
    language sql
as
$$
    SELECT has_relation( $1, 'Relation ' || quote_ident($1) || ' should exist' );
$$;

alter function has_relation(name) owner to rdsadmin;

