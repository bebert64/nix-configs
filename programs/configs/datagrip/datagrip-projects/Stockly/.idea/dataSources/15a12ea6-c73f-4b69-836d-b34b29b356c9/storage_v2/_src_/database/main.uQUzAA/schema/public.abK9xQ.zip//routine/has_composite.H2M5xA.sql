create function has_composite(name, text) returns text
    language sql
as
$$
    SELECT ok( _rexists( 'c', $1 ), $2 );
$$;

alter function has_composite(name, text) owner to rdsadmin;

