create function has_sequence(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _rexists( 'S', $1, $2 ), $3 );
$$;

alter function has_sequence(name, name, text) owner to rdsadmin;

