create function _has_group(name) returns boolean
    strict
    language sql
as
$$
    SELECT EXISTS(
        SELECT true
          FROM pg_catalog.pg_group
         WHERE groname = $1
    );
$$;

alter function _has_group(name) owner to rdsadmin;

