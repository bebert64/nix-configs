create function collect_tap(character varying[]) returns text
    language sql
as
$$
    SELECT array_to_string($1, E'\n');
$$;

alter function collect_tap(character varying[]) owner to rdsadmin;

