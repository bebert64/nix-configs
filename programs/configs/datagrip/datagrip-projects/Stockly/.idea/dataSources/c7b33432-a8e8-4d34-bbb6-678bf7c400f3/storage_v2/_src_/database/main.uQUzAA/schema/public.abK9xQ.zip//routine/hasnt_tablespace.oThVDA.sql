create function hasnt_tablespace(name) returns text
    language sql
as
$$
    SELECT hasnt_tablespace( $1, 'Tablespace ' || quote_ident($1) || ' should not exist' );
$$;

alter function hasnt_tablespace(name) owner to rdsadmin;

