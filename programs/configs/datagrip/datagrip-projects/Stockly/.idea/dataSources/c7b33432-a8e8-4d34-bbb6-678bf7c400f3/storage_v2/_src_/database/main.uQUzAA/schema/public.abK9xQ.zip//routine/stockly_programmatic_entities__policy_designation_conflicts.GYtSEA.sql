create function stockly_programmatic_entities__policy_designation_conflicts() returns trigger
    language plpgsql
as
$$
BEGIN
	IF stockly_programmatic_entities__domain_conflicts_with_pol_dsgntn(NEW.entity_id) THEN
		RAISE 'Policy designation conflicts with stockly programmatic entity domain (%)', NEW.domain
		USING ERRCODE = 'unique_violation', CONSTRAINT = 'stockly_programmatic_entities__policy_designation_conflicts', TABLE = 'stockly_programmatic_entities';
	END IF;
		RETURN NULL;
END
$$;

alter function stockly_programmatic_entities__policy_designation_conflicts() owner to master;

