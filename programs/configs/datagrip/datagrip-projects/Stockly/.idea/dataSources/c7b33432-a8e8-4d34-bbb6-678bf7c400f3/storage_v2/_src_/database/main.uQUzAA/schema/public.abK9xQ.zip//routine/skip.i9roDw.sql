create function skip(text) returns text
    language sql
as
$$
    SELECT ok( TRUE ) || ' ' || diag( 'SKIP' || COALESCE(' ' || $1, '') );
$$;

alter function skip(text) owner to rdsadmin;

