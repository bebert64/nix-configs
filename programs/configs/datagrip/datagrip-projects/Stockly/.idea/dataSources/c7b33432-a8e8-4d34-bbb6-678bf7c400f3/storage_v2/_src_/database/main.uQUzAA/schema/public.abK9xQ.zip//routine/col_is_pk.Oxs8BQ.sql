create function col_is_pk(name, name, name) returns text
    language sql
as
$$
    SELECT col_is_pk( $1, $2, $3, 'Column ' || quote_ident($1) || '.' || quote_ident($2) || '(' || quote_ident($3) || ') should be a primary key' );
$$;

alter function col_is_pk(name, name, name) owner to rdsadmin;

