create function has_index(name, name, name, text) returns text
    language sql
as
$$
    SELECT CASE WHEN _is_schema( $1 ) THEN
        -- Looking for schema.table index.
            ok ( _have_index( $1, $2, $3 ), $4)
        ELSE
        -- Looking for particular columns.
            has_index( $1, $2, ARRAY[$3], $4 )
      END;
$$;

alter function has_index(name, name, name, text) owner to rdsadmin;

