create function function_returns(name, text, text) returns text
    language sql
as
$$
    SELECT _func_compare(NULL, $1, _returns($1), _retval($2), $3 );
$$;

alter function function_returns(name, text, text) owner to romain;

