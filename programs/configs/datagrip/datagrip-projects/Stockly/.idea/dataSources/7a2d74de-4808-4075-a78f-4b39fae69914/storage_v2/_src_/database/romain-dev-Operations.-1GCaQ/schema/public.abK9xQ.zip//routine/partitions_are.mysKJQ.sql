create function partitions_are(name, name[]) returns text
    language sql
as
$$
    SELECT partitions_are(
        $1, $2,
        'Table ' || quote_ident($1) || ' should have the correct partitions'
    );
$$;

alter function partitions_are(name, name[]) owner to romain;

