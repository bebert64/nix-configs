create function domains_are(name[]) returns text
    language sql
as
$$
    SELECT _types_are( $1, 'Search path ' || pg_catalog.current_setting('search_path') || ' should have the correct domains', ARRAY['d'] );
$$;

alter function domains_are(name[]) owner to romain;

