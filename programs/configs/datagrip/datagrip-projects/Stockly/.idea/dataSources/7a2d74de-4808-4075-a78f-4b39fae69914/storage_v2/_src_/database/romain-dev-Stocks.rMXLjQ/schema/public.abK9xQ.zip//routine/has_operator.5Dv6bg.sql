create function has_operator(name, name, name, name) returns text
    language sql
as
$$
    SELECT ok(
         _op_exists($1, $2, $3, $4 ),
        'Operator ' ||  $2 || '(' || $1 || ',' || $3
        || ') RETURNS ' || $4 || ' should exist'
    );
$$;

alter function has_operator(name, name, name, name) owner to romain;

