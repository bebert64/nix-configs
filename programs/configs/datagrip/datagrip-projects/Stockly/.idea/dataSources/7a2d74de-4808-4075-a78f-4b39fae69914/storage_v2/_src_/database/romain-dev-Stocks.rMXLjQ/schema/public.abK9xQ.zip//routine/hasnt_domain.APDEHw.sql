create function hasnt_domain(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _has_type( $1, ARRAY['d'] ), $2 );
$$;

alter function hasnt_domain(name, text) owner to romain;

