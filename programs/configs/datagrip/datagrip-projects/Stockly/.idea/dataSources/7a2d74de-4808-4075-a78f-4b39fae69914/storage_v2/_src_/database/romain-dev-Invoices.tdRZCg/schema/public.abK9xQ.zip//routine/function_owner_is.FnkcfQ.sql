create function function_owner_is(name, name, name[], name) returns text
    language sql
as
$$
    SELECT function_owner_is(
        $1, $2, $3, $4,
        'Function ' || quote_ident($1) || '.' || quote_ident($2) || '(' ||
        array_to_string($3, ', ') || ') should be owned by ' || quote_ident($4)
    );
$$;

alter function function_owner_is(name, name, name[], name) owner to romain;

