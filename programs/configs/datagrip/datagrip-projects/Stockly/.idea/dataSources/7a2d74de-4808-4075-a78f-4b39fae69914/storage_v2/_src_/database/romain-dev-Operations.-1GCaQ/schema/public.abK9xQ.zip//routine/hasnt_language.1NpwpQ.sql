create function hasnt_language(name, text) returns text
    language sql
as
$$
    SELECT ok( _is_trusted($1) IS NULL, $2 );
$$;

alter function hasnt_language(name, text) owner to romain;

