create function is_procedure(name) returns text
    language sql
as
$$
    SELECT _func_compare(
        NULL, $1, _type_func('p', $1),
        'Function ' || quote_ident($1) || '() should be a procedure'
    );
$$;

alter function is_procedure(name) owner to romain;

