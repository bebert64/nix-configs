create function opclasses_are(name[]) returns text
    language sql
as
$$
    SELECT opclasses_are( $1, 'Search path ' || pg_catalog.current_setting('search_path') || ' should have the correct operator classes' );
$$;

alter function opclasses_are(name[]) owner to romain;

