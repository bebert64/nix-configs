create function isa_ok(anyelement, regtype) returns text
    language sql
as
$$
    SELECT isa_ok($1, $2, 'the value');
$$;

alter function isa_ok(anyelement, regtype) owner to romain;

