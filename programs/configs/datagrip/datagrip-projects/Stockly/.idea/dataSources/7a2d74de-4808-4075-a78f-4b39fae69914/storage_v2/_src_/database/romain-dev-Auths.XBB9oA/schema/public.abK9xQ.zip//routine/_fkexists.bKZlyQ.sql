create function _fkexists(name, name, name[]) returns boolean
    language sql
as
$$
    SELECT EXISTS(
        SELECT TRUE
           FROM pg_all_foreign_keys
          WHERE fk_schema_name    = $1
            AND quote_ident(fk_table_name)     = quote_ident($2)
            AND fk_columns = $3
    );
$$;

alter function _fkexists(name, name, name[]) owner to romain;

