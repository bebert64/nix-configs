create function _get_schema_owner(name) returns name
    language sql
as
$$
    SELECT pg_catalog.pg_get_userbyid(nspowner)
      FROM pg_catalog.pg_namespace
     WHERE nspname = $1;
$$;

alter function _get_schema_owner(name) owner to romain;

