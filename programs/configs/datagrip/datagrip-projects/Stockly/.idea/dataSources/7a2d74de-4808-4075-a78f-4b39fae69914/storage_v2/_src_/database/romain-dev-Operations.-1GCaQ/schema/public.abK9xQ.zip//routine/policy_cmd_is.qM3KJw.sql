create function policy_cmd_is(name, name, text) returns text
    language sql
as
$$
    SELECT policy_cmd_is(
        $1, $2, $3,
        'Policy ' || quote_ident($2)
        || ' for table ' || quote_ident($1)
        || ' should apply to ' || upper($3) || ' command'
    );
$$;

alter function policy_cmd_is(name, name, text) owner to romain;

