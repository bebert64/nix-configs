create function invoices__check_no_generation_format_has_file() returns trigger
    language plpgsql
as
$$
BEGIN
	IF NOT invoices__no_generation_format_has_file(NEW.id) THEN
		RAISE EXCEPTION 'invoices__check_no_generation_format_has_file';
	END IF;
	RETURN NULL;
END
$$;

alter function invoices__check_no_generation_format_has_file() owner to romain;

