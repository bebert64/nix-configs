create function purchases_shippings__check_unique_rsid_for_supplier() returns trigger
    language plpgsql
as
$$
DECLARE
	supplier_id INTEGER;
BEGIN
	SELECT psub.supplier_id INTO supplier_id FROM purchases_submissions psub WHERE id = NEW.submission_id;

	IF purchases_shippings__retailer_specific_id__is_duplicated(supplier_id, NEW.retailer_specific_id) THEN
		RAISE 'purchases_shipping RSID (%) already exists for supplier_id %', NEW.retailer_specific_id, supplier_id
		USING ERRCODE = 'unique_violation', CONSTRAINT = 'purchases_shippings__retailer_specific_id__already_exists', TABLE = 'purchases_shippings';
	END IF;

	RETURN NULL;
END
$$;

alter function purchases_shippings__check_unique_rsid_for_supplier() owner to romain;

