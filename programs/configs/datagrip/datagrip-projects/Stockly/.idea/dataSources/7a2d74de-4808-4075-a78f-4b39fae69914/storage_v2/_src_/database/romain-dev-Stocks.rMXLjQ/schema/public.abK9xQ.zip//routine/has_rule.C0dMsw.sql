create function has_rule(name, name, name) returns text
    language sql
as
$$
    SELECT ok( _is_instead($1, $2, $3) IS NOT NULL, 'Relation ' || quote_ident($1) || '.' || quote_ident($2) || ' should have rule ' || quote_ident($3) );
$$;

alter function has_rule(name, name, name) owner to romain;

