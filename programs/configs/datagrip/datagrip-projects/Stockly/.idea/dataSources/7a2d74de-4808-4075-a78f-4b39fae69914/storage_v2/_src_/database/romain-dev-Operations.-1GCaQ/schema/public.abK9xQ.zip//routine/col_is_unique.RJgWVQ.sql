create function col_is_unique(name, name[]) returns text
    language sql
as
$$
    SELECT col_is_unique( $1, $2, 'Columns ' || quote_ident($1) || '(' || _ident_array_to_string($2, ', ') || ') should have a unique constraint' );
$$;

alter function col_is_unique(name, name[]) owner to romain;

