create function _nosuch(name, name, name[]) returns text
    immutable
    language sql
as
$$
    SELECT E'\n' || diag(
        '    Function '
          || CASE WHEN $1 IS NOT NULL THEN quote_ident($1) || '.' ELSE '' END
          || quote_ident($2) || '('
          || array_to_string($3, ', ') || ') does not exist'
    );
$$;

alter function _nosuch(name, name, name[]) owner to romain;

