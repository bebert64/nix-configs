create function enum_has_labels(name, name[]) returns text
    language sql
as
$$
    SELECT enum_has_labels(
        $1, $2,
        'Enum ' || quote_ident($1) || ' should have labels (' || array_to_string( $2, ', ' ) || ')'
    );
$$;

alter function enum_has_labels(name, name[]) owner to romain;

