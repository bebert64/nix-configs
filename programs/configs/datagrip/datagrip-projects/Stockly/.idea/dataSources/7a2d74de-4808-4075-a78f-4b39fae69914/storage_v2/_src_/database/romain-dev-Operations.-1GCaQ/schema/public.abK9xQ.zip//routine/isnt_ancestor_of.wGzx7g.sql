create function isnt_ancestor_of(name, name, name, name, text) returns text
    language sql
as
$$
    SELECT ok( NOT  _ancestor_of( $1, $2, $3, $4, NULL ), $5 );
$$;

alter function isnt_ancestor_of(name, name, name, name, text) owner to romain;

