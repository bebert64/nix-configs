create function groups_are(name[]) returns text
    language sql
as
$$
    SELECT groups_are( $1, 'There should be the correct groups' );
$$;

alter function groups_are(name[]) owner to romain;

