create function hasnt_leftop(name, name, name, name) returns text
    language sql
as
$$
    SELECT ok(
         NOT _op_exists(NULL, $1, $2, $3, $4 ),
        'Left operator ' || quote_ident($1) || '.' || $2 || '(NONE,'
        || $3 || ') RETURNS ' || $4 || ' should not exist'
    );
$$;

alter function hasnt_leftop(name, name, name, name) owner to romain;

