create function column_privs_are(name, name, name, name[]) returns text
    language sql
as
$$
    SELECT column_privs_are(
        $1, $2, $3, $4,
        'Role ' || quote_ident($3) || ' should be granted '
            || CASE WHEN $4[1] IS NULL THEN 'no privileges' ELSE array_to_string($4, ', ') END
            || ' on column ' || quote_ident($1) || '.' || quote_ident($2)
    );
$$;

alter function column_privs_are(name, name, name, name[]) owner to romain;

