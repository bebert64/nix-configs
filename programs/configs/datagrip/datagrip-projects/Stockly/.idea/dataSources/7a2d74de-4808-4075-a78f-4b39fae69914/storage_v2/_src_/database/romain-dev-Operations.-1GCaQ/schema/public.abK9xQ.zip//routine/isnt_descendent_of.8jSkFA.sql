create function isnt_descendent_of(name, name, text) returns text
    language sql
as
$$
    SELECT ok(NOT  _ancestor_of( $2, $1, NULL ), $3 );
$$;

alter function isnt_descendent_of(name, name, text) owner to romain;

