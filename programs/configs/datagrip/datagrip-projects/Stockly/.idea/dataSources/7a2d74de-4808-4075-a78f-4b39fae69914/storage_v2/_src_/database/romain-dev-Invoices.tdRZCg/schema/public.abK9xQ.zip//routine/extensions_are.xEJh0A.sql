create function extensions_are(name[], text) returns text
    language sql
as
$$
    SELECT _are(
        'extensions',
        ARRAY(SELECT _extensions() EXCEPT SELECT unnest($1)),
        ARRAY(SELECT unnest($1) EXCEPT SELECT _extensions()),
        $2
    );
$$;

alter function extensions_are(name[], text) owner to romain;

