create function companies_check_legal_structure_on_reactivation() returns trigger
    language plpgsql
as
$$
BEGIN
    IF OLD.active_in_stockly_network = FALSE AND NEW.active_in_stockly_network = TRUE THEN
        IF EXISTS (
            SELECT 1
            FROM legal_entities le
            INNER JOIN country_legal_structures cls ON cls.country = le.country_alpha3
            WHERE le.id = NEW.legal_entity_id
            AND cls.legal_structure = NEW.legal_structure
            AND cls.invalidated_at IS NOT NULL
        ) THEN
            RAISE EXCEPTION 'Cannot reactivate company: legal structure "%" is invalidated for this country',
                NEW.legal_structure;
        END IF;
    END IF;

    RETURN NEW;
END;
$$;

alter function companies_check_legal_structure_on_reactivation() owner to romain;

