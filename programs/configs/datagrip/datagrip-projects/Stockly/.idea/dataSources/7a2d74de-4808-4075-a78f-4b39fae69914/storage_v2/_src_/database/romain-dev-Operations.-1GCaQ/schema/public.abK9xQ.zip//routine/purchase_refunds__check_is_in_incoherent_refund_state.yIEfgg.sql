create function purchase_refunds__check_is_in_incoherent_refund_state() returns trigger
    language plpgsql
as
$$
BEGIN
	IF purchases__is_in_incoherent_refund_state(NULL, NULL, NULL, NEW.id) THEN
		RAISE EXCEPTION 'purchase_refunds__check_is_in_incoherent_refund_state';
	END IF;
	RETURN NULL;
END
$$;

alter function purchase_refunds__check_is_in_incoherent_refund_state() owner to romain;

