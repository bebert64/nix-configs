create function fk_ok(name, name[], name, name[]) returns text
    language sql
as
$$
    SELECT fk_ok( $1, $2, $3, $4,
        $1 || '(' || _ident_array_to_string( $2, ', ' )
        || ') should reference ' ||
        $3 || '(' || _ident_array_to_string( $4, ', ' ) || ')'
    );
$$;

alter function fk_ok(name, name[], name, name[]) owner to romain;

