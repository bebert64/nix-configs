create function has_operator(name, name, name, name, text) returns text
    language sql
as
$$
    SELECT ok( _op_exists($1, $2, $3, $4 ), $5 );
$$;

alter function has_operator(name, name, name, name, text) owner to romain;

