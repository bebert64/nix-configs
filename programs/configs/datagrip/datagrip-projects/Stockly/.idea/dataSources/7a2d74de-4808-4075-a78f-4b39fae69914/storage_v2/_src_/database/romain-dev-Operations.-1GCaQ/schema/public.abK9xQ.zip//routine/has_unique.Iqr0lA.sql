create function has_unique(text) returns text
    language sql
as
$$
    SELECT has_unique( $1, 'Table ' || quote_ident($1) || ' should have a unique constraint' );
$$;

alter function has_unique(text) owner to romain;

