create function _get_rel_owner(character[], name, name) returns name
    language sql
as
$$
    SELECT pg_catalog.pg_get_userbyid(c.relowner)
      FROM pg_catalog.pg_class c
      JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
     WHERE c.relkind = ANY($1)
       AND n.nspname = $2
       AND c.relname = $3
$$;

alter function _get_rel_owner(character[], name, name) owner to romain;

