create function bag_hasnt(text, text, text) returns text
    language sql
as
$$
    SELECT _relcomp( $1, $2, $3, 'INTERSECT ALL', 'Extra' );
$$;

alter function bag_hasnt(text, text, text) owner to romain;

