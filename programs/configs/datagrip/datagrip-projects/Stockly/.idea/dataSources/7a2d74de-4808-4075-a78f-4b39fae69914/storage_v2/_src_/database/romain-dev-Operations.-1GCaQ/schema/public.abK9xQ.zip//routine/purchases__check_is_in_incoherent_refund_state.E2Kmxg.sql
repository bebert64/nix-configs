create function purchases__check_is_in_incoherent_refund_state() returns trigger
    language plpgsql
as
$$
BEGIN
	IF purchases__is_in_incoherent_refund_state(NEW.id, NULL, NULL, NULL) THEN
		RAISE EXCEPTION 'purchases__check_is_in_incoherent_refund_state';
	END IF;
	RETURN NULL;
END
$$;

alter function purchases__check_is_in_incoherent_refund_state() owner to romain;

