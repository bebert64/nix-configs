create function has_inherited_tables(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _inherited( $1, $2 ), $3);
$$;

alter function has_inherited_tables(name, name, text) owner to romain;

