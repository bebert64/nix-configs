create function isnt_partitioned(name) returns text
    language sql
as
$$
    SELECT ok(
        NOT _rexists('p', $1),
        'Table ' || quote_ident($1) || ' should not be partitioned'
    );
$$;

alter function isnt_partitioned(name) owner to romain;

