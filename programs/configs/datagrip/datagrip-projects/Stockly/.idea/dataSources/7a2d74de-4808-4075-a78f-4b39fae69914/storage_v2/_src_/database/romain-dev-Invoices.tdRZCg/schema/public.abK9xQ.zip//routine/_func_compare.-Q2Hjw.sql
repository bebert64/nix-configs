create function _func_compare(name, name, boolean, text) returns text
    language sql
as
$$
    SELECT CASE WHEN $3 IS NULL
      THEN ok( FALSE, $4 ) || _nosuch($1, $2, '{}')
      ELSE ok( $3, $4 )
      END;
$$;

alter function _func_compare(name, name, boolean, text) owner to romain;

