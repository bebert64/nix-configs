create function isnt_member_of(name, name[]) returns text
    language sql
as
$$
    SELECT isnt_member_of( $1, $2, 'Should not have members of role ' || quote_ident($1) );
$$;

alter function isnt_member_of(name, name[]) owner to romain;

