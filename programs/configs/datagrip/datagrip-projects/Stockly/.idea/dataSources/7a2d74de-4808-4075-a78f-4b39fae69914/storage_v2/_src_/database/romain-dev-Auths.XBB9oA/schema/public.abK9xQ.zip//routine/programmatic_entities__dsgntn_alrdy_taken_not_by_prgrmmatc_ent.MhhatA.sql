create function programmatic_entities__dsgntn_alrdy_taken_not_by_prgrmmatc_ent() returns trigger
    language plpgsql
as
$$
BEGIN
	IF policies__designation_already_taken_not_by_programmatic_entity(NULL, OLD.entity_id) THEN
		RAISE 'Policy designation (%) already exists created by non-programmatic entity', NEW.designation
		USING ERRCODE = 'unique_violation', CONSTRAINT = 'programmatic_entities__dsgntn_alrdy_taken_not_by_prgrmmatc_ent', TABLE = 'policies';
	END IF;
		RETURN NULL;
END
$$;

alter function programmatic_entities__dsgntn_alrdy_taken_not_by_prgrmmatc_ent() owner to romain;

