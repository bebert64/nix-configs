create function parcels__stockly_pays_et_for_initial_parcel_check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF incoherent_stockly_pays_et_for_initial_parcel(NEW.id, NULL) THEN
		RAISE 'parcel_id = % is initial for a purchase but its stockly_pays_et value is not zero', NEW.id
		USING
			ERRCODE = 'check_violation',
			TABLE = 'parcels';
	END IF;
	RETURN NULL;
END
$$;

alter function parcels__stockly_pays_et_for_initial_parcel_check() owner to romain;

