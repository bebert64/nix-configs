create function isnt_descendent_of(name, name) returns text
    language sql
as
$$
    SELECT ok(
       NOT  _ancestor_of( $2, $1, NULL ),
        'Table ' || quote_ident( $1 ) || ' should not be a descendent of ' || quote_ident( $2)
    );
$$;

alter function isnt_descendent_of(name, name) owner to romain;

