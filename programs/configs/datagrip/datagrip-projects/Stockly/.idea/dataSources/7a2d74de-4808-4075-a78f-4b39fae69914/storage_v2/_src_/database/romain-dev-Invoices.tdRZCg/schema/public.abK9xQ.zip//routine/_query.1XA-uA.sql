create function _query(text) returns text
    language sql
as
$$
    SELECT CASE
        WHEN $1 LIKE '"%' OR $1 !~ '[[:space:]]' THEN 'EXECUTE ' || $1
        ELSE $1
    END;
$$;

alter function _query(text) owner to romain;

