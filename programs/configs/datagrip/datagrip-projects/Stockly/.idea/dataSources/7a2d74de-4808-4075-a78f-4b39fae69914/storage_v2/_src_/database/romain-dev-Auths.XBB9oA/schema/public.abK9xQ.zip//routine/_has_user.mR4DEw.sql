create function _has_user(name) returns boolean
    strict
    language sql
as
$$
    SELECT EXISTS( SELECT true FROM pg_catalog.pg_user WHERE usename = $1);
$$;

alter function _has_user(name) owner to romain;

