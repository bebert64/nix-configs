create function array_has_empty_elem(arg_array text[]) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT * FROM unnest(arg_array) AS elem
		WHERE
			LENGTH(elem) = 0
	);

	RETURN ret_val;
END
$$;

alter function array_has_empty_elem(text[]) owner to romain;

