create function is_ancestor_of(name, name, name, name, integer) returns text
    language sql
as
$$
    SELECT ok(
        _ancestor_of( $1, $2, $3, $4, $5 ),
        'Table ' || quote_ident( $1 ) || '.' || quote_ident( $2 )
        || ' should be ancestor ' || $5 || ' for '
        || quote_ident( $3 ) || '.' || quote_ident( $4 )
    );
$$;

alter function is_ancestor_of(name, name, name, name, integer) owner to romain;

