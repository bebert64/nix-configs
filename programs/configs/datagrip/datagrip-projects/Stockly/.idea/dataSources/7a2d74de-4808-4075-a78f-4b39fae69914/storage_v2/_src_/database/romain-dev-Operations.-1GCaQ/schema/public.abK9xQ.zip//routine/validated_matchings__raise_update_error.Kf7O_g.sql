create function validated_matchings__raise_update_error() returns trigger
    language plpgsql
as
$$
BEGIN
	RAISE
		'Can''t update demander_stocks_item_id or supplier_stocks_item_id on validated_matchings table'
	USING
		ERRCODE = 'check_violation',
		CONSTRAINT = 'validated_matchings__prevent_update',
		TABLE = 'validated_matchings';
END
$$;

alter function validated_matchings__raise_update_error() owner to romain;

