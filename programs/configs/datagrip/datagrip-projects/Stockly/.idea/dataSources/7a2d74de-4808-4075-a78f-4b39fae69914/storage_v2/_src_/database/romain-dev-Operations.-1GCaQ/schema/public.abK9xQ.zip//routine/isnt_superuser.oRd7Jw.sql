create function isnt_superuser(name) returns text
    language sql
as
$$
    SELECT isnt_superuser( $1, 'User ' || quote_ident($1) || ' should not be a super user' );
$$;

alter function isnt_superuser(name) owner to romain;

