create function has_extension(name) returns text
    language sql
as
$$
    SELECT ok(
        _ext_exists( $1 ),
        'Extension ' || quote_ident($1) || ' should exist' );
$$;

alter function has_extension(name) owner to romain;

