create function isnt_window(name, name[], text) returns text
    language sql
as
$$
    SELECT _func_compare(NULL, $1, $2, NOT _type_func('w', $1, $2), $3 );
$$;

alter function isnt_window(name, name[], text) owner to romain;

