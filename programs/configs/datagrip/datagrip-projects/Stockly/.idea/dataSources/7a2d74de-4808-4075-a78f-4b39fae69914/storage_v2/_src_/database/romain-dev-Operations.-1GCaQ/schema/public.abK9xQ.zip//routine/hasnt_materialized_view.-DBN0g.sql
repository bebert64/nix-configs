create function hasnt_materialized_view(name) returns text
    language sql
as
$$
    SELECT hasnt_materialized_view( $1, 'Materialized view ' || quote_ident($1) || ' should not exist' );
$$;

alter function hasnt_materialized_view(name) owner to romain;

