create function isnt_ancestor_of(name, name, name, name, integer, text) returns text
    language sql
as
$$
    SELECT ok( NOT  _ancestor_of( $1, $2, $3, $4, $5 ), $6 );
$$;

alter function isnt_ancestor_of(name, name, name, name, integer, text) owner to romain;

