create function _returns(name) returns text
    language sql
as
$$
    SELECT returns FROM tap_funky WHERE name = $1 AND is_visible;
$$;

alter function _returns(name) owner to romain;

