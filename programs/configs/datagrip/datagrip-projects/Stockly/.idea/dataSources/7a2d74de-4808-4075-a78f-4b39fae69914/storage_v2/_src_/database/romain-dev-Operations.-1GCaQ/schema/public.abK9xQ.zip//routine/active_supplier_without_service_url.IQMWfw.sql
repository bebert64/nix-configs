create function active_supplier_without_service_url(arg_supplier_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
	RETURN (
		SELECT
			EXISTS (
				SELECT
					*
				FROM
					automated_purchase_submission_cron_configs apscc
					INNER JOIN suppliers s ON apscc.supplier_id = s.retailer_id
				WHERE
					apscc.deactivated_at IS NULL
					AND s.service_url IS NULL
					AND (s.retailer_id = arg_supplier_id
						OR arg_supplier_id IS NULL)));
END
$$;

alter function active_supplier_without_service_url(integer) owner to romain;

