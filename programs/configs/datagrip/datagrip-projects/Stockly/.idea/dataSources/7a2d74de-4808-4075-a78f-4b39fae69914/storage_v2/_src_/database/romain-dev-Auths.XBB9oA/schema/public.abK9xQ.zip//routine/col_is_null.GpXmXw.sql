create function col_is_null(schema_name name, table_name name, column_name name, description text DEFAULT NULL::text) returns text
    language sql
as
$$
    SELECT _col_is_null( $1, $2, $3, $4, false );
$$;

alter function col_is_null(name, name, name, text) owner to romain;

