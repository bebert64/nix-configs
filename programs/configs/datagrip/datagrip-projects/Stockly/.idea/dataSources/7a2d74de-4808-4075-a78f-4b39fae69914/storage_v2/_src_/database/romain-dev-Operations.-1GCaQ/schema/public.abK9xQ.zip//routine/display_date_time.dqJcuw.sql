create function display_date_time(date_time timestamp with time zone, time_zone text, use_short_format boolean) returns text
    language plpgsql
as
$$
BEGIN
	return display_date(date_time, time_zone, use_short_format) || ' ' || display_time(date_time, time_zone);
END;
$$;

alter function display_date_time(timestamp with time zone, text, boolean) owner to romain;

