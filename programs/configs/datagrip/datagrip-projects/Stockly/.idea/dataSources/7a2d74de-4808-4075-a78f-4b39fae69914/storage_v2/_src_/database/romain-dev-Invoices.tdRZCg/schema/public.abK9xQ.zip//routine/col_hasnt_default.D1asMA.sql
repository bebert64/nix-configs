create function col_hasnt_default(name, name, text) returns text
    language plpgsql
as
$$
BEGIN
    IF NOT _cexists( $1, $2 ) THEN
        RETURN fail( $3 ) || E'\n'
            || diag ('    Column ' || quote_ident($1) || '.' || quote_ident($2) || ' does not exist' );
    END IF;
    RETURN ok( NOT _has_def( $1, $2 ), $3 );
END;
$$;

alter function col_hasnt_default(name, name, text) owner to romain;

