create view acceptable_losses(purchase_id, acceptable_loss_flag_id, reason, created_by, created_at) as
SELECT p.id    AS purchase_id,
       CASE
           WHEN alf.created_at IS NULL OR acceptable_losses_because_sdd_refusal.created_at < alf.created_at THEN NULL::integer
           ELSE p.acceptable_loss_flag_id
           END AS acceptable_loss_flag_id,
       CASE
           WHEN alf.created_at IS NULL OR acceptable_losses_because_sdd_refusal.created_at < alf.created_at
               THEN 'Supply delivery dispute refusal'::character varying
           ELSE alf.reason
           END AS reason,
       CASE
           WHEN alf.created_at IS NULL OR acceptable_losses_because_sdd_refusal.created_at < alf.created_at
               THEN 'Operations'::character varying
           ELSE alf.created_by
           END AS created_by,
       CASE
           WHEN alf.created_at IS NULL OR acceptable_losses_because_sdd_refusal.created_at < alf.created_at
               THEN acceptable_losses_because_sdd_refusal.created_at
           ELSE alf.created_at
           END AS created_at
FROM purchases p
         LEFT JOIN acceptable_loss_flags alf ON p.acceptable_loss_flag_id = alf.id
         LEFT JOIN (SELECT DISTINCT ON (p2.id) p2.id AS purchase_id,
                                               sddo.created_at
                    FROM purchases p2
                             JOIN parcel_items pi ON pi.purchase_id = p2.id
                             JOIN supply_delivery_disputes sdd ON sdd.parcel_id = pi.parcel_id
                             JOIN supply_delivery_dispute_outcomes sddo ON sddo.id = sdd.outcome_id
                    WHERE sdd.supplier_id = p2.supplier_id
                      AND sddo.outcome = 'refused'::accepted_refused_or_aborted
                    ORDER BY p2.id, sddo.created_at) acceptable_losses_because_sdd_refusal
                   ON acceptable_losses_because_sdd_refusal.purchase_id = p.id
WHERE alf.id IS NOT NULL
   OR acceptable_losses_because_sdd_refusal.purchase_id IS NOT NULL;

alter table acceptable_losses
    owner to romain;

