create function banned_brands_for_dmds_cache__check_bbfd_history_consistency(affected_retailer_id integer, affected_brand_interned_id integer, is_banned_in_cache boolean) returns void
    language plpgsql
as
$$
DECLARE
	is_banned_in_history BOOLEAN;
BEGIN
	SELECT is_banned INTO is_banned_in_history
	FROM banned_brands_for_demanders_history
	WHERE brand_interned_id = affected_brand_interned_id AND demander_id = affected_retailer_id
		ORDER BY created_at DESC
		LIMIT 1;

	IF is_banned_in_cache AND (is_banned_in_history IS NULL OR NOT is_banned_in_history) THEN
		RAISE EXCEPTION
			'New entry (interned id %) in `banned_brands_for_demander_cache`, but there is no corresponding record in `banned_brands_for_demanders_history`. The `banned_brands_for_demanders_cache` table should not be updated directly.',
			affected_brand_interned_id;
	ELSIF NOT is_banned_in_cache AND (is_banned_in_history IS NOT NULL AND is_banned_in_history) THEN
		RAISE EXCEPTION
			'An entry (interned id %) in `banned_brands_for_demanders_cache` is being deleted, but there is no corresponding record in `banned_brands_for_demanders_history`. The `banned_brands_for_demanders_cache` table should not be updated directly.',
			affected_brand_interned_id;
	END IF;
END;
$$;

alter function banned_brands_for_dmds_cache__check_bbfd_history_consistency(integer, integer, boolean) owner to romain;

