create function has_fk(name) returns text
    language sql
as
$$
    SELECT has_fk( $1, 'Table ' || quote_ident($1) || ' should have a foreign key constraint' );
$$;

alter function has_fk(name) owner to romain;

