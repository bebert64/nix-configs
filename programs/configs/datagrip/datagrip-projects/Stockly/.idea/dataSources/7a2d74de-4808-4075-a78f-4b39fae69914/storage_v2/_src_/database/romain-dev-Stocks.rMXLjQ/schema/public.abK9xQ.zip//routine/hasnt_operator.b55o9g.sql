create function hasnt_operator(name, name, name, name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _op_exists($1, $2, $3, $4 ), $5 );
$$;

alter function hasnt_operator(name, name, name, name, text) owner to romain;

