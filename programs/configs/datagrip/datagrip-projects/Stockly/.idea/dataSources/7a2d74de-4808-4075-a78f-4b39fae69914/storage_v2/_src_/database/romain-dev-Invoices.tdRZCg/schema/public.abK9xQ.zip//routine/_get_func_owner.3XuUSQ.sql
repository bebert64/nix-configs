create function _get_func_owner(name, name[]) returns name
    language sql
as
$$
    SELECT owner
      FROM tap_funky
     WHERE name = $1
       AND args = _funkargs($2)
       AND is_visible
$$;

alter function _get_func_owner(name, name[]) owner to romain;

