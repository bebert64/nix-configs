create function _dexists(name, name) returns boolean
    language sql
as
$$
   SELECT EXISTS(
       SELECT true
         FROM pg_catalog.pg_namespace n
         JOIN pg_catalog.pg_type t on n.oid = t.typnamespace
        WHERE n.nspname = $1
          AND t.typname = $2
   );
$$;

alter function _dexists(name, name) owner to romain;

