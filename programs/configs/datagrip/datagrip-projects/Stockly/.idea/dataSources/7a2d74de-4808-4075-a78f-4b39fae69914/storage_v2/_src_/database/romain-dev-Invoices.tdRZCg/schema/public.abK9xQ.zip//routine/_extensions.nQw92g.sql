create function _extensions(name) returns SETOF name
    language sql
as
$$
    SELECT e.extname
      FROM pg_catalog.pg_namespace n
      JOIN pg_catalog.pg_extension e ON n.oid = e.extnamespace
     WHERE n.nspname = $1
$$;

alter function _extensions(name) owner to romain;

