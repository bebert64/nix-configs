create function is_definer(name, text) returns text
    language sql
as
$$
    SELECT _func_compare(NULL, $1, _definer($1), $2 );
$$;

alter function is_definer(name, text) owner to romain;

