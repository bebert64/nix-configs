create function has_opclass(name) returns text
    language sql
as
$$
    SELECT ok( _opc_exists( $1 ), 'Operator class ' || quote_ident($1) || ' should exist' );
$$;

alter function has_opclass(name) owner to romain;

