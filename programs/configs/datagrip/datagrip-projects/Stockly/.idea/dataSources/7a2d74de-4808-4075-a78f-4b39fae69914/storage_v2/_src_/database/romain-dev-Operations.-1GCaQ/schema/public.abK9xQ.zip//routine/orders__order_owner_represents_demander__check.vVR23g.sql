create function orders__order_owner_represents_demander__check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NOT demand__order_owner_represents_demander__check(NULL, NEW.id, NULL, NULL)) THEN
		RAISE EXCEPTION 'orders__order_owner_represents_demander__check FAILED';
	END IF;
	RETURN NULL;
END
$$;

alter function orders__order_owner_represents_demander__check() owner to romain;

