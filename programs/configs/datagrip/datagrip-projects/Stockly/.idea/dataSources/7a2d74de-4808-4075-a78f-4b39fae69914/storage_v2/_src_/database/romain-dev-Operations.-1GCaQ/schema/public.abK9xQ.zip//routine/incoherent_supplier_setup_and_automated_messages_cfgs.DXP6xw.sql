create function incoherent_supplier_setup_and_automated_messages_cfgs(arg_retailer_id integer, arg_automated_messages_config_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val Boolean := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT
			*
		FROM
			"suppliers" s
			LEFT JOIN
			"automated_supplier_messages_configs" asmc
			ON s.automated_messages_config_id = asmc.id
		WHERE
			s.auto_ask_demand_for_delivery_dispute_documents = TRUE
			AND asmc.supply_delivery_dispute__open IS NULL
			AND ("arg_retailer_id" IS NULL OR "arg_retailer_id" = s.retailer_id)
			AND ("arg_automated_messages_config_id" IS NULL OR "arg_automated_messages_config_id" = asmc.id)
	);
	RETURN ret_val;
END
$$;

alter function incoherent_supplier_setup_and_automated_messages_cfgs(integer, integer) owner to romain;

