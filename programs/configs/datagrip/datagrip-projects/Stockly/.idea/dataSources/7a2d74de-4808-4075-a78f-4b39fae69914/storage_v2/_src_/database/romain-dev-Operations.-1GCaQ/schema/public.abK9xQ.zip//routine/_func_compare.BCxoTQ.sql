create function _func_compare(name, name, name[], anyelement, anyelement, text) returns text
    language sql
as
$$
    SELECT CASE WHEN $4 IS NULL
      THEN ok( FALSE, $6 ) || _nosuch($1, $2, $3)
      ELSE is( $4, $5, $6 )
      END;
$$;

alter function _func_compare(name, name, name[], anyelement, anyelement, text) owner to romain;

