create function hasnt_sequence(name, name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _rexists( 'S', $1, $2 ), $3 );
$$;

alter function hasnt_sequence(name, name, text) owner to romain;

