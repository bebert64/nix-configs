create function has_sequence(name) returns text
    language sql
as
$$
    SELECT has_sequence( $1, 'Sequence ' || quote_ident($1) || ' should exist' );
$$;

alter function has_sequence(name) owner to romain;

