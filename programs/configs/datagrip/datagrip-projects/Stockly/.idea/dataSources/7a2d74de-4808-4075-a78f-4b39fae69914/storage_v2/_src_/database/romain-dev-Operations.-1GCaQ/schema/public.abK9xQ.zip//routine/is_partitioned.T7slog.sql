create function is_partitioned(name, name) returns text
    language sql
as
$$
    SELECT ok(
        _rexists('p', $1, $2),
        'Table ' || quote_ident($1) || '.' || quote_ident($2) || ' should be partitioned'
    );
$$;

alter function is_partitioned(name, name) owner to romain;

