create function has_inherited_tables(name) returns text
    language sql
as
$$
    SELECT ok(
        _inherited( $1 ),
        'Table ' || quote_ident( $1 ) || ' should have descendents'
    );
$$;

alter function has_inherited_tables(name) owner to romain;

