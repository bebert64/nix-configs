create function columns_are(name, name, name[]) returns text
    language sql
as
$$
    SELECT columns_are( $1, $2, $3, 'Table ' || quote_ident($1) || '.' || quote_ident($2) || ' should have the correct columns' );
$$;

alter function columns_are(name, name, name[]) owner to romain;

