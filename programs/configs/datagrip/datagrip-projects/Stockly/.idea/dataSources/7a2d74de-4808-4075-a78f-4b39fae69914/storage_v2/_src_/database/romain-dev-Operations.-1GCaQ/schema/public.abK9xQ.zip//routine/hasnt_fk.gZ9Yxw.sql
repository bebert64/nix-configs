create function hasnt_fk(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _hasc( $1, 'f' ), $2 );
$$;

alter function hasnt_fk(name, text) owner to romain;

