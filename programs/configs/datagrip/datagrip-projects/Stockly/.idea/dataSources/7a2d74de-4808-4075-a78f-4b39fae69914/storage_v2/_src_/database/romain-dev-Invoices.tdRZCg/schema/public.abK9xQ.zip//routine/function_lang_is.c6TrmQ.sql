create function function_lang_is(name, name[], name, text) returns text
    language sql
as
$$
    SELECT _func_compare(NULL, $1, $2, _lang($1, $2), $3, $4 );
$$;

alter function function_lang_is(name, name[], name, text) owner to romain;

