create function has_schema(name, text) returns text
    language sql
as
$$
    SELECT ok(
        EXISTS(
            SELECT true
              FROM pg_catalog.pg_namespace
             WHERE nspname = $1
        ), $2
    );
$$;

alter function has_schema(name, text) owner to romain;

