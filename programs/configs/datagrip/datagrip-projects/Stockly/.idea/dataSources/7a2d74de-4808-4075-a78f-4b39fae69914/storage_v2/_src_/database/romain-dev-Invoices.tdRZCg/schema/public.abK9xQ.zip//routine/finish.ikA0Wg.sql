create function finish(exception_on_failure boolean DEFAULT NULL::boolean) returns SETOF text
    language sql
as
$$
    SELECT * FROM _finish(
        _get('curr_test'),
        _get('plan'),
        num_failed(),
        $1
    );
$$;

alter function finish(boolean) owner to romain;

