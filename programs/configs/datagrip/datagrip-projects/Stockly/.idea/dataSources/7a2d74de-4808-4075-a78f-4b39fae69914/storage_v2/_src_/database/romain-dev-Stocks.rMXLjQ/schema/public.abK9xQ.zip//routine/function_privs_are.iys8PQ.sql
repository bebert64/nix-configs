create function function_privs_are(name, name, name[], name, name[], text) returns text
    language sql
as
$$
    SELECT _fprivs_are(
        quote_ident($1) || '.' || quote_ident($2) || '(' || array_to_string($3, ', ') || ')',
        $4, $5, $6
    );
$$;

alter function function_privs_are(name, name, name[], name, name[], text) owner to romain;

