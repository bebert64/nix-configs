create function domains_are(name, name[], text) returns text
    language sql
as
$$
    SELECT _types_are( $1, $2, $3, ARRAY['d'] );
$$;

alter function domains_are(name, name[], text) owner to romain;

