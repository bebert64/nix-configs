create function cancellation_decision_on_not_submitted_purchases(arg_purchase_id integer, arg_purchase_cancellation_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
	RETURN (
		SELECT
			EXISTS (
				SELECT
					*
				FROM
					"purchase_cancellations" pc
					INNER JOIN "purchases" p ON pc.id = p.cancellation_id
				WHERE
					(p.id = arg_purchase_id OR arg_purchase_id IS NULL)
					AND p.purchases_shipping_id IS NULL -- Not submitted
					AND pc.decision_id IS NOT NULL
					AND (pc.id = arg_purchase_cancellation_id
						OR arg_purchase_cancellation_id IS NULL)));
END
$$;

alter function cancellation_decision_on_not_submitted_purchases(integer, integer) owner to romain;

