create function isnt_definer(name) returns text
    language sql
as
$$
    SELECT ok( NOT _definer($1), 'Function ' || quote_ident($1) || '() should not be security definer' );
$$;

alter function isnt_definer(name) owner to romain;

