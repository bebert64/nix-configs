create function _func_compare(name, name, anyelement, anyelement, text) returns text
    language sql
as
$$
    SELECT CASE WHEN $3 IS NULL
      THEN ok( FALSE, $5 ) || _nosuch($1, $2, '{}')
      ELSE is( $3, $4, $5 )
      END;
$$;

alter function _func_compare(name, name, anyelement, anyelement, text) owner to romain;

