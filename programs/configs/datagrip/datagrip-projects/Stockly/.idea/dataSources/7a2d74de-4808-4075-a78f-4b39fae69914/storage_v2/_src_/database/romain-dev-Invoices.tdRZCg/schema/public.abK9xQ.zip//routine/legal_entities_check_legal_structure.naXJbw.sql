create function legal_entities_check_legal_structure() returns trigger
    language plpgsql
as
$$
DECLARE
    company_legal_structure Text;
BEGIN
    SELECT c.legal_structure INTO company_legal_structure
    FROM companies c
    WHERE c.legal_entity_id = NEW.legal_entity_id;

    IF company_legal_structure IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
            FROM country_legal_structures cls
            WHERE cls.country = NEW.country_alpha3
            AND cls.legal_structure = company_legal_structure
        ) THEN
            RAISE EXCEPTION 'Invalid legal structure "%" for country "%"',
                company_legal_structure,
                NEW.country_alpha3;
        END IF;
    END IF;

    RETURN NEW;
END;
$$;

alter function legal_entities_check_legal_structure() owner to romain;

