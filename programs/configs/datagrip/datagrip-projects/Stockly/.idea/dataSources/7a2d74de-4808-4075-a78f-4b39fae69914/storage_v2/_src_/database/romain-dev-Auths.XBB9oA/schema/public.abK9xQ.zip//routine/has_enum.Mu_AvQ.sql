create function has_enum(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _has_type( $1, $2, ARRAY['e'] ), $3 );
$$;

alter function has_enum(name, name, text) owner to romain;

