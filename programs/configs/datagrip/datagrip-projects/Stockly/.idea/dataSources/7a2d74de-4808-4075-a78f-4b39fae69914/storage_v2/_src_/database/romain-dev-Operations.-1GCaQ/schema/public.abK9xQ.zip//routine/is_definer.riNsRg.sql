create function is_definer(name, name, name[]) returns text
    language sql
as
$$
    SELECT ok(
        _definer($1, $2, $3),
        'Function ' || quote_ident($1) || '.' || quote_ident($2) || '(' ||
        array_to_string($3, ', ') || ') should be security definer'
    );
$$;

alter function is_definer(name, name, name[]) owner to romain;

