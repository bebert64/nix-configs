create function _type_func("char", name, name) returns boolean
    language sql
as
$$
    SELECT kind = $1 FROM tap_funky WHERE schema = $2 AND name = $3
$$;

alter function _type_func("char", name, name) owner to romain;

