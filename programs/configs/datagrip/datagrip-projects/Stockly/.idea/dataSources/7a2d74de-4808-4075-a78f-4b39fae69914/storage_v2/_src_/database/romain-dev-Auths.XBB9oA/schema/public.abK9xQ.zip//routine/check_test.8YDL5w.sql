create function check_test(text, boolean) returns SETOF text
    language sql
as
$$
    SELECT * FROM check_test( $1, $2, NULL, NULL, NULL, FALSE );
$$;

alter function check_test(text, boolean) owner to romain;

