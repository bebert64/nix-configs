create function has_trigger(name, name, name) returns text
    language sql
as
$$
    SELECT has_trigger(
        $1, $2, $3,
        'Table ' || quote_ident($1) || '.' || quote_ident($2) || ' should have trigger ' || quote_ident($3)
    );
$$;

alter function has_trigger(name, name, name) owner to romain;

