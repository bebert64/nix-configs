create function database_privs_are(name, name, name[]) returns text
    language sql
as
$$
    SELECT database_privs_are(
        $1, $2, $3,
        'Role ' || quote_ident($2) || ' should be granted '
            || CASE WHEN $3[1] IS NULL THEN 'no privileges' ELSE array_to_string($3, ', ') END
            || ' on database ' || quote_ident($1)
    );
$$;

alter function database_privs_are(name, name, name[]) owner to romain;

