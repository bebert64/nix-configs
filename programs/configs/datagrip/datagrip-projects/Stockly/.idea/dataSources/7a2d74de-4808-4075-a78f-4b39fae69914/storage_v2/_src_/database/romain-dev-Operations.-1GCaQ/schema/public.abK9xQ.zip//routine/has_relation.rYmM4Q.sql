create function has_relation(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _relexists( $1, $2 ), $3 );
$$;

alter function has_relation(name, name, text) owner to romain;

