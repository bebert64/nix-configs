create function _get_rel_owner(character, name, name) returns name
    language sql
as
$$
    SELECT _get_rel_owner(ARRAY[$1], $2, $3);
$$;

alter function _get_rel_owner(char, name, name) owner to romain;

