create function hasnt_function(name, name[]) returns text
    language sql
as
$$
    SELECT ok(
        NOT _got_func($1, $2),
        'Function ' || quote_ident($1) || '(' ||
        array_to_string($2, ', ') || ') should not exist'
    );
$$;

alter function hasnt_function(name, name[]) owner to romain;

