create function incoherent_stocks_item_id_in_matching_checks__order_lines() returns trigger
    language plpgsql
as
$$
BEGIN
	IF incoherent_stocks_item_id_in_matching_checks(NULL, NEW.id, NULL) THEN
		RAISE 'Incoherent demander_stocks_item_id'
		USING ERRCODE = 'check_violation', CONSTRAINT = 'matching_checks__incoherent_stocks_item_id', TABLE = 'order_lines';
	END IF;
		RETURN NULL;
END
$$;

alter function incoherent_stocks_item_id_in_matching_checks__order_lines() owner to romain;

