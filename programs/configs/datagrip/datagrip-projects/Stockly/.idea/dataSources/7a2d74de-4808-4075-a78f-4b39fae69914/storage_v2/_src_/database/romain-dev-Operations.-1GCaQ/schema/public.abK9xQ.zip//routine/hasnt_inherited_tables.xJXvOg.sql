create function hasnt_inherited_tables(name, name) returns text
    language sql
as
$$
    SELECT ok(
        NOT _inherited( $1, $2 ),
        'Table ' || quote_ident( $1 ) || '.' || quote_ident( $2 ) || ' should not have descendents'
    );
$$;

alter function hasnt_inherited_tables(name, name) owner to romain;

