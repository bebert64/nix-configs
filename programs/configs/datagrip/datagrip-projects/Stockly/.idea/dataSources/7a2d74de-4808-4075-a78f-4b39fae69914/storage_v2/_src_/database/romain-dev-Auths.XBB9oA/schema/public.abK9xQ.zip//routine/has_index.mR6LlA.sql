create function has_index(name, name, name[]) returns text
    language sql
as
$$
   SELECT has_index( $1, $2, $3, 'Index ' || quote_ident($2) || ' should exist' );
$$;

alter function has_index(name, name, name[]) owner to romain;

