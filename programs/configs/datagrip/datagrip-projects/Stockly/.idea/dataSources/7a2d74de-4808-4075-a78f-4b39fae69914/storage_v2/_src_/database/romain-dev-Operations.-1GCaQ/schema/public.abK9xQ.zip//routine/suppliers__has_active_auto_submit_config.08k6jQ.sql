create function suppliers__has_active_auto_submit_config(arg_supplier_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT
			*
		FROM
			"automated_purchase_submission_configs" apsc
		WHERE
			apsc.supplier_id = arg_supplier_id
			AND apsc.deactivated_at IS NULL
	);
	RETURN ret_val;
END
$$;

alter function suppliers__has_active_auto_submit_config(integer) owner to romain;

