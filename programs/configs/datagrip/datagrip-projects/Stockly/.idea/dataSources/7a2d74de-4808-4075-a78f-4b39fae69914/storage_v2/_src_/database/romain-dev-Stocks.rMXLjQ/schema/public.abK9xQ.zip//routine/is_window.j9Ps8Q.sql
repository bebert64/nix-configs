create function is_window(name) returns text
    language sql
as
$$
    SELECT _func_compare(
        NULL, $1, _type_func('w', $1),
        'Function ' || quote_ident($1) || '() should be a window function'
    );
$$;

alter function is_window(name) owner to romain;

