create function policies__designation_already_taken_not_by_programmatic_entity(arg_policy_id integer, arg_programmatic_entity_id integer) returns boolean
    language sql
as
$$
	SELECT
		EXISTS(
			SELECT
				*
			FROM
				"policies" p
				INNER JOIN "policies" p2 ON(p.designation = p2.designation
						AND p.id != p2.id)
			WHERE(p.id = arg_policy_id
				OR arg_policy_id IS NULL)
			AND(p.created_by = arg_programmatic_entity_id
				OR arg_programmatic_entity_id IS NULL)
			AND NOT EXISTS(
				SELECT
					*
				FROM
					"programmatic_entities"
				WHERE
					entity_id = p.created_by)
				AND NOT EXISTS(
					SELECT
						*
					FROM
						"programmatic_entities"
					WHERE
						entity_id = p2.created_by));
$$;

alter function policies__designation_already_taken_not_by_programmatic_entity(integer, integer) owner to romain;

