create function _currtest() returns integer
    language plpgsql
as
$$
BEGIN
    RETURN currval('__tresults___numb_seq');
EXCEPTION
    WHEN object_not_in_prerequisite_state THEN RETURN 0;
END;
$$;

alter function _currtest() owner to romain;

