create function results_ne(refcursor, text) returns text
    language sql
as
$$
    SELECT results_ne( $1, $2, NULL::text );
$$;

alter function results_ne(refcursor, text) owner to romain;

