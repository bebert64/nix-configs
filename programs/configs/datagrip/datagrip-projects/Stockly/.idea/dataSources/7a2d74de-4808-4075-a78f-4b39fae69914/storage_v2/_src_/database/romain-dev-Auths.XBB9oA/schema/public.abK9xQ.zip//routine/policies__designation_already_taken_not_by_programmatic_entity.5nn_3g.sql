create function policies__designation_already_taken_not_by_programmatic_entity() returns trigger
    language plpgsql
as
$$
BEGIN
	IF policies__designation_already_taken_not_by_programmatic_entity(NEW.id, NULL) THEN
		RAISE 'Policy designation (%) already exists created by non-programmatic entity', NEW.designation
		USING ERRCODE = 'unique_violation', CONSTRAINT = 'policies__designation_already_taken_not_by_programmatic_entity', TABLE = 'policies';
	END IF;
		RETURN NULL;
END
$$;

alter function policies__designation_already_taken_not_by_programmatic_entity() owner to romain;

