create function is_clustered(name, name, name) returns text
    language sql
as
$$
    SELECT is_clustered(
        $1, $2, $3,
        'Table ' || quote_ident($1) || '.' || quote_ident($2) ||
        ' should be clustered on index ' || quote_ident($3)
    );
$$;

alter function is_clustered(name, name, name) owner to romain;

