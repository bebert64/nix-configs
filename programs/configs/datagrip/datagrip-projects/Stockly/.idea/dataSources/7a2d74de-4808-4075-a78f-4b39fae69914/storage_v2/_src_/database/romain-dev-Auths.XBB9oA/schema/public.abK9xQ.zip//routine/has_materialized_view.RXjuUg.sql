create function has_materialized_view(name, text) returns text
    language sql
as
$$
    SELECT ok( _rexists( 'm', $1 ), $2 );
$$;

alter function has_materialized_view(name, text) owner to romain;

