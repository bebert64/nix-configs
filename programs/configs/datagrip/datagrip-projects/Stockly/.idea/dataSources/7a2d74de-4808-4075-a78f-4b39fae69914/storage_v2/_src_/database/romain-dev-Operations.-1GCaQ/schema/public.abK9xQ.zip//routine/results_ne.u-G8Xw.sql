create function results_ne(text, text) returns text
    language sql
as
$$
    SELECT results_ne( $1, $2, NULL::text );
$$;

alter function results_ne(text, text) owner to romain;

