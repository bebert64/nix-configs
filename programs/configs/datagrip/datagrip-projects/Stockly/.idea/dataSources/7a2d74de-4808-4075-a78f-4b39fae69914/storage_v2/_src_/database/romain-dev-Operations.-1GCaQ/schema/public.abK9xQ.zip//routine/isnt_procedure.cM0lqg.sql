create function isnt_procedure(name, name, text) returns text
    language sql
as
$$
    SELECT _func_compare($1, $2, NOT _type_func('p', $1, $2), $3 );
$$;

alter function isnt_procedure(name, name, text) owner to romain;

