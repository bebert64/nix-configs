create function hasnt_materialized_view(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _rexists( 'm', $1 ), $2 );
$$;

alter function hasnt_materialized_view(name, text) owner to romain;

