create function has_rightop(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _op_exists( $1, $2, NULL), $3 );
$$;

alter function has_rightop(name, name, text) owner to romain;

