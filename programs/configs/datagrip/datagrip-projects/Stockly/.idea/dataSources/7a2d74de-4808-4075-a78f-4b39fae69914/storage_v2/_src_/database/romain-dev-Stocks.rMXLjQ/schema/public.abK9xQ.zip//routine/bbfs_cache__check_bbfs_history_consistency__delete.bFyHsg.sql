create function bbfs_cache__check_bbfs_history_consistency__delete() returns trigger
    language plpgsql
as
$$
BEGIN
	PERFORM banned_brands_for_supls_cache__check_bbfs_history_consistency(OLD.supplier_id, OLD.brand_interned_id, FALSE);
	RETURN OLD;
END;
$$;

alter function bbfs_cache__check_bbfs_history_consistency__delete() owner to romain;

