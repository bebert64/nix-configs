create function has_table(name) returns text
    language sql
as
$$
    SELECT has_table( $1, 'Table ' || quote_ident($1) || ' should exist' );
$$;

alter function has_table(name) owner to romain;

