create function _parts(name, name) returns SETOF name
    language sql
as
$$
    SELECT i.inhrelid::regclass::name
      FROM pg_catalog.pg_namespace n
      JOIN pg_catalog.pg_class c ON n.oid = c.relnamespace
      JOIN pg_catalog.pg_inherits i ON c.oid = i.inhparent
     WHERE n.nspname = $1
       AND c.relname = $2
       AND c.relkind = 'p'
$$;

alter function _parts(name, name) owner to romain;

