create function turnover(start_dt timestamp with time zone, end_dt timestamp with time zone) returns bigint
    language plpgsql
as
$$
DECLARE
	turnover bigint;
BEGIN
	SELECT sum(lines.turnover) INTO turnover
	FROM (
		SELECT
			SUM(ol.client_price_et + ol.client_extra_shipping_price_et)
		FROM
			order_lines ol
		INNER JOIN order_shippings os ON os.id = ol.order_shipping_id
		INNER JOIN orders o ON o.id = os.order_id
		WHERE
			o.confirmed_at >= start_dt AND o.confirmed_at < end_dt
		UNION ALL
		SELECT
			SUM(os.client_price_et)
		FROM
			order_shippings os
		INNER JOIN orders o ON o.id = os.order_id
		WHERE
			o.confirmed_at >= start_dt AND o.confirmed_at < end_dt
	) lines(turnover);

	RETURN turnover;
END
$$;

alter function turnover(timestamp with time zone, timestamp with time zone) owner to romain;

