create function purchase_fully_refunded_with_refused_cancellation(arg_purchase_id integer, arg_purchase_cancellation_id integer, arg_purchase_cancellation_decision_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
    RETURN (SELECT EXISTS (
        SELECT *
        FROM purchases p
        INNER JOIN (
            SELECT pr.purchase_id, SUM(pr.price_et) AS refunds_sum_et
            FROM
                purchase_refunds pr
                INNER JOIN purchases p ON pr.purchase_id = p.id
                INNER JOIN purchase_cancellations pc ON p.cancellation_id = pc.id
                INNER JOIN purchase_cancellation_decisions pcd ON pc.decision_id = pcd.id
            WHERE
                (p.id = arg_purchase_id OR arg_purchase_id IS NULL)
                AND (pc.id = arg_purchase_cancellation_id OR arg_purchase_cancellation_id IS NULL)
                AND (pcd.id = arg_purchase_cancellation_decision_id OR arg_purchase_cancellation_decision_id IS NULL)
                AND pcd.refused_reason IS NOT NULL
                AND pr.flagged_as_erroneous_at IS NULL
            GROUP BY pr.purchase_id
        ) pr_sum ON p.id = pr_sum.purchase_id
        WHERE
            pr_sum.refunds_sum_et > p.price_et - 1e-9
    ));
    END;
$$;

alter function purchase_fully_refunded_with_refused_cancellation(integer, integer, integer) owner to romain;

