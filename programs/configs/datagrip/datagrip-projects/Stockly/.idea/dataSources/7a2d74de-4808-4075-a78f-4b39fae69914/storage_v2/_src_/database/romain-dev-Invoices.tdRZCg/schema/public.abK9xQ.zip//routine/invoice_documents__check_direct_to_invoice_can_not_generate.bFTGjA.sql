create function invoice_documents__check_direct_to_invoice_can_not_generate() returns trigger
    language plpgsql
as
$$
BEGIN
	IF NOT invoice_documents__direct_to_invoice_can_not_generate(NEW.invoice_id, NEW.id) THEN
		RAISE EXCEPTION 'invoice_documents__check_direct_to_invoice_can_not_generate';
	END IF;
	RETURN NULL;
END
$$;

alter function invoice_documents__check_direct_to_invoice_can_not_generate() owner to romain;

