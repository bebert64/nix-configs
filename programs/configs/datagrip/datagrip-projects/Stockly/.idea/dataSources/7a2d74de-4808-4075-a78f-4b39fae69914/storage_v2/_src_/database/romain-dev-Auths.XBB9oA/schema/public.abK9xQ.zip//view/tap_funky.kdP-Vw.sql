create view tap_funky
            (oid, schema, name, owner, args, returns, langoid, is_strict, kind, is_definer, returns_set, volatility,
             is_visible) as
SELECT p.oid,
       n.nspname                                            AS schema,
       p.proname                                            AS name,
       pg_get_userbyid(p.proowner)                          AS owner,
       array_to_string(p.proargtypes::regtype[], ','::text) AS args,
       CASE p.proretset
           WHEN true THEN 'setof '::text
           ELSE ''::text
           END || p.prorettype::regtype                     AS returns,
       p.prolang                                            AS langoid,
       p.proisstrict                                        AS is_strict,
       _prokind(p.oid)                                      AS kind,
       p.prosecdef                                          AS is_definer,
       p.proretset                                          AS returns_set,
       p.provolatile::character(1)                          AS volatility,
       pg_function_is_visible(p.oid)                        AS is_visible
FROM pg_proc p
         JOIN pg_namespace n ON p.pronamespace = n.oid;

alter table tap_funky
    owner to romain;

grant select on tap_funky to public;

