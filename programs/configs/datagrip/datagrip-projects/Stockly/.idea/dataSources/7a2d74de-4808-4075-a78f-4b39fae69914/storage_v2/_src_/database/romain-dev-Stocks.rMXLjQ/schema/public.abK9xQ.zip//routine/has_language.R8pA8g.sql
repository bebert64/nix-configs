create function has_language(name) returns text
    language sql
as
$$
    SELECT ok( _is_trusted($1) IS NOT NULL, 'Procedural language ' || quote_ident($1) || ' should exist' );
$$;

alter function has_language(name) owner to romain;

