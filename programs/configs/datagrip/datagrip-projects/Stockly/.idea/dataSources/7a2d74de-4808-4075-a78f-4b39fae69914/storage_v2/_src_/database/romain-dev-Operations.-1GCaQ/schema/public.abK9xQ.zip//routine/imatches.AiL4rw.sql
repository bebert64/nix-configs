create function imatches(anyelement, text) returns text
    language sql
as
$$
    SELECT _alike( $1 ~* $2, $1, $2, NULL );
$$;

alter function imatches(anyelement, text) owner to romain;

