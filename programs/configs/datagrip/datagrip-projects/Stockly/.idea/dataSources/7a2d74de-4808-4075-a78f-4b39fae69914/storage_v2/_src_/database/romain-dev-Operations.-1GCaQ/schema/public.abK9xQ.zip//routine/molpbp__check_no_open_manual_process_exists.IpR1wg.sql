create function molpbp__check_no_open_manual_process_exists() returns trigger
    language plpgsql
as
$$
BEGIN
	IF NEW.handled_by IS NULL AND open_manual_process_exists (NEW.order_line_id) THEN
		RAISE 'A manual process for order line id (%) is already opened', NEW.order_line_id
		USING ERRCODE = 'unique_violation', CONSTRAINT = 'molpbp__check_no_open_manual_process_exists', TABLE = 'manual_order_line_purchase_binding_process';
	END IF;
		RETURN NULL;
END
$$;

alter function molpbp__check_no_open_manual_process_exists() owner to romain;

