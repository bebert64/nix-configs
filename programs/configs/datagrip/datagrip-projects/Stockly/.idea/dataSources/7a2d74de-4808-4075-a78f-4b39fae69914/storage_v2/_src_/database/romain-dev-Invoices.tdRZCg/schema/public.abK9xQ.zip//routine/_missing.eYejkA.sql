create function _missing(character, name[]) returns name[]
    language sql
as
$$
    SELECT _missing(ARRAY[$1], $2);
$$;

alter function _missing(char, name[]) owner to romain;

