create function molpbp_handled_by_coherent_with_order_line_state(arg_order_line_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
RETURN (SELECT
	NOT EXISTS (
		SELECT
			1
		FROM
			"manual_order_line_purchase_binding_process" m
			INNER JOIN order_lines ol ON ol.id = m.order_line_id
			LEFT JOIN order_line_cancellations olc ON ol.cancellation_id = olc.id
			LEFT JOIN order_line_cancellation_decisions olcd ON olc.decision_id = olcd.id
		WHERE
			m.order_line_id = arg_order_line_id
			AND m.handled_by IS NULL
			AND (ol.purchase_id IS NOT NULL
				OR (ol.cancellation_id IS NOT NULL
					AND olcd.refused_reason IS NOT NULL)))
);
END;
$$;

alter function molpbp_handled_by_coherent_with_order_line_state(integer) owner to romain;

