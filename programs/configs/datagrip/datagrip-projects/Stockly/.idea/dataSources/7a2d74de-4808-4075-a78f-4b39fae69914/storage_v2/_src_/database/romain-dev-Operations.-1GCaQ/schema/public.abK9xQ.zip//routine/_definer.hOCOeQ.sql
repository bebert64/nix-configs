create function _definer(name, name, name[]) returns boolean
    language sql
as
$$
    SELECT is_definer
      FROM tap_funky
     WHERE schema = $1
       AND name   = $2
       AND args   = _funkargs($3)
$$;

alter function _definer(name, name, name[]) owner to romain;

