create function isnt(anyelement, anyelement) returns text
    language sql
as
$$
    SELECT isnt( $1, $2, NULL);
$$;

alter function isnt(anyelement, anyelement) owner to romain;

