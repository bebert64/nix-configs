create function has_cast(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _cast_exists( $1, $2 ), $3 );
$$;

alter function has_cast(name, name, text) owner to romain;

