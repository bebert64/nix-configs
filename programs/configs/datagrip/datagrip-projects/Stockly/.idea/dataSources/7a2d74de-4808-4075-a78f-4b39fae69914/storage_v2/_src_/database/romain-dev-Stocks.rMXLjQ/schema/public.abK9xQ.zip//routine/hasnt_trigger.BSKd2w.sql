create function hasnt_trigger(name, name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _trig($1, $2), $3);
$$;

alter function hasnt_trigger(name, name, text) owner to romain;

