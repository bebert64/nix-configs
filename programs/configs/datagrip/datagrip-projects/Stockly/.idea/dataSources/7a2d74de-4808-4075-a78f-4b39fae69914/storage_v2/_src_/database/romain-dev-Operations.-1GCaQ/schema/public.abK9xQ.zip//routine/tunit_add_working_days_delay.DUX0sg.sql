create function tunit_add_working_days_delay() returns SETOF text
    language plpgsql
as
$$
DECLARE
	friday_17_dec_wds Timestamptz;
	friday_31_dec_noon Timestamptz;

	saturday_01_noon Timestamptz;

	sunday_02_noon Timestamptz;

	monday_03_wds_minus Timestamptz;
	monday_03_noon Timestamptz;
	monday_03_wde Timestamptz;

	tuesday_04_wde Timestamptz;

	wednesday_05_wds Timestamptz;

	thursday_06_wde Timestamptz;

	friday_07_wds Timestamptz;
	friday_07_wde Timestamptz;

	saturday_08_noon Timestamptz;

	sunday_09_noon Timestamptz;

	monday_10_noon Timestamptz;
	monday_10_wde Timestamptz;

	tuesday_11_wds Timestamptz;

	wednesday_12_wde Timestamptz;

	thursday_13_wds Timestamptz;

	friday_14_noon Timestamptz;

	monday_31_wde Timestamptz;

	monday_14_feb_wde Timestamptz;
BEGIN
	friday_17_dec_wds := '1999-12-17 9:00:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';
	friday_31_dec_noon = '1999-12-31 12:00:00.0'::Timestamp AT TIME ZONE 'UTC';

	saturday_01_noon := '2000-01-01 12:00:00.0'::Timestamp AT TIME ZONE 'UTC';

	sunday_02_noon := '2000-01-02 12:00:00.0'::Timestamp AT TIME ZONE 'UTC';

	monday_03_wds_minus := '2000-01-03 8:00:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';
	monday_03_noon := '2000-01-03 12:00:00.0'::Timestamp AT TIME ZONE 'UTC';
	monday_03_wde := '2000-01-03 18:30:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';

	tuesday_04_wde := '2000-01-04 18:30:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';

	wednesday_05_wds := '2000-01-05 09:00:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';

	thursday_06_wde := '2000-01-06 18:30:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';

	friday_07_wds := '2000-01-07 09:00:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';
	friday_07_wde := '2000-01-07 18:30:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';

	saturday_08_noon := '2000-01-08 12:00:00.0'::Timestamp AT TIME ZONE 'UTC';

	sunday_09_noon := '2000-01-09 12:00:00.0'::Timestamp AT TIME ZONE 'UTC';

	monday_10_noon := '2000-01-10 12:00:00.0'::Timestamp AT TIME ZONE 'UTC';
	monday_10_wde := '2000-01-10 18:30:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';

	tuesday_11_wds := '2000-01-11 09:00:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';

	wednesday_12_wde := '2000-01-12 18:30:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';

	thursday_13_wds := '2000-01-13 09:00:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';

	friday_14_noon := '2000-01-14 12:00:00.0'::Timestamp AT TIME ZONE 'UTC';

	monday_31_wde := '2000-01-31 18:30:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';

	monday_14_feb_wde := '2000-02-14 18:30:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';

	RETURN QUERY (
		-- Adding 0 days
		SELECT IS(
			add_working_days_delay(monday_03_noon, 0, 'Europe/Paris'),
			monday_03_noon,
			'0 workings days on Monday noon is Monday noon'
		)

		UNION ALL

		-- Adding positive days
		SELECT is(
			add_working_days_delay(monday_03_wds_minus, 1, 'Europe/Paris'),
			monday_03_wde,
			'1 working day on Monday early is Monday wde')

		UNION ALL

		SELECT is(
			add_working_days_delay(monday_03_noon, 1, 'Europe/Paris'),
			tuesday_04_wde,
			'1 working day on Monday noon is Tuesday wde'
		)

		UNION ALL

		SELECT is(
			add_working_days_delay(monday_03_noon, 3, 'Europe/Paris'),
			thursday_06_wde,
			'3 working days on Monday noon is Thursday wde'
		)

		UNION ALL

		SELECT is(
			add_working_days_delay(monday_03_noon, 5, 'Europe/Paris'),
			monday_10_wde,
			'5 working days on Monday noon is next Monday wde'
		)

		UNION ALL

		SELECT is(
			add_working_days_delay(monday_03_noon, 7, 'Europe/Paris'),
			wednesday_12_wde,
			'7 working days on Monday noon is Wednesday wde'
		)

		UNION ALL

		SELECT is(
			add_working_days_delay(monday_03_noon, 4 * 5, 'Europe/Paris'),
			monday_31_wde,
			'4 * 5 working days on Monday noon is Monday wde after 4 weeks'
		)

		UNION ALL

		SELECT is(
			add_working_days_delay(monday_03_noon, 6 * 5, 'Europe/Paris'),
			monday_14_feb_wde,
			'6 * 5 working days on Monday noon is Monday wde after 6 weeks'
		)

		UNION ALL

		SELECT is(
			add_working_days_delay(saturday_01_noon, 1, 'Europe/Paris'),
			monday_03_wde,
			'1 working day on Saturday is Monday'
		)

		UNION ALL

		SELECT is(
			add_working_days_delay(sunday_02_noon, 1, 'Europe/Paris'),
			monday_03_wde,
			'1 working day on Sunday is Monday'
		)

		UNION ALL

		SELECT is(
			add_working_days_delay(friday_31_dec_noon, 1, 'Europe/Paris'),
			monday_03_wde,
			'1 working day on Friday noon is Monday'
		)

		UNION ALL

		SELECT is(
			add_working_days_delay(saturday_01_noon, 5, 'Europe/Paris'),
			friday_07_wde,
			'5 working days on Saturday is Friday'
		)

		-- Adding negative days
		UNION ALL

		SELECT is(
			add_working_days_delay(friday_14_noon, -1, 'Europe/Paris'),
			thursday_13_wds,
			'-1 working day on Friday is Thursday'
		)

		UNION ALL

		SELECT is(
			add_working_days_delay(friday_14_noon, -3, 'Europe/Paris'),
			tuesday_11_wds,
			'-3 working days on Friday is Tuesday'
		)

		UNION ALL

		SELECT is(
			add_working_days_delay(friday_14_noon, -5, 'Europe/Paris'),
			friday_07_wds,
			'-5 working days on Friday is friday one week earlier'
		)

		UNION ALL

		SELECT is(
			add_working_days_delay(friday_14_noon, -7, 'Europe/Paris'),
			wednesday_05_wds,
			'-7 working days on Friday is Wednesday of previous week'
		)

		UNION ALL

		SELECT is(
			add_working_days_delay(friday_14_noon, -(4 * 5), 'Europe/Paris'),
			friday_17_dec_wds,
			'-(4 * 5) working days on Friday is Friday four weeks earlier'
		)


		UNION ALL

		SELECT is(
			add_working_days_delay(monday_10_noon, -1, 'Europe/Paris'),
			friday_07_wds,
			'-1 working day on Monday is Friday'
		)

		UNION ALL

		SELECT is(
			add_working_days_delay(sunday_09_noon, -1, 'Europe/Paris'),
			friday_07_wds,
			'-1 working day on Sunday is Friday'
		)

		UNION ALL

		SELECT is(
			add_working_days_delay(saturday_08_noon, -1, 'Europe/Paris'),
			friday_07_wds,
			'-1 working day on Saturday is Friday'
		)
	);
END;
$$;

alter function tunit_add_working_days_delay() owner to romain;

