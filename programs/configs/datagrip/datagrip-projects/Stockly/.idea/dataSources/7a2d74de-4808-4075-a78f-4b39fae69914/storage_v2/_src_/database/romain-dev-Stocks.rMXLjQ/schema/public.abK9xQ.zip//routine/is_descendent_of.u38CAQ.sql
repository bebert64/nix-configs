create function is_descendent_of(name, name, name, name) returns text
    language sql
as
$$
    SELECT ok(
        _ancestor_of( $3, $4, $1, $2, NULL ),
        'Table ' || quote_ident( $1 ) || '.' || quote_ident( $2 )
        || ' should be a descendent of '
        || quote_ident( $3 ) || '.' || quote_ident( $4 )
    );
$$;

alter function is_descendent_of(name, name, name, name) owner to romain;

