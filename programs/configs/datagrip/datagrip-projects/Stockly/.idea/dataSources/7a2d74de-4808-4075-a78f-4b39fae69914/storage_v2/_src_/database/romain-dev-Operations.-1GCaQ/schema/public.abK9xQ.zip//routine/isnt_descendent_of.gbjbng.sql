create function isnt_descendent_of(name, name, name, name) returns text
    language sql
as
$$
    SELECT ok(
       NOT  _ancestor_of( $3, $4, $1, $2, NULL ),
        'Table ' || quote_ident( $1 ) || '.' || quote_ident( $2 )
        || ' should not be a descendent of '
        || quote_ident( $3 ) || '.' || quote_ident( $4 )
    );
$$;

alter function isnt_descendent_of(name, name, name, name) owner to romain;

