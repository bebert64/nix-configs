create function policies__designatn_conflicts_with_stockly_programmatic_entity(arg_policy_id integer, arg_just_deleted_programmatic_entity_id integer) returns boolean
    language sql
as
$$
	SELECT
		EXISTS(
			SELECT 1
			FROM "policies" p
			INNER JOIN "stockly_programmatic_entities" spe ON spe.domain = split_part(p.designation, '.', 1)
			LEFT JOIN "programmatic_entities" pe ON pe.entity_id = p.created_by
			WHERE
			(p.id = arg_policy_id OR arg_policy_id IS NULL)
			AND (p.created_by = arg_just_deleted_programmatic_entity_id OR arg_just_deleted_programmatic_entity_id IS NULL)
			AND pe.entity_id IS NULL -- otherwise this is checked by the unique index on policies("designation", "created_by")
		);
$$;

alter function policies__designatn_conflicts_with_stockly_programmatic_entity(integer, integer) owner to romain;

