create function bbfs_history__no_delete_or_update() returns trigger
    language plpgsql
as
$$
BEGIN
	RAISE EXCEPTION
		'The `banned_brands_for_suppliers_history` table can only be inserted into. To ban/uban a brand, create a new row.';
	RETURN NULL;
END;
$$;

alter function bbfs_history__no_delete_or_update() owner to romain;

