create function _opc_exists(name) returns boolean
    language sql
as
$$
    SELECT EXISTS (
        SELECT TRUE
          FROM pg_catalog.pg_opclass oc
         WHERE oc.opcname = $1
           AND pg_opclass_is_visible(oid)
    );
$$;

alter function _opc_exists(name) owner to romain;

