create function index_is_primary(name, name, name) returns text
    language sql
as
$$
    SELECT index_is_primary(
        $1, $2, $3,
        'Index ' || quote_ident($3) || ' should be on a primary key'
    );
$$;

alter function index_is_primary(name, name, name) owner to romain;

