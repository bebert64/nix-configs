create function has_view(name, text) returns text
    language sql
as
$$
    SELECT ok( _rexists( 'v', $1 ), $2 );
$$;

alter function has_view(name, text) owner to romain;

