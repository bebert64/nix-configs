create function enums_are(name[]) returns text
    language sql
as
$$
    SELECT _types_are( $1, 'Search path ' || pg_catalog.current_setting('search_path') || ' should have the correct enums', ARRAY['e'] );
$$;

alter function enums_are(name[]) owner to romain;

