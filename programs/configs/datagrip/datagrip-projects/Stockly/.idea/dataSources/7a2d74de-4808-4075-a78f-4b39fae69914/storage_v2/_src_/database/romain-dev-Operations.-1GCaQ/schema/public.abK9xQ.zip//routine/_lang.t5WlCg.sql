create function _lang(name) returns name
    language sql
as
$$
    SELECT l.lanname
      FROM tap_funky f
      JOIN pg_catalog.pg_language l ON f.langoid = l.oid
     WHERE f.name = $1
       AND f.is_visible;
$$;

alter function _lang(name) owner to romain;

