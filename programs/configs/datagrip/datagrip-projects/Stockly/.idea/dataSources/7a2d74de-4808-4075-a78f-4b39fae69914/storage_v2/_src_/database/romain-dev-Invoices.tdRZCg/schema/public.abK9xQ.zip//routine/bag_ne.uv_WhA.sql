create function bag_ne(text, text, text) returns text
    language sql
as
$$
    SELECT _relne( $1, $2, $3, 'ALL ' );
$$;

alter function bag_ne(text, text, text) owner to romain;

