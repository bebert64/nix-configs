create function bag_has(text, text) returns text
    language sql
as
$$
    SELECT _relcomp( $1, $2, NULL::TEXT, 'EXCEPT ALL', 'Missing' );
$$;

alter function bag_has(text, text) owner to romain;

