create function is_procedure(name, name) returns text
    language sql
as
$$
    SELECT _func_compare(
        $1, $2, _type_func('p', $1, $2),
        'Function ' || quote_ident($1) || '.' || quote_ident($2) || '() should be a procedure'
    );
$$;

alter function is_procedure(name, name) owner to romain;

