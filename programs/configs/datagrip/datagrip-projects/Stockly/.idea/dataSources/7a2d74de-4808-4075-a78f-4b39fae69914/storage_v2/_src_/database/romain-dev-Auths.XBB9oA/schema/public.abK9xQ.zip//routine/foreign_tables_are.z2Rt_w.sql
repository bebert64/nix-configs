create function foreign_tables_are(name, name[], text) returns text
    language sql
as
$$
    SELECT _are( 'foreign tables', _extras('f', $1, $2), _missing('f', $1, $2), $3);
$$;

alter function foreign_tables_are(name, name[], text) owner to romain;

