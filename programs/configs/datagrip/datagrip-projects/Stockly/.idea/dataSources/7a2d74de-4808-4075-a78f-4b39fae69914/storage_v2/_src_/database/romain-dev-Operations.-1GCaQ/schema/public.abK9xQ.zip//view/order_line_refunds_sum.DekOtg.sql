create view order_line_refunds_sum(order_line_id, total_price_et, total_extra_shipping_price_et) as
SELECT order_line_id,
       sum(price_et)                AS total_price_et,
       sum(extra_shipping_price_et) AS total_extra_shipping_price_et
FROM order_line_refunds
GROUP BY order_line_id;

alter table order_line_refunds_sum
    owner to romain;

