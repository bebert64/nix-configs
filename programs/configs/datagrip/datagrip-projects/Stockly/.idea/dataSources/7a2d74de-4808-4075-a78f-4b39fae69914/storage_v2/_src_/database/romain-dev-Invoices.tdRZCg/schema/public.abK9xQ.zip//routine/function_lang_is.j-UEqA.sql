create function function_lang_is(name, name) returns text
    language sql
as
$$
    SELECT function_lang_is(
        $1, $2,
        'Function ' || quote_ident($1)
        || '() should be written in ' || quote_ident($2)
    );
$$;

alter function function_lang_is(name, name) owner to romain;

