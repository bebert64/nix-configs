create function display_time(date_time timestamp with time zone, time_zone text) returns text
    language plpgsql
as
$$
DECLARE
	duration_to_now interval;
	offset_to_utc numeric;

	abs_seconds numeric;
	abs_minutes numeric;
	abs_hours numeric;

	is_less_than_1_min bool;
	is_less_than_1_hour bool;
	is_less_than_3_hours bool;

	abs_duration_txt text;
BEGIN
	duration_to_now := now() - date_time;
	offset_to_utc := extract( hours from (now() at time zone time_zone) - now() at time zone 'UTC');
	abs_seconds := ROUND(ABS(extract(seconds from duration_to_now)));
	abs_minutes := ABS(extract(minutes from duration_to_now)) + ROUND(ABS(extract(seconds from duration_to_now)) / 60.0);
	abs_hours := ABS(extract(hours from duration_to_now)) + ROUND(ABS(extract(minutes from duration_to_now)::float / 60.0));

	is_less_than_1_min := (duration_to_now < '1 minute'::interval AND duration_to_now > '-1 minute'::interval);
	is_less_than_1_hour := (duration_to_now < '1 hour'::interval AND duration_to_now > '-1 hour'::interval);
	is_less_than_3_hours := (duration_to_now < '3 hour'::interval AND duration_to_now > '-3 hour'::interval);

	CASE
		WHEN duration_to_now < '1 second'::interval AND duration_to_now > '-1 second'::interval
			THEN abs_duration_txt = '< 1 sec';
		WHEN is_less_than_1_min AND abs_seconds = 1
			THEN abs_duration_txt = '1 sec';
		WHEN is_less_than_1_min
			THEN abs_duration_txt = abs_seconds || ' secs';
		WHEN is_less_than_1_hour AND abs_minutes = 1
			THEN abs_duration_txt = '1 min';
		WHEN is_less_than_1_hour
			THEN abs_duration_txt = abs_minutes || ' mins';
		WHEN is_less_than_3_hours AND abs_hours = 1
			THEN abs_duration_txt = '1 hour';
		WHEN is_less_than_3_hours
			THEN abs_duration_txt = abs_hours || ' hours';
		ELSE
			return 'at '
				|| to_char(date_time at time zone time_zone, 'HH24:MI')
				|| (CASE
						WHEN (now() at time zone time_zone) = (now() at time zone 'CET')
							THEN ' CET'
						WHEN offset_to_utc = 0
							THEN ' UTC'
						WHEN offset_to_utc > 0
							THEN ' UTC+' || offset_to_utc
						ELSE
							' UTC' || offset_to_utc
					END);
	END CASE;

	IF now() > date_time
		THEN return abs_duration_txt || ' ago';
	ELSE
		return 'in ' || abs_duration_txt;
	END IF;
END;
$$;

alter function display_time(timestamp with time zone, text) owner to romain;

