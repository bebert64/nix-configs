create function index_owner_is(name, name, name, name) returns text
    language sql
as
$$
    SELECT index_owner_is(
        $1, $2, $3, $4,
        'Index ' || quote_ident($3) || ' ON '
        || quote_ident($1) || '.' || quote_ident($2)
        || ' should be owned by ' || quote_ident($4)
    );
$$;

alter function index_owner_is(name, name, name, name) owner to romain;

