create function _opc_exists(name, name) returns boolean
    language sql
as
$$
    SELECT EXISTS (
        SELECT TRUE
          FROM pg_catalog.pg_opclass oc
          JOIN pg_catalog.pg_namespace n ON oc.opcnamespace = n.oid
         WHERE n.nspname  = $1
           AND oc.opcname = $2
    );
$$;

alter function _opc_exists(name, name) owner to romain;

