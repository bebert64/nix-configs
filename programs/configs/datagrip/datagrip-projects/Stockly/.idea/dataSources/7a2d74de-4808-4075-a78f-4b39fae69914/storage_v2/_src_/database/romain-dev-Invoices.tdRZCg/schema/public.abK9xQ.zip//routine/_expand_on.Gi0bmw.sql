create function _expand_on(character) returns text
    immutable
    language sql
as
$$
   SELECT CASE $1
          WHEN '1' THEN 'SELECT'
          WHEN '2' THEN 'UPDATE'
          WHEN '3' THEN 'INSERT'
          WHEN '4' THEN 'DELETE'
          ELSE          'UNKNOWN' END
$$;

alter function _expand_on(char) owner to romain;

