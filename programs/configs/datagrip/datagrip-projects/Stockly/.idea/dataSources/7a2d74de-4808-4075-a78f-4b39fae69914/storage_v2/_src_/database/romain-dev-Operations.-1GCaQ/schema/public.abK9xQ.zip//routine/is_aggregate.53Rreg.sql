create function is_aggregate(name, text) returns text
    language sql
as
$$
    SELECT _func_compare(NULL, $1, _type_func('a', $1), $2 );
$$;

alter function is_aggregate(name, text) owner to romain;

