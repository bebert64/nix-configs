create function sum_of_purchase_refunds_exceeds_purchase_price_et(arg_purchase_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
	RETURN (EXISTS (
		SELECT * FROM purchases p
		INNER JOIN (
				SELECT pr.purchase_id, SUM(pr.price_et) as refunds_sum_et FROM purchase_refunds pr WHERE pr.flagged_as_erroneous_at IS NULL GROUP BY pr.purchase_id
			) pr_sum on p.id = pr_sum.purchase_id
		WHERE (p.id = arg_purchase_id OR arg_purchase_id IS NULL) AND pr_sum.refunds_sum_et > p.price_et + 1e-9
	));
END;
$$;

alter function sum_of_purchase_refunds_exceeds_purchase_price_et(integer) owner to romain;

