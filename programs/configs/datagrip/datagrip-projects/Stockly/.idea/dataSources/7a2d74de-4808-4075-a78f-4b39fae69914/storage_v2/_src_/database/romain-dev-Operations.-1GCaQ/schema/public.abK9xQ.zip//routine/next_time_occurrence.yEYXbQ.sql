create function next_time_occurrence(start_dt timestamp with time zone, time_zone text, limit_hour integer, limit_min integer, skip_days integer[]) returns timestamp with time zone
    language plpgsql
as
$$
DECLARE
	start_dt_in_time_zone Timestamp;
	target_dt_in_time_zone Timestamp;
BEGIN
	start_dt_in_time_zone := start_dt AT TIME ZONE time_zone;
	target_dt_in_time_zone := DATE_TRUNC('day', start_dt_in_time_zone) + make_interval(hours => limit_hour, mins => limit_min);
	IF target_dt_in_time_zone <= start_dt_in_time_zone THEN
		target_dt_in_time_zone := target_dt_in_time_zone + INTERVAL '1 day';
	END IF;

	WHILE EXTRACT(isodow FROM target_dt_in_time_zone) = ANY(skip_days) LOOP
		target_dt_in_time_zone := target_dt_in_time_zone + INTERVAL '1 day';
	END LOOP;

	RETURN target_dt_in_time_zone AT TIME ZONE time_zone;
END;
$$;

alter function next_time_occurrence(timestamp with time zone, text, integer, integer, integer[]) owner to romain;

