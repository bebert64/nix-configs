create function has_type(name, name) returns text
    language sql
as
$$
    SELECT has_type( $1, $2, 'Type ' || quote_ident($1) || '.' || quote_ident($2) || ' should exist' );
$$;

alter function has_type(name, name) owner to romain;

