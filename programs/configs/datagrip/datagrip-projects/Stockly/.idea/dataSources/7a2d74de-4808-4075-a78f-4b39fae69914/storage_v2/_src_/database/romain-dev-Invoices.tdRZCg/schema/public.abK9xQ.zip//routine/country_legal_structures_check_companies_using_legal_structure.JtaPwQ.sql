create function country_legal_structures_check_companies_using_legal_structure() returns trigger
    language plpgsql
as
$$
BEGIN
    IF OLD.invalidated_at IS NULL AND NEW.invalidated_at IS NOT NULL THEN
        IF EXISTS (
            SELECT 1
            FROM companies c
            JOIN legal_entities le ON le.id = c.legal_entity_id
            WHERE c.legal_structure = NEW.legal_structure
            AND le.country_alpha3 = NEW.country
            AND c.active_in_stockly_network
        ) THEN
            RAISE EXCEPTION 'Cannot invalidate legal structure "%" for country "%" as it is being used by active companies',
                NEW.legal_structure,
                NEW.country;
        END IF;
    ELSE
        IF EXISTS (
            SELECT 1
            FROM (
                SELECT legal_structure
                FROM companies c
                JOIN legal_entities le ON le.id = c.legal_entity_id
                WHERE c.legal_structure = OLD.legal_structure
                AND le.country_alpha3 = OLD.country

                UNION

                SELECT previous_legal_structure
                FROM company_legal_structure_history
                WHERE previous_legal_structure = OLD.legal_structure
            ) usage
        ) THEN
            RAISE EXCEPTION 'Cannot % legal structure "%" as it is being used or has historical usage',
                CASE TG_OP
                    WHEN 'DELETE' THEN 'delete'
                    WHEN 'UPDATE' THEN 'update'
                END,
                OLD.legal_structure;
        END IF;
    END IF;

    RETURN OLD;
END;
$$;

alter function country_legal_structures_check_companies_using_legal_structure() owner to romain;

