create function isnt_ancestor_of(name, name, integer) returns text
    language sql
as
$$
    SELECT ok(
        NOT  _ancestor_of( $1, $2, $3 ),
        'Table ' || quote_ident( $1 ) || ' should not be ancestor ' || $3 || ' of ' || quote_ident( $2)
    );
$$;

alter function isnt_ancestor_of(name, name, integer) owner to romain;

