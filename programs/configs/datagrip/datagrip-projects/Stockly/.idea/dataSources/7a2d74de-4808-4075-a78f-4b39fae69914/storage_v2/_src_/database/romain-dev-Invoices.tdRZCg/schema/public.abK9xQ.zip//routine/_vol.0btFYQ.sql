create function _vol(name, name[]) returns text
    language sql
as
$$
    SELECT _expand_vol(volatility)
      FROM tap_funky f
     WHERE f.name = $1
       AND f.args = _funkargs($2)
       AND f.is_visible;
$$;

alter function _vol(name, name[]) owner to romain;

