create function has_extension(name, text) returns text
    language sql
as
$$
    SELECT ok( _ext_exists( $1 ), $2)
$$;

alter function has_extension(name, text) owner to romain;

