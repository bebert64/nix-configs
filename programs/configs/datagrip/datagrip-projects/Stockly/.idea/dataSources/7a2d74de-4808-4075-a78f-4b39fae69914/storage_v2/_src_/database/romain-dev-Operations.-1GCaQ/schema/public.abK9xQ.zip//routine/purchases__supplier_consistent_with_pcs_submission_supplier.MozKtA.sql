create function purchases__supplier_consistent_with_pcs_submission_supplier() returns trigger
    language plpgsql
as
$$
BEGIN
	IF purchases__supplier_inconsistent_with_pcs_submission (NEW.id, NEW.purchases_shipping_id, NULL) THEN
		RAISE EXCEPTION 'purchases__supplier_consistent_with_pcs_submission_supplier';
	END IF;
	RETURN NULL;
END
$$;

alter function purchases__supplier_consistent_with_pcs_submission_supplier() owner to romain;

