create function results_ne(text, refcursor) returns text
    language sql
as
$$
    SELECT results_ne( $1, $2, NULL::text );
$$;

alter function results_ne(text, refcursor) owner to romain;

