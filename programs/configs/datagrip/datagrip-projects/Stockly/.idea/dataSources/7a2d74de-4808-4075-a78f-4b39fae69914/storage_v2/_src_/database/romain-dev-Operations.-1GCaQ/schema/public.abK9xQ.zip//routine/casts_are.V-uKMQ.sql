create function casts_are(text[]) returns text
    language sql
as
$$
    SELECT casts_are( $1, 'There should be the correct casts');
$$;

alter function casts_are(text[]) owner to romain;

