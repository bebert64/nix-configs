create function _get_rel_owner(character, name) returns name
    language sql
as
$$
    SELECT _get_rel_owner(ARRAY[$1], $2);
$$;

alter function _get_rel_owner(char, name) owner to romain;

