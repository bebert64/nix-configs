create function col_is_fk(name, name[]) returns text
    language sql
as
$$
    SELECT col_is_fk( $1, $2, 'Columns ' || quote_ident($1) || '(' || _ident_array_to_string($2, ', ') || ') should be a foreign key' );
$$;

alter function col_is_fk(name, name[]) owner to romain;

