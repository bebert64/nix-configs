create function has_materialized_view(name) returns text
    language sql
as
$$
    SELECT has_materialized_view( $1, 'Materialized view ' || quote_ident($1) || ' should exist' );
$$;

alter function has_materialized_view(name) owner to romain;

