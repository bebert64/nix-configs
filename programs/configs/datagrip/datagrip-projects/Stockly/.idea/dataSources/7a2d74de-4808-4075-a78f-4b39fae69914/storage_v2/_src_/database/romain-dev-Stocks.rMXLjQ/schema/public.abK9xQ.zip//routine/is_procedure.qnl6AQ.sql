create function is_procedure(name, name, name[]) returns text
    language sql
as
$$
    SELECT _func_compare(
        $1, $2, $3, _type_func('p', $1, $2, $3),
        'Function ' || quote_ident($1) || '.' || quote_ident($2) || '(' ||
        array_to_string($3, ', ') || ') should be a procedure'
    );
$$;

alter function is_procedure(name, name, name[]) owner to romain;

