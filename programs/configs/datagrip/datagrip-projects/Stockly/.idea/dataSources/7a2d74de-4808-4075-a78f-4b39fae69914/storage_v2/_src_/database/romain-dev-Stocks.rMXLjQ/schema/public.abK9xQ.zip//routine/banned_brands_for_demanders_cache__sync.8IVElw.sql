create function banned_brands_for_demanders_cache__sync() returns trigger
    language plpgsql
as
$$
BEGIN
	IF NEW.is_banned THEN
		INSERT INTO banned_brands_for_demanders_cache(demander_id, brand_interned_id)
			VALUES(NEW.demander_id, NEW.brand_interned_id)
			ON CONFLICT DO NOTHING;
	ELSE
		DELETE FROM banned_brands_for_demanders_cache
			WHERE brand_interned_id = NEW.brand_interned_id AND demander_id = NEW.demander_id;
	END IF;
	RETURN NEW;
END;
$$;

alter function banned_brands_for_demanders_cache__sync() owner to romain;

