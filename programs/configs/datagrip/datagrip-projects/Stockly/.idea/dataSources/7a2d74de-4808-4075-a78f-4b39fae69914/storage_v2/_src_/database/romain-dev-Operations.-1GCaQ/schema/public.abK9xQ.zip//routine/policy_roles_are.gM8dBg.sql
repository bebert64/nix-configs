create function policy_roles_are(name, name, name[], text) returns text
    language sql
as
$$
    SELECT _are(
        'policy roles',
        ARRAY(
            SELECT pr.rolname
              FROM pg_catalog.pg_policy AS pp
              JOIN pg_catalog.pg_roles AS pr ON pr.oid = ANY (pp.polroles)
              JOIN pg_catalog.pg_class AS pc ON pc.oid = pp.polrelid
              JOIN pg_catalog.pg_namespace AS pn ON pn.oid = pc.relnamespace
             WHERE pc.relname = $1
               AND pp.polname = $2
               AND pn.nspname NOT IN ('pg_catalog', 'information_schema')
            EXCEPT
            SELECT $3[i]
              FROM generate_series(1, array_upper($3, 1)) s(i)
        ),
        ARRAY(
            SELECT $3[i]
              FROM generate_series(1, array_upper($3, 1)) s(i)
            EXCEPT
            SELECT pr.rolname
              FROM pg_catalog.pg_policy AS pp
              JOIN pg_catalog.pg_roles AS pr ON pr.oid = ANY (pp.polroles)
              JOIN pg_catalog.pg_class AS pc ON pc.oid = pp.polrelid
              JOIN pg_catalog.pg_namespace AS pn ON pn.oid = pc.relnamespace
             WHERE pc.relname = $1
               AND pp.polname = $2
               AND pn.nspname NOT IN ('pg_catalog', 'information_schema')
        ),
        $4
    );
$$;

alter function policy_roles_are(name, name, name[], text) owner to romain;

