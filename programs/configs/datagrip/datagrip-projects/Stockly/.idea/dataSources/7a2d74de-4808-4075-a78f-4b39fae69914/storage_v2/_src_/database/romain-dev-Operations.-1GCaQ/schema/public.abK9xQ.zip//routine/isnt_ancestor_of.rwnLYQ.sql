create function isnt_ancestor_of(name, name, name, name) returns text
    language sql
as
$$
    SELECT ok(
        NOT  _ancestor_of( $1, $2, $3, $4, NULL ),
        'Table ' || quote_ident( $1 ) || '.' || quote_ident( $2 )
        || ' should not be an ancestor of '
        || quote_ident( $3 ) || '.' || quote_ident( $4 )
    );
$$;

alter function isnt_ancestor_of(name, name, name, name) owner to romain;

