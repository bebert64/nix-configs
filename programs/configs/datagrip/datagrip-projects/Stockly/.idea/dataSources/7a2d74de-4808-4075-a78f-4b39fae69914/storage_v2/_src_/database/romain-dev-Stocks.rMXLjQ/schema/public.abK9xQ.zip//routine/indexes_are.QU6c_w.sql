create function indexes_are(name, name, name[]) returns text
    language sql
as
$$
    SELECT indexes_are( $1, $2, $3, 'Table ' || quote_ident($1) || '.' || quote_ident($2) || ' should have the correct indexes' );
$$;

alter function indexes_are(name, name, name[]) owner to romain;

