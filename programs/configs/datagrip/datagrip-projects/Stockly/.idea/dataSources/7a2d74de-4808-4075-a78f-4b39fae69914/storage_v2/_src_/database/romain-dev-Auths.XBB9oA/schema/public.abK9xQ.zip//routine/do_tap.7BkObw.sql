create function do_tap(name, text) returns SETOF text
    language sql
as
$$
    SELECT * FROM _runem( findfuncs($1, $2), _is_verbose() );
$$;

alter function do_tap(name, text) owner to romain;

