create function hasnt_table(name) returns text
    language sql
as
$$
    SELECT hasnt_table( $1, 'Table ' || quote_ident($1) || ' should not exist' );
$$;

alter function hasnt_table(name) owner to romain;

