create function is_definer(name, name, text) returns text
    language sql
as
$$
    SELECT _func_compare($1, $2, _definer($1, $2), $3 );
$$;

alter function is_definer(name, name, text) owner to romain;

