create function ols_gmv(order_line_ids integer[]) returns double precision
    stable
    parallel safe
    language plpgsql
as
$$
BEGIN
    RETURN (SELECT
      SUM(COALESCE(os.client_price_et / os.nb_order_lines + ol.client_price_et + ol.client_extra_shipping_price_et, 0))
    FROM order_lines ol
    INNER JOIN (
        SELECT
            os.client_price_et,
            os.id,
            COUNT(*) as nb_order_lines
        FROM
            order_shippings os
            INNER JOIN order_lines ol_inner on os.id = ol_inner.order_shipping_id
        GROUP BY os.id
    ) os ON ol.order_shipping_id = os.id
    WHERE ol.id = ANY (order_line_ids));
END;
$$;

alter function ols_gmv(integer[]) owner to romain;

