create function received_order_msgs__insert_no_answer_required_notif() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NEW.flagged_as_no_answer_required_at IS NOT NULL AND OLD.flagged_as_no_answer_required_at IS NULL) THEN
		INSERT INTO public.no_answer_required_demander_notifications (order_message_id)
			VALUES (NEW.order_message_id);
	END IF;
	RETURN NULL;
END;
$$;

alter function received_order_msgs__insert_no_answer_required_notif() owner to romain;

