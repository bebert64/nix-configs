create function _has_role(name) returns boolean
    strict
    language sql
as
$$
    SELECT EXISTS(
        SELECT true
          FROM pg_catalog.pg_roles
         WHERE rolname = $1
    );
$$;

alter function _has_role(name) owner to romain;

