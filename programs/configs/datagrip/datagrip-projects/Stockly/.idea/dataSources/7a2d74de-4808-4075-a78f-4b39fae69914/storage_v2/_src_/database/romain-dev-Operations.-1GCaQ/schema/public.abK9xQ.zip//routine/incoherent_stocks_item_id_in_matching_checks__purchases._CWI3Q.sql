create function incoherent_stocks_item_id_in_matching_checks__purchases() returns trigger
    language plpgsql
as
$$
BEGIN
	IF incoherent_stocks_item_id_in_matching_checks(NULL, NULL, NEW.id) THEN
		RAISE 'Incoherent supplier_stocks_item_id'
		USING ERRCODE = 'check_violation', CONSTRAINT = 'matching_checks__incoherent_stocks_item_id', TABLE = 'purchases';
	END IF;
		RETURN NULL;
END
$$;

alter function incoherent_stocks_item_id_in_matching_checks__purchases() owner to romain;

