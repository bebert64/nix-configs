create function orders__owner_and_consumer_belong_to_same_demander(arg_owner_id integer, arg_consumer_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT
			*
		FROM
			"demander_persons" order_owner
			INNER JOIN
				"demander_persons" consumer
			ON
				consumer.id = arg_consumer_id
		WHERE
			order_owner.id = arg_owner_id
			AND consumer.demander_id = order_owner.demander_id
	);

	RETURN ret_val;
END
$$;

alter function orders__owner_and_consumer_belong_to_same_demander(integer, integer) owner to romain;

