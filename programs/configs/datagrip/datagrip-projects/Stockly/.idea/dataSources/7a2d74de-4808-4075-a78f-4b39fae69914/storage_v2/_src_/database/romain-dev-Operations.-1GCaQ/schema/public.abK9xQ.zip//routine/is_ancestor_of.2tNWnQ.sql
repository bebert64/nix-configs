create function is_ancestor_of(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _ancestor_of( $1, $2, NULL ), $3 );
$$;

alter function is_ancestor_of(name, name, text) owner to romain;

