create function prev_paris_day_start(start_dt timestamp with time zone) returns timestamp with time zone
    language plpgsql
as
$$
BEGIN RETURN prev_time_occurrence(start_dt, 'Europe/Paris', 9, 0, '{}'); END;
$$;

alter function prev_paris_day_start(timestamp with time zone) owner to romain;

