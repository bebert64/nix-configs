create function _strict(name) returns boolean
    language sql
as
$$
    SELECT is_strict FROM tap_funky WHERE name = $1 AND is_visible;
$$;

alter function _strict(name) owner to romain;

