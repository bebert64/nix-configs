create function _get_rel_owner(name, name) returns name
    language sql
as
$$
    SELECT pg_catalog.pg_get_userbyid(c.relowner)
      FROM pg_catalog.pg_class c
      JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
     WHERE n.nspname = $1
       AND c.relname = $2
$$;

alter function _get_rel_owner(name, name) owner to romain;

