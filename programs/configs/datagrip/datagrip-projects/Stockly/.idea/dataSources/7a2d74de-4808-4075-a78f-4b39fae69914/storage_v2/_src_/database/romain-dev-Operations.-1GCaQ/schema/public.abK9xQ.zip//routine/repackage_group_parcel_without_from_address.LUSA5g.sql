create function repackage_group_parcel_without_from_address(arg_parcel_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
	RETURN (SELECT EXISTS (
		SELECT *
		FROM
			parcels pa
			INNER JOIN repackage_groups_parcel rgpa ON pa.id = rgpa.parcel_id
		WHERE
			pa.id = arg_parcel_id
			AND pa.from_address_id IS NULL
	));
END;
$$;

alter function repackage_group_parcel_without_from_address(integer) owner to romain;

