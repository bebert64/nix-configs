create function is_aggregate(name) returns text
    language sql
as
$$
    SELECT _func_compare(
        NULL, $1,  _type_func('a', $1),
        'Function ' || quote_ident($1) || '() should be an aggregate function'
    );
$$;

alter function is_aggregate(name) owner to romain;

