create function pship_refunds__sum_of_pship_refunds_exceeds_pship_price_et() returns trigger
    language plpgsql
as
$$
BEGIN
	ASSERT NOT sum_of_pship_refunds_exceeds_pship_price_et(NEW.purchases_shipping_id);
	RETURN NULL;
END
$$;

alter function pship_refunds__sum_of_pship_refunds_exceeds_pship_price_et() owner to romain;

