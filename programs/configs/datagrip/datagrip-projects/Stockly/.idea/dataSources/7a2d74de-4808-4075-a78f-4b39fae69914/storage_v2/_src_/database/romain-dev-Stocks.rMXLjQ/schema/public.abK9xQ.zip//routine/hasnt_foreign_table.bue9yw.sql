create function hasnt_foreign_table(name) returns text
    language sql
as
$$
    SELECT hasnt_foreign_table( $1, 'Foreign table ' || quote_ident($1) || ' should not exist' );
$$;

alter function hasnt_foreign_table(name) owner to romain;

