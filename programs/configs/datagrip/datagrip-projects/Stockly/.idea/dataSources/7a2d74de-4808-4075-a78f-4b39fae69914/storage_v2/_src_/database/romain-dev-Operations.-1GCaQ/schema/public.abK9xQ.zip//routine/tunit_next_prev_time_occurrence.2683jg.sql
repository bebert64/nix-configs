create function tunit_next_prev_time_occurrence() returns SETOF text
    language plpgsql
as
$$
DECLARE
	last_friday_noon Timestamptz;
	last_sunday_noon Timestamptz;
	monday_noon Timestamptz;
	monday_before_noon Timestamptz;
	monday_after_noon Timestamptz;
	tuesday_noon Timestamptz;
	thursday_noon Timestamptz;
	friday_noon Timestamptz;
	saturday_noon Timestamptz;
	sunday_noon Timestamptz;
	next_monday_noon Timestamptz;
BEGIN
	last_friday_noon := '2024-07-12 12:00:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';
	last_sunday_noon := '2024-07-14 12:00:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';
	monday_noon := '2024-07-15 12:00:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';
	monday_before_noon := '2024-07-15 11:59:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';
	monday_after_noon := '2024-07-15 12:01:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';
	tuesday_noon := '2024-07-16 12:00:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';
	thursday_noon := '2024-07-18 12:00:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';
	friday_noon := '2024-07-19 12:00:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';
	saturday_noon := '2024-07-20 12:00:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';
	sunday_noon := '2024-07-21 12:00:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';
	next_monday_noon := '2024-07-22 12:00:00.0'::Timestamp AT TIME ZONE 'Europe/Paris';

	RETURN QUERY (
		SELECT IS(
			next_time_occurrence(monday_noon, 'Europe/Paris', 12, 00, '{}'),
			tuesday_noon,
			'next noon on Monday noon is Tuesday'
		)

		UNION ALL

		SELECT IS(
			next_time_occurrence(monday_before_noon, 'Europe/Paris', 12, 00, '{}'),
			monday_noon,
			'next noon on Monday before noon is Monday'
		)

		UNION ALL

		SELECT IS(
			prev_time_occurrence(monday_noon, 'Europe/Paris', 12, 00, '{}'),
			last_sunday_noon,
			'prev noon on Monday noon is Sunday'
		)

		UNION ALL

		SELECT IS(
			prev_time_occurrence(monday_after_noon, 'Europe/Paris', 12, 00, '{}'),
			monday_noon,
			'prev noon on Monday after noon is Monday'
		)

		UNION ALL

		SELECT IS(
			prev_time_occurrence(monday_noon, 'Europe/Paris', 12, 00, '{6, 7}'),
			last_friday_noon,
			'prev noon on Monday noon, skipping weekend, is Friday'
		)

		UNION ALL

		SELECT IS(
			next_time_occurrence(friday_noon, 'Europe/Paris', 12, 00, '{}'),
			saturday_noon,
			'next noon on Friday noon is Saturday'
		)

		UNION ALL

		SELECT IS(
			next_time_occurrence(friday_noon, 'Europe/Paris', 12, 00, '{6, 7}'),
			next_monday_noon,
			'next noon on Friday noon, skipping weekend, is Monday'
		)

		UNION ALL

		SELECT IS(
			prev_time_occurrence(friday_noon, 'Europe/Paris', 12, 00, '{}'),
			Thursday_noon,
			'prev noon on Friday noon is Thursday'
		)
	);
END;
$$;

alter function tunit_next_prev_time_occurrence() owner to romain;

