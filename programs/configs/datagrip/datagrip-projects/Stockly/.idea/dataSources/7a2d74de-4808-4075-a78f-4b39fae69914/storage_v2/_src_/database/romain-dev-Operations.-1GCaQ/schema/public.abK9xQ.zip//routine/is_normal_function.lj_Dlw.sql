create function is_normal_function(name, name, name[], text) returns text
    language sql
as
$$
    SELECT _func_compare($1, $2, $3, _type_func('f', $1, $2, $3), $4 );
$$;

alter function is_normal_function(name, name, name[], text) owner to romain;

