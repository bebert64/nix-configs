create function order_lines__check_unique_rsid_for_demander() returns trigger
    language plpgsql
as
$$
BEGIN
	IF order_lines__retailer_specific_id__already_exists (NEW.retailer_specific_id) THEN
		RAISE 'order_line RSID (%) already exists for demander linked to order_shipping_id (%)', NEW.retailer_specific_id, NEW.order_shipping_id
		USING ERRCODE = 'unique_violation', CONSTRAINT = 'order_lines__check_unique_rsid_for_demander', TABLE = 'order_lines';
	END IF;
		RETURN NULL;
END
$$;

alter function order_lines__check_unique_rsid_for_demander() owner to romain;

