create function is_aggregate(name, name, name[]) returns text
    language sql
as
$$
    SELECT _func_compare(
        $1, $2, $3, _type_func('a', $1, $2, $3),
        'Function ' || quote_ident($1) || '.' || quote_ident($2) || '(' ||
        array_to_string($3, ', ') || ') should be an aggregate function'
    );
$$;

alter function is_aggregate(name, name, name[]) owner to romain;

