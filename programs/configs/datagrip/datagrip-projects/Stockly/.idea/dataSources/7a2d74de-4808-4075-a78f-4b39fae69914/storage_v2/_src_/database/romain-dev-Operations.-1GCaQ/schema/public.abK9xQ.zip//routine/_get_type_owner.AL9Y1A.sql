create function _get_type_owner(name) returns name
    language sql
as
$$
    SELECT pg_catalog.pg_get_userbyid(typowner)
      FROM pg_catalog.pg_type
     WHERE typname = $1
       AND pg_catalog.pg_type_is_visible(oid)
$$;

alter function _get_type_owner(name) owner to romain;

