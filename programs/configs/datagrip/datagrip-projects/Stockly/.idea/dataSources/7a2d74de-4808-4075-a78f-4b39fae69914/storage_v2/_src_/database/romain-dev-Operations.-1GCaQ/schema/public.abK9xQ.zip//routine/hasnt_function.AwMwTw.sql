create function hasnt_function(name, name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _got_func($1, $2), $3 );
$$;

alter function hasnt_function(name, name, text) owner to romain;

