create function is_partitioned(name, text) returns text
    language sql
as
$$
    SELECT ok( _rexists('p', $1), $2);
$$;

alter function is_partitioned(name, text) owner to romain;

