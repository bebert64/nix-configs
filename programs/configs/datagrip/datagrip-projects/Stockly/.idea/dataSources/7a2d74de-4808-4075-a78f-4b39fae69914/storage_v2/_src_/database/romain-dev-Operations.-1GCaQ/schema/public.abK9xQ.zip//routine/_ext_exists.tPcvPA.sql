create function _ext_exists(name, name) returns boolean
    language sql
as
$$
    SELECT EXISTS (
        SELECT TRUE
          FROM pg_catalog.pg_extension ex
          JOIN pg_catalog.pg_namespace n ON ex.extnamespace = n.oid
         WHERE n.nspname  = $1
           AND ex.extname = $2
    );
$$;

alter function _ext_exists(name, name) owner to romain;

