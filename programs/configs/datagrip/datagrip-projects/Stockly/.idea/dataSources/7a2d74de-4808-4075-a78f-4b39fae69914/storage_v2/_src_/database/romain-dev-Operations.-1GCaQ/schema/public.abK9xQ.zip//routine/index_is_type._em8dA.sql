create function index_is_type(name, name, name, name) returns text
    language sql
as
$$
    SELECT index_is_type(
        $1, $2, $3, $4,
        'Index ' || quote_ident($3) || ' should be a ' || quote_ident($4) || ' index'
    );
$$;

alter function index_is_type(name, name, name, name) owner to romain;

