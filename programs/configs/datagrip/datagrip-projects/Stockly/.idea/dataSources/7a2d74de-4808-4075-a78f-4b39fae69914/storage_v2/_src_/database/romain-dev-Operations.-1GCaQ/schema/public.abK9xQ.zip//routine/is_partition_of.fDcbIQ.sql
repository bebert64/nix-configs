create function is_partition_of(name, name, name, name) returns text
    language sql
as
$$
    SELECT ok(
        _partof($1, $2, $3, $4),
        'Table ' || quote_ident($1) || '.' || quote_ident($2) || ' should be a partition of '
        || quote_ident($3) || '.' || quote_ident($4)
    );
$$;

alter function is_partition_of(name, name, name, name) owner to romain;

