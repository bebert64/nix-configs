create function function_owner_is(name, name[], name) returns text
    language sql
as
$$
    SELECT function_owner_is(
        $1, $2, $3,
        'Function ' || quote_ident($1) || '(' ||
        array_to_string($2, ', ') || ') should be owned by ' || quote_ident($3)
    );
$$;

alter function function_owner_is(name, name[], name) owner to romain;

