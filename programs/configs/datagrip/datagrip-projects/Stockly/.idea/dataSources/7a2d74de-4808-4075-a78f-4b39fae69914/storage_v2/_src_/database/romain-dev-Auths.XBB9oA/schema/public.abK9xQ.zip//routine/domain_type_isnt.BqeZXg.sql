create function domain_type_isnt(text, text, text) returns text
    language plpgsql
as
$$
DECLARE
    actual_type TEXT := _get_dtype($1);
BEGIN
    IF actual_type IS NULL THEN
        RETURN fail( $3 ) || E'\n' || diag (
            '   Domain ' ||  $1 || ' does not exist'
        );
    END IF;

    RETURN isnt( actual_type, _typename($2), $3 );
END;
$$;

alter function domain_type_isnt(text, text, text) owner to romain;

