create function doesnt_match(anyelement, text) returns text
    language sql
as
$$
    SELECT _unalike( $1 !~ $2, $1, $2, NULL );
$$;

alter function doesnt_match(anyelement, text) owner to romain;

