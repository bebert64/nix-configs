create function isnt_aggregate(name, text) returns text
    language sql
as
$$
    SELECT _func_compare(NULL, $1, NOT _type_func('a', $1), $2 );
$$;

alter function isnt_aggregate(name, text) owner to romain;

