create function bbfd_cache__check_bbfd_history_consistency__insert() returns trigger
    language plpgsql
as
$$
BEGIN
	PERFORM banned_brands_for_dmds_cache__check_bbfd_history_consistency(NEW.demander_id, NEW.brand_interned_id, TRUE);
	RETURN NEW;
END;
$$;

alter function bbfd_cache__check_bbfd_history_consistency__insert() owner to romain;

