create function findfuncs(text) returns text[]
    language sql
as
$$
    SELECT findfuncs( $1, NULL )
$$;

alter function findfuncs(text) owner to romain;

