create function dsc__enforce_immutability_delete() returns trigger
    language plpgsql
as
$$
BEGIN
	RAISE EXCEPTION 'Cannot delete demander_shipping_contract.id = % since it may appear in the table invalidated_answer_demander_shipping_contracts. Consider deactivating instead of deleting.', OLD.id;
	RETURN OLD;
END;
$$;

alter function dsc__enforce_immutability_delete() owner to romain;

