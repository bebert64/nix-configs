create function materialized_view_owner_is(name, name, name) returns text
    language sql
as
$$
    SELECT materialized_view_owner_is(
        $1, $2, $3,
        'Materialized view ' || quote_ident($1) || '.' || quote_ident($2) || ' should be owned by ' || quote_ident($3)
    );
$$;

alter function materialized_view_owner_is(name, name, name) owner to romain;

