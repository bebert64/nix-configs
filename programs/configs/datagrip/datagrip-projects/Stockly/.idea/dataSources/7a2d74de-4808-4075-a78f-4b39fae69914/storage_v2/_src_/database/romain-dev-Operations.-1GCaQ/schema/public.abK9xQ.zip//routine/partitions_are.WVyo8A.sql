create function partitions_are(name, name, name[], text) returns text
    language sql
as
$$
    SELECT _are(
        'partitions',
        ARRAY(SELECT _parts($1, $2) EXCEPT SELECT unnest($3)),
        ARRAY(SELECT unnest($3) EXCEPT SELECT _parts($1, $2)),
        $4
    );
$$;

alter function partitions_are(name, name, name[], text) owner to romain;

