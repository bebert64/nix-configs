create function is_procedure(name, text) returns text
    language sql
as
$$
    SELECT _func_compare(NULL, $1, _type_func('p', $1), $2 );
$$;

alter function is_procedure(name, text) owner to romain;

