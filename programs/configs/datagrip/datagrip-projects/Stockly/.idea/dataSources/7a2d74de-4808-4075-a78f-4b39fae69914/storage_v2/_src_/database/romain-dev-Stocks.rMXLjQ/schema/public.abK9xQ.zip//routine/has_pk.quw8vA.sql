create function has_pk(name) returns text
    language sql
as
$$
    SELECT has_pk( $1, 'Table ' || quote_ident($1) || ' should have a primary key' );
$$;

alter function has_pk(name) owner to romain;

