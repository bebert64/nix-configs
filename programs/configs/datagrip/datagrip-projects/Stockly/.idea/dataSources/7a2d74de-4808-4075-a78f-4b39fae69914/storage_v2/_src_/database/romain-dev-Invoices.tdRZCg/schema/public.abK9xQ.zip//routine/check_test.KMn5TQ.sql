create function check_test(text, boolean, text, text, text) returns SETOF text
    language sql
as
$$
    SELECT * FROM check_test( $1, $2, $3, $4, $5, FALSE );
$$;

alter function check_test(text, boolean, text, text, text) owner to romain;

