create view purchases_submissions_amounts(id, supplier_id, amount, created_at) as
SELECT id,
       supplier_id,
       ((SELECT sum(pcs.price_et * (1::double precision + pcs.vat_rate)) AS sum
         FROM purchases pcs
                  JOIN purchases_shippings psh ON pcs.purchases_shipping_id = psh.id
         WHERE psh.submission_id = ps.id)) +
       ((SELECT sum(p.stockly_pays_et * (1::double precision + p.stockly_pays_vat_rate)) AS sum
         FROM parcels p
         WHERE (p.id IN (SELECT p_1.id
                         FROM parcel_items pi
                                  JOIN parcels p_1 ON p_1.id = pi.parcel_id
                                  JOIN purchases pcs ON pcs.id = pi.purchase_id
                                  JOIN purchases_shippings psh ON psh.id = pcs.purchases_shipping_id
                                  LEFT JOIN purchase_cancellations pc ON pc.id = pcs.cancellation_id
                                  LEFT JOIN purchase_cancellation_decisions pcd ON pcd.id = pc.decision_id
                         WHERE psh.submission_id = ps.id
                           AND NOT (EXISTS (SELECT
                                            FROM parcel_items pi_alias
                                            WHERE pi_alias.purchase_id = pcs.id
                                              AND (pi_alias.flagged_as_erroneous_at IS NULL OR
                                                   pc.supplier_reason IS NOT NULL OR
                                                   pc.decision_id IS NOT NULL AND pcd.details IS NULL OR
                                                   pcs.purchases_shipping_id IS NULL OR pc.supplier_reason IS NOT NULL)
                                              AND (pi_alias.created_at < pi.created_at OR
                                                   pi_alias.id < pi.id AND pi_alias.created_at = pi.created_at)))
                           AND (pi.flagged_as_erroneous_at IS NULL OR pc.supplier_reason IS NOT NULL OR
                                pc.decision_id IS NOT NULL AND pcd.details IS NULL OR
                                pcs.purchases_shipping_id IS NULL OR pc.supplier_reason IS NOT NULL))))) AS amount,
       created_at
FROM purchases_submissions ps;

alter table purchases_submissions_amounts
    owner to romain;

