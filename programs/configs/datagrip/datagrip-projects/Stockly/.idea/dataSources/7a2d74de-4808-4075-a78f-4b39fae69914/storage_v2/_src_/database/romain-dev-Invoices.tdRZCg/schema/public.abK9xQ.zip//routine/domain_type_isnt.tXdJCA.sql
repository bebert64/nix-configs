create function domain_type_isnt(text, text) returns text
    language sql
as
$$
    SELECT domain_type_isnt(
        $1, $2,
        'Domain ' || $1 || ' should not extend type ' || $2
    );
$$;

alter function domain_type_isnt(text, text) owner to romain;

