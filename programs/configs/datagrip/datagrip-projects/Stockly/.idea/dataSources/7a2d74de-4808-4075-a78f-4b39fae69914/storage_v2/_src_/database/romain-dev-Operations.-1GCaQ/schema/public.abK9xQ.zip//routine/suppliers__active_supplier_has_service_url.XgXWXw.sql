create function suppliers__active_supplier_has_service_url() returns trigger
    language plpgsql
as
$$
BEGIN
	IF active_supplier_without_service_url (NEW.retailer_id) THEN
		RAISE 'Supplier ID (%) cannot be active without a service url', NEW.retailer_id
		USING ERRCODE = 'integrity_constraint_violation', CONSTRAINT = 'active_supplier_without_service_url', TABLE = 'suppliers';
	END IF;
		RETURN NULL;
END
$$;

alter function suppliers__active_supplier_has_service_url() owner to romain;

