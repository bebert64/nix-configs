create function _get_tablespace_owner(name) returns name
    language sql
as
$$
    SELECT pg_catalog.pg_get_userbyid(spcowner)
      FROM pg_catalog.pg_tablespace
     WHERE spcname = $1;
$$;

alter function _get_tablespace_owner(name) owner to romain;

