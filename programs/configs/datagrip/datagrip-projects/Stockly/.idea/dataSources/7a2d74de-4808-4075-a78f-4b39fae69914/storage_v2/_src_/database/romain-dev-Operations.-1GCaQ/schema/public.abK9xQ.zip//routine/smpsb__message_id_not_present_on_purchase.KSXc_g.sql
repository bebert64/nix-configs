create function smpsb__message_id_not_present_on_purchase() returns trigger
    language plpgsql
as
$$
BEGIN
	IF non_unique_message_id_on_purchase_and_purchase_submission (NULL, NEW.supplier_message_id) THEN
		RAISE 'Message id (%) is already bound to a purchase', NEW.supplier_message_id
		USING ERRCODE = 'unique_violation', CONSTRAINT = 'smpsb__message_id_not_present_on_purchase', TABLE = 'supplier_message_purchases_submissions_bindings';
	END IF;
		RETURN NULL;
END
$$;

alter function smpsb__message_id_not_present_on_purchase() owner to romain;

