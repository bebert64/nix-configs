create function has_opclass(name, name) returns text
    language sql
as
$$
    SELECT ok( _opc_exists( $1, $2 ), 'Operator class ' || quote_ident($1) || '.' || quote_ident($2) || ' should exist' );
$$;

alter function has_opclass(name, name) owner to romain;

