create function enums_are(name, name[]) returns text
    language sql
as
$$
    SELECT _types_are( $1, $2, 'Schema ' || quote_ident($1) || ' should have the correct enums', ARRAY['e'] );
$$;

alter function enums_are(name, name[]) owner to romain;

