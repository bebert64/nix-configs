create function pass(text) returns text
    language sql
as
$$
    SELECT ok( TRUE, $1 );
$$;

alter function pass(text) owner to romain;

