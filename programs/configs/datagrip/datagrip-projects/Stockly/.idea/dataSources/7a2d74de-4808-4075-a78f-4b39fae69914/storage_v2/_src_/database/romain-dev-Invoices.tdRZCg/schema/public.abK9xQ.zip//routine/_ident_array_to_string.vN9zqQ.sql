create function _ident_array_to_string(name[], text) returns text
    immutable
    language sql
as
$$
    SELECT array_to_string(ARRAY(
        SELECT quote_ident($1[i])
          FROM generate_series(1, array_upper($1, 1)) s(i)
         ORDER BY i
    ), $2);
$$;

alter function _ident_array_to_string(name[], text) owner to romain;

