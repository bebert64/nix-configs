create function isnt_strict(name, name, name[], text) returns text
    language sql
as
$$
    SELECT _func_compare($1, $2, $3, NOT _strict($1, $2, $3), $4 );
$$;

alter function isnt_strict(name, name, name[], text) owner to romain;

