create function operators_are(text[]) returns text
    language sql
as
$$
    SELECT operators_are($1, 'There should be the correct operators')
$$;

alter function operators_are(text[]) owner to romain;

