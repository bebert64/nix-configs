create function isnt_descendent_of(name, name, name, name, integer) returns text
    language sql
as
$$
    SELECT ok(
       NOT  _ancestor_of( $3, $4, $1, $2, $5 ),
        'Table ' || quote_ident( $1 ) || '.' || quote_ident( $2 )
        || ' should not be descendent ' || $5 || ' from '
        || quote_ident( $3 ) || '.' || quote_ident( $4 )
    );
$$;

alter function isnt_descendent_of(name, name, name, name, integer) owner to romain;

