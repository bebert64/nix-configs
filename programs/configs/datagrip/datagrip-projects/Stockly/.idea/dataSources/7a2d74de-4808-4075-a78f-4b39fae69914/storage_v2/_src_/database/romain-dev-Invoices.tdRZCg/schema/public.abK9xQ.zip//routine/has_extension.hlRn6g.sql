create function has_extension(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _ext_exists( $1, $2 ), $3 );
$$;

alter function has_extension(name, name, text) owner to romain;

