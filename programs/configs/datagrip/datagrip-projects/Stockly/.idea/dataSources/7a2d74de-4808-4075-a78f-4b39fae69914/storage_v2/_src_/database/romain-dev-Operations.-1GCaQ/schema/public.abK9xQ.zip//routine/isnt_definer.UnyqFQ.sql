create function isnt_definer(name, name[], text) returns text
    language sql
as
$$
    SELECT _func_compare(NULL, $1, $2, NOT _definer($1, $2), $3 );
$$;

alter function isnt_definer(name, name[], text) owner to romain;

