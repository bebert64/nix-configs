create function is_strict(name) returns text
    language sql
as
$$
    SELECT ok( _strict($1), 'Function ' || quote_ident($1) || '() should be strict' );
$$;

alter function is_strict(name) owner to romain;

