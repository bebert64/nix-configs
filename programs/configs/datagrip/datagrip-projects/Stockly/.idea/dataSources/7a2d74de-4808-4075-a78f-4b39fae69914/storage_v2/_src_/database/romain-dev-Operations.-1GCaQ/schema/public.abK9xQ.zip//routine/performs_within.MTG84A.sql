create function performs_within(text, numeric, numeric, text) returns text
    language sql
as
$$
SELECT performs_within(
          $1, $2, $3, 10, $4
        );
$$;

alter function performs_within(text, numeric, numeric, text) owner to romain;

