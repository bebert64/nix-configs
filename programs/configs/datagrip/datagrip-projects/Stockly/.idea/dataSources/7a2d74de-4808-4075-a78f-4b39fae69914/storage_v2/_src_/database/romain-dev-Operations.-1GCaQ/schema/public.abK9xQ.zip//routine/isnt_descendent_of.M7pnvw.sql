create function isnt_descendent_of(name, name, integer) returns text
    language sql
as
$$
    SELECT ok(
       NOT  _ancestor_of( $2, $1, $3 ),
        'Table ' || quote_ident( $1 ) || ' should not be descendent ' || $3 || ' from ' || quote_ident( $2)
    );
$$;

alter function isnt_descendent_of(name, name, integer) owner to romain;

