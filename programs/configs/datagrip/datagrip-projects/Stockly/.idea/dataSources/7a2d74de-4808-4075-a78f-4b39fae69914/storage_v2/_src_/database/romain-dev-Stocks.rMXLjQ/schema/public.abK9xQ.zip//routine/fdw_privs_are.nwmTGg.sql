create function fdw_privs_are(name, name, name[]) returns text
    language sql
as
$$
    SELECT fdw_privs_are(
        $1, $2, $3,
        'Role ' || quote_ident($2) || ' should be granted '
            || CASE WHEN $3[1] IS NULL THEN 'no privileges' ELSE array_to_string($3, ', ') END
            || ' on FDW ' || quote_ident($1)
    );
$$;

alter function fdw_privs_are(name, name, name[]) owner to romain;

