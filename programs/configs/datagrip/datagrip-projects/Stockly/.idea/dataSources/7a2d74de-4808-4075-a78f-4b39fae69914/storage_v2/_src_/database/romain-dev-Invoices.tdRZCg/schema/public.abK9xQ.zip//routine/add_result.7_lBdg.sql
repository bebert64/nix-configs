create function add_result(boolean, boolean, text, text, text) returns integer
    language plpgsql
as
$$
BEGIN
    IF NOT $1 THEN PERFORM _set('failed', _get('failed') + 1); END IF;
    RETURN nextval('__tresults___numb_seq');
END;
$$;

alter function add_result(boolean, boolean, text, text, text) owner to romain;

