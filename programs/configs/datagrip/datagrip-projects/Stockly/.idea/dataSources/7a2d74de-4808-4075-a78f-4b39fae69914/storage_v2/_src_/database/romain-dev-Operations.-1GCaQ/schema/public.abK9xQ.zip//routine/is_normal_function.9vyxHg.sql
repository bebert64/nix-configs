create function is_normal_function(name, name) returns text
    language sql
as
$$
    SELECT _func_compare(
        $1, $2, _type_func('f', $1, $2),
        'Function ' || quote_ident($1) || '.' || quote_ident($2) || '() should be a normal function'
    );
$$;

alter function is_normal_function(name, name) owner to romain;

