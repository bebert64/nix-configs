create function hasnt_rule(name, name, name, text) returns text
    language sql
as
$$
    SELECT ok( _is_instead($1, $2, $3) IS NULL, $4 );
$$;

alter function hasnt_rule(name, name, name, text) owner to romain;

