create function _rule_on(name, name) returns "char"
    language sql
as
$$
    SELECT r.ev_type
      FROM pg_catalog.pg_rewrite r
      JOIN pg_catalog.pg_class c     ON c.oid = r.ev_class
     WHERE r.rulename = $2
       AND c.relname  = $1
$$;

alter function _rule_on(name, name) owner to romain;

