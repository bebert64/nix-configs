create function policy_cmd_is(name, name, name, text) returns text
    language sql
as
$$
    SELECT policy_cmd_is(
        $1, $2, $3, $4,
        'Policy ' || quote_ident($3)
        || ' for table ' || quote_ident($1) || '.' || quote_ident($2)
        || ' should apply to ' || upper($4) || ' command'
    );
$$;

alter function policy_cmd_is(name, name, name, text) owner to romain;

