create function isnt_descendent_of(name, name, integer, text) returns text
    language sql
as
$$
    SELECT ok(NOT  _ancestor_of( $2, $1, $3 ), $4 );
$$;

alter function isnt_descendent_of(name, name, integer, text) owner to romain;

