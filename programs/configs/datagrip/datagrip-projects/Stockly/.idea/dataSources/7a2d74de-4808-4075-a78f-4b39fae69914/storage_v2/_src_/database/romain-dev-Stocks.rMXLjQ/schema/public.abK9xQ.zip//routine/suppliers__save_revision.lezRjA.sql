create function suppliers__save_revision() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NEW.retailer_id != OLD.retailer_id) THEN
		RAISE EXCEPTION 'You can''t change a supplier ID (% to %)',  OLD.id, NEW.id;
	END IF;
	IF (NEW.* IS DISTINCT FROM OLD.*) THEN
		INSERT INTO supplier_revisions(
			supplier_id,
			extra_attr_cost_flat,
			fake_distribution_prices_before_submission_rate,
			block_distribution_reason,
			restrict_distribution_percentage,
			enforced_has_neutral_packaging_value,
			min_item_quantity_for_distribution,
			max_item_weight_kg_for_distribution,
			expected_vat_for_new_transactions,
			drop_integration_reason
		)
		VALUES(
			OLD.retailer_id,
			OLD.extra_attr_cost_flat,
			OLD.fake_distribution_prices_before_submission_rate,
			OLD.block_distribution_reason,
			OLD.restrict_distribution_percentage,
			OLD.enforced_has_neutral_packaging_value,
			OLD.min_item_quantity_for_distribution,
			OLD.max_item_weight_kg_for_distribution,
			OLD.expected_vat_for_new_transactions,
			OLD.drop_integration_reason
		);
	END IF;
	RETURN NULL;
END;
$$;

alter function suppliers__save_revision() owner to romain;

