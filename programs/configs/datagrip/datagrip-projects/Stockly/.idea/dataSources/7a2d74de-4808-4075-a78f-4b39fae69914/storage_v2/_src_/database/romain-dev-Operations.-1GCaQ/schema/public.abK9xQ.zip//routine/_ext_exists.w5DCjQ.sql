create function _ext_exists(name) returns boolean
    language sql
as
$$
    SELECT EXISTS (
        SELECT TRUE
          FROM pg_catalog.pg_extension ex
         WHERE ex.extname = $1
    );
$$;

alter function _ext_exists(name) owner to romain;

