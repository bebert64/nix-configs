create function order_line_refunds__check_unique_rsid_for_demander() returns trigger
    language plpgsql
as
$$
BEGIN
	IF EXISTS(SELECT *
			FROM order_line_refunds olr
				INNER JOIN order_lines ol ON olr.order_line_id = ol.id
				INNER JOIN order_shippings os ON ol.order_shipping_id = os.id
				INNER JOIN orders o ON os.order_id = o.id
				INNER JOIN demander_persons dp ON o.owner_id = dp.id
				INNER JOIN demander_persons dp2 ON dp2.demander_id = dp.demander_id
				INNER JOIN orders o2 ON o2.owner_id = dp2.id
				INNER JOIN order_shippings os2 ON os2.order_id = o2.id
				INNER JOIN order_lines ol2 ON ol2.order_shipping_id = os2.id
			WHERE olr.retailer_specific_id = NEW.retailer_specific_id
				AND olr.id != NEW.id
				AND ol2.id = NEW.order_line_id)
	THEN
		RAISE EXCEPTION 'order_line_refunds__check_unique_rsid_for_demander FAILED';
	END IF;
	RETURN NULL;
END
$$;

alter function order_line_refunds__check_unique_rsid_for_demander() owner to romain;

