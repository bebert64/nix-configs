create function col_is_pk(name, name, text) returns text
    language sql
as
$$
    SELECT col_is_pk( $1, ARRAY[$2], $3 );
$$;

alter function col_is_pk(name, name, text) owner to romain;

