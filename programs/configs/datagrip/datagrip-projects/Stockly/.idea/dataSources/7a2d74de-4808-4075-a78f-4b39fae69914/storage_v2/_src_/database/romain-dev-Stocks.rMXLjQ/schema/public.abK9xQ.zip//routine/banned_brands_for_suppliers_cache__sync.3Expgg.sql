create function banned_brands_for_suppliers_cache__sync() returns trigger
    language plpgsql
as
$$
BEGIN
	IF NEW.is_banned THEN
		INSERT INTO banned_brands_for_suppliers_cache(supplier_id, brand_interned_id)
			VALUES(NEW.supplier_id, NEW.brand_interned_id)
			ON CONFLICT DO NOTHING;
	ELSE
		DELETE FROM banned_brands_for_suppliers_cache
			WHERE brand_interned_id = NEW.brand_interned_id AND supplier_id = NEW.supplier_id;
	END IF;
	RETURN NEW;
END;
$$;

alter function banned_brands_for_suppliers_cache__sync() owner to romain;

