create function _strict(name, name) returns boolean
    language sql
as
$$
    SELECT is_strict FROM tap_funky WHERE schema = $1 AND name = $2
$$;

alter function _strict(name, name) owner to romain;

