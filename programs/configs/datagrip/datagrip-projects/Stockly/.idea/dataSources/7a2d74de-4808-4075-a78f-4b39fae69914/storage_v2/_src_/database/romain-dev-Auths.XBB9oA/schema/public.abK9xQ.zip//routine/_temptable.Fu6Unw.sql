create function _temptable(text, text) returns text
    language plpgsql
as
$$
BEGIN
    EXECUTE 'CREATE TEMP TABLE ' || $2 || ' AS ' || _query($1);
    return $2;
END;
$$;

alter function _temptable(text, text) owner to romain;

