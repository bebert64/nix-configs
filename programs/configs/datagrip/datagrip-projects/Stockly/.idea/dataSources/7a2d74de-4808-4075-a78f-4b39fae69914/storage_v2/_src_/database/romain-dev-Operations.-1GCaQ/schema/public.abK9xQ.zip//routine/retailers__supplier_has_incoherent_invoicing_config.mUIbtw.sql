create function retailers__supplier_has_incoherent_invoicing_config() returns trigger
    language plpgsql
as
$$
BEGIN
	IF supplier_has_incoherent_invoicing_config(NEW.id) THEN
		RAISE EXCEPTION 'retailers__supplier_has_incoherent_invoicing_config';
	END IF;
	RETURN NULL;
END
$$;

alter function retailers__supplier_has_incoherent_invoicing_config() owner to romain;

