create function has_enum(name, name) returns text
    language sql
as
$$
    SELECT has_enum( $1, $2, 'Enum ' || quote_ident($1) || '.' || quote_ident($2) || ' should exist' );
$$;

alter function has_enum(name, name) owner to romain;

