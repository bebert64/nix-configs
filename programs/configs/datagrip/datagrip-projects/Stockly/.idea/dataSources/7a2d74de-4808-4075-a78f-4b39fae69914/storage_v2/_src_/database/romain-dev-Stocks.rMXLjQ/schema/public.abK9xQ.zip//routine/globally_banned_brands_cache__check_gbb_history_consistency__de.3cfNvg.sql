create function globally_banned_brands_cache__check_gbb_history_consistency__de() returns trigger
    language plpgsql
as
$$
BEGIN
	PERFORM globally_banned_brands_cache__check_gbb_history_consistency(OLD.brand_interned_id, FALSE);
	RETURN OLD;
END;
$$;

alter function globally_banned_brands_cache__check_gbb_history_consistency__de() owner to romain;

