create function orders__retailer_specific_id__already_exists(arg_id integer, arg_retailer_specific_id character varying, arg_order_owner_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT
			*
		FROM
			"orders" old_o
			INNER JOIN
				"demander_persons" old_dp
			ON
				old_dp.id = old_o.owner_id
			INNER JOIN
				"demander_persons" new_dp
			ON
				new_dp.id = arg_order_owner_id
		WHERE
			old_o.id != arg_id
			AND old_dp.demander_id = new_dp.demander_id
			AND old_o.retailer_specific_id = arg_retailer_specific_id
	);

	RETURN ret_val;
END
$$;

alter function orders__retailer_specific_id__already_exists(integer, varchar, integer) owner to romain;

