create function hasnt_index(name, name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _have_index( $1, $2 ), $3 );
$$;

alter function hasnt_index(name, name, text) owner to romain;

