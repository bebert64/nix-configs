create function diag_test_name(text) returns text
    language sql
as
$$
    SELECT diag($1 || '()');
$$;

alter function diag_test_name(text) owner to romain;

