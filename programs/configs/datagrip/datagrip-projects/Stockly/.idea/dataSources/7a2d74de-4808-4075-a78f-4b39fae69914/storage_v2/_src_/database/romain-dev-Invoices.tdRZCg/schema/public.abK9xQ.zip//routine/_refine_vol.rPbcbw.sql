create function _refine_vol(text) returns text
    immutable
    language sql
as
$$
    SELECT _expand_vol(substring(LOWER($1) FROM 1 FOR 1)::char);
$$;

alter function _refine_vol(text) owner to romain;

