create function do_tap() returns SETOF text
    language sql
as
$$
    SELECT * FROM _runem( findfuncs('^test'), _is_verbose());
$$;

alter function do_tap() owner to romain;

