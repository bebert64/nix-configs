create function banned_brands_cache__sync() returns trigger
    language plpgsql
as
$$
BEGIN
	IF NEW.is_banned THEN
		INSERT INTO banned_brands_cache(brand_interned_id)
			VALUES(NEW.brand_interned_id)
			ON CONFLICT DO NOTHING;
	ELSE
		DELETE FROM banned_brands_cache
			WHERE brand_interned_id = NEW.brand_interned_id;
	END IF;
END;
$$;

alter function banned_brands_cache__sync() owner to romain;

