create function add_working_days_delay(start_dt timestamp with time zone, days integer, raw_tz text) returns timestamp with time zone
    language plpgsql
as
$$
DECLARE
	start_dt_in_tz Timestamp;
BEGIN
	IF days > 0 THEN
		start_dt_in_tz := next_working_day_start(start_dt, raw_tz) AT TIME ZONE 'Europe/Paris';
		RETURN prev_working_day_end((start_dt_in_tz + ((FLOOR((((EXTRACT(isodow FROM start_dt_in_tz) - 1) + days) / 5)) * 2 + days) * INTERVAL '1 day')) AT TIME ZONE raw_tz, raw_tz);
	END IF;

	IF days = 0 THEN
		RETURN start_dt;
	END IF;

	IF days < 0 THEN
		start_dt_in_tz := prev_working_day_end(start_dt, raw_tz) AT TIME ZONE 'Europe/Paris';
		RETURN next_working_day_start((start_dt_in_tz - ((FLOOR((((-(EXTRACT(isodow FROM start_dt_in_tz) - 1) + 4) - days) / 5)) * 2 - days) * INTERVAL '1 day')) AT TIME ZONE raw_tz, raw_tz);
	END IF;
END;
$$;

alter function add_working_days_delay(timestamp with time zone, integer, text) owner to romain;

