create function display_oper(name, oid) returns text
    language sql
as
$$
    SELECT $1 || substring($2::regoperator::text, '[(][^)]+[)]$')
$$;

alter function display_oper(name, oid) owner to romain;

