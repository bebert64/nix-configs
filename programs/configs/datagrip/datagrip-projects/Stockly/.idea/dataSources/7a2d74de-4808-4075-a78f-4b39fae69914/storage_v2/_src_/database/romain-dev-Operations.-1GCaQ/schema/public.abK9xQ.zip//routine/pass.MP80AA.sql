create function pass() returns text
    language sql
as
$$
    SELECT ok( TRUE, NULL );
$$;

alter function pass() owner to romain;

