create function function_returns(name, text) returns text
    language sql
as
$$
    SELECT function_returns(
        $1, $2,
        'Function ' || quote_ident($1) || '() should return ' || $2
    );
$$;

alter function function_returns(name, text) owner to romain;

