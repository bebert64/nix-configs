create function results_ne(refcursor, anyarray, text) returns text
    language plpgsql
as
$$
DECLARE
    want REFCURSOR;
    res  TEXT;
BEGIN
    OPEN want FOR SELECT $2[i]
    FROM generate_series(array_lower($2, 1), array_upper($2, 1)) s(i);
    res := results_ne($1, want, $3);
    CLOSE want;
    RETURN res;
END;
$$;

alter function results_ne(refcursor, anyarray, text) owner to romain;

