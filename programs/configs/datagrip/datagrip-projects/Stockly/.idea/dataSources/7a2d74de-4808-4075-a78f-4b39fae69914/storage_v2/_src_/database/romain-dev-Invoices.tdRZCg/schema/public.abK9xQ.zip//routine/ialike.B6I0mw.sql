create function ialike(anyelement, text) returns text
    language sql
as
$$
    SELECT _alike( $1 ~~* $2, $1, $2, NULL );
$$;

alter function ialike(anyelement, text) owner to romain;

