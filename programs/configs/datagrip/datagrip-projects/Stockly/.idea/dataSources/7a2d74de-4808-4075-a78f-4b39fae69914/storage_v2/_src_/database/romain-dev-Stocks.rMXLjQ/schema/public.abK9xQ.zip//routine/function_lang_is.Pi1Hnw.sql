create function function_lang_is(name, name, name) returns text
    language sql
as
$$
    SELECT function_lang_is(
        $1, $2, $3,
        'Function ' || quote_ident($1) || '.' || quote_ident($2)
        || '() should be written in ' || quote_ident($3)
    );
$$;

alter function function_lang_is(name, name, name) owner to romain;

