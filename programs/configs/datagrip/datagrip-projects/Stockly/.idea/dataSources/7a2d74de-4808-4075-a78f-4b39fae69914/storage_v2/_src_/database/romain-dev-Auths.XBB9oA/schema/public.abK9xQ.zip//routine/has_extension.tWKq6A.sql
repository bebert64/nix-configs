create function has_extension(name, name) returns text
    language sql
as
$$
    SELECT ok(
        _ext_exists( $1, $2 ),
        'Extension ' || quote_ident($2)
        || ' should exist in schema ' || quote_ident($1) );
$$;

alter function has_extension(name, name) owner to romain;

