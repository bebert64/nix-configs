create function _get_language_owner(name) returns name
    language sql
as
$$
    SELECT pg_catalog.pg_get_userbyid(lanowner)
      FROM pg_catalog.pg_language
     WHERE lanname = $1;
$$;

alter function _get_language_owner(name) owner to romain;

