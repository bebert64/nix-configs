create function isnt_definer(name, text) returns text
    language sql
as
$$
    SELECT _func_compare(NULL, $1, NOT _definer($1), $2 );
$$;

alter function isnt_definer(name, text) owner to romain;

