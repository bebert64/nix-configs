create function do_tap(text) returns SETOF text
    language sql
as
$$
    SELECT * FROM _runem( findfuncs($1), _is_verbose() );
$$;

alter function do_tap(text) owner to romain;

