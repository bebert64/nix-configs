create function extensions_are(name[]) returns text
    language sql
as
$$
  SELECT extensions_are($1, 'Should have the correct extensions');
$$;

alter function extensions_are(name[]) owner to romain;

