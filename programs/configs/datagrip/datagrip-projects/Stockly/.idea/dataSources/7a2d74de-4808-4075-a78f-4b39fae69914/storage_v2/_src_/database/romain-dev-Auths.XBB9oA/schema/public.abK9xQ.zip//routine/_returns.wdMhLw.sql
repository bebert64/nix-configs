create function _returns(name, name[]) returns text
    language sql
as
$$
    SELECT returns
      FROM tap_funky
     WHERE name = $1
       AND args = _funkargs($2)
       AND is_visible;
$$;

alter function _returns(name, name[]) owner to romain;

