create function demanders__check_not_demander_without_legal_entity_id() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NEW.retailer_id != OLD.retailer_id) THEN
		RAISE EXCEPTION '% You can''t change a demander Id', NEW.retailer_id;
	END IF;
	IF (is_demander_without_legal_entity_id(NEW.retailer_id)) THEN
		RAISE 'Being a demander requires having a legal entity id'
			USING ERRCODE = 'integrity_constraint_violation',
				CONSTRAINT = 'check_not_demander_without_legal_entity_id',
				TABLE = 'demanders';
	END IF;
	RETURN NULL;
END
$$;

alter function demanders__check_not_demander_without_legal_entity_id() owner to romain;

