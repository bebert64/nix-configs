create function has_group(name) returns text
    language sql
as
$$
    SELECT ok( _has_group($1), 'Group ' || quote_ident($1) || ' should exist' );
$$;

alter function has_group(name) owner to romain;

