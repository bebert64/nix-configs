create function has_foreign_table(name) returns text
    language sql
as
$$
    SELECT has_foreign_table( $1, 'Foreign table ' || quote_ident($1) || ' should exist' );
$$;

alter function has_foreign_table(name) owner to romain;

