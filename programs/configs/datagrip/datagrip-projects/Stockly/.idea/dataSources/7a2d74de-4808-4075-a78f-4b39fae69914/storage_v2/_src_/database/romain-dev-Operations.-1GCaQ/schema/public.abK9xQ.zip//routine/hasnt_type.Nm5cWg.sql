create function hasnt_type(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _has_type( $1, NULL ), $2 );
$$;

alter function hasnt_type(name, text) owner to romain;

