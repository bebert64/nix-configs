create function hasnt_rule(name, name, name) returns text
    language sql
as
$$
    SELECT ok( _is_instead($1, $2, $3) IS NULL, 'Relation ' || quote_ident($1) || '.' || quote_ident($2) || ' should not have rule ' || quote_ident($3) );
$$;

alter function hasnt_rule(name, name, name) owner to romain;

