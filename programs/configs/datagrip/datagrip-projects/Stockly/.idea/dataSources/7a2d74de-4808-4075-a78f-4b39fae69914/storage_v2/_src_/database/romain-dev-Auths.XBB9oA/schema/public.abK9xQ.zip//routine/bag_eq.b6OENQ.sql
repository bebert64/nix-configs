create function bag_eq(text, anyarray, text) returns text
    language sql
as
$$
    SELECT _relcomp( $1, $2, $3, 'ALL ' );
$$;

alter function bag_eq(text, anyarray, text) owner to romain;

