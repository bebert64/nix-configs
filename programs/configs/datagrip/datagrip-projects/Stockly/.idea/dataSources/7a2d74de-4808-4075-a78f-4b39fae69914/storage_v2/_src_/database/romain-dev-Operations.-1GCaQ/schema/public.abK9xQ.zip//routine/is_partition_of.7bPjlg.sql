create function is_partition_of(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _partof($1, $2), $3);
$$;

alter function is_partition_of(name, name, text) owner to romain;

