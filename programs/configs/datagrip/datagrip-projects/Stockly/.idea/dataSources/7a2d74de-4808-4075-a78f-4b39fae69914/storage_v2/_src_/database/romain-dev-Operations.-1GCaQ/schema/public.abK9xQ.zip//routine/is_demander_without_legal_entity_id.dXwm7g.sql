create function is_demander_without_legal_entity_id(arg_retailer_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
	RETURN (SELECT
		EXISTS (
			SELECT
				*
			FROM
				retailers r
				INNER JOIN demanders d ON d.retailer_id = r.id
			WHERE
				(r.id = arg_retailer_id OR arg_retailer_id IS NULL)
				AND r.invoices_legal_entity_id IS NULL
		)
	);
END;
$$;

alter function is_demander_without_legal_entity_id(integer) owner to romain;

