create function _extensions() returns SETOF name
    language sql
as
$$
    SELECT extname FROM pg_catalog.pg_extension
$$;

alter function _extensions() owner to romain;

