create procedure shift_columns_up(IN param_table oid, IN param_column_names text[], IN just_under_column text)
    language plpgsql
as
$$
DECLARE
	just_under_column_position information_schema.cardinal_number;
	drop_views text;
	drop_triggers text;
	rename_sql text;
	alter_create_sql text;
	table_name_glob text;
	set_sql text;
	alter_set_notnull_sql text;
	alter_set_default_sql text;
	alter_drop_old_sql text;
	set_comments text;
	create_indexes_sql text;
	create_constraints_sql text;
	create_views_sql text;
	create_triggers_sql text;
	full_sql text;
BEGIN
	SELECT a.attnum INTO just_under_column_position
		FROM pg_catalog.pg_attribute a
		JOIN pg_catalog.pg_class c ON a.attrelid = c.oid
		WHERE c.oid = param_table
		AND a.attname = just_under_column;
	DROP TABLE IF EXISTS shift_columns_up__columns_to_shift;
	CREATE TEMP TABLE shift_columns_up__columns_to_shift AS
		WITH attrdef AS (
			SELECT
				n.nspname,
				c.relname,
				pg_catalog.array_to_string(c.reloptions || array(select 'toast.' || x from pg_catalog.unnest(tc.reloptions) x), ', ') as relopts,
				c.relpersistence,
				a.attnum,
				a.attname,
				pg_catalog.format_type(a.atttypid, a.atttypmod) as atttype,
				(SELECT substring(pg_catalog.pg_get_expr(d.adbin, d.adrelid, true) for 128) FROM pg_catalog.pg_attrdef d
					WHERE d.adrelid = a.attrelid AND d.adnum = a.attnum AND a.atthasdef) as attdefault,
				a.attnotnull,
				(SELECT c.collname FROM pg_catalog.pg_collation c, pg_catalog.pg_type t
					WHERE c.oid = a.attcollation AND t.oid = a.atttypid AND a.attcollation <> t.typcollation) as attcollation,
				a.attidentity,
				a.attgenerated,
				pgd.description AS comment
			FROM pg_catalog.pg_attribute a
			JOIN pg_catalog.pg_class c ON a.attrelid = c.oid
			JOIN pg_catalog.pg_namespace n ON c.relnamespace = n.oid
			LEFT JOIN pg_catalog.pg_class tc ON (c.reltoastrelid = tc.oid)
			LEFT JOIN pg_catalog.pg_description pgd on (pgd.objoid = a.attrelid AND a.attnum = pgd.objsubid)
			WHERE a.attrelid = param_table
				AND a.attnum > just_under_column_position
				AND NOT a.attisdropped
				AND a.attname != ALL(param_column_names)
			ORDER BY a.attnum
		)
		SELECT
			attrdef.nspname as table_schema,
			attrdef.relname as table_name,
			attrdef.relopts,
			attrdef.relpersistence,
			attrdef.attname as column_name,
			format(
				'%s%s%s%s',
				attrdef.atttype,
				case when attrdef.attcollation is null then '' else format(' COLLATE %I', attrdef.attcollation) end,
				--case when attrdef.attnotnull then ' NOT NULL' else '' end,
				case
					when attrdef.attdefault is null then ''
					else
						case
							when attrdef.attgenerated = 's' then format(' GENERATED ALWAYS AS (%s) STORED', attrdef.attdefault)
							when attrdef.attgenerated <> '' then ' GENERATED AS NOT_IMPLEMENTED'
							else '' --format(' DEFAULT %s', attrdef.attdefault)
						end
				end,
				case
					when attrdef.attidentity <> '' then
						format(' GENERATED %s AS IDENTITY', case attrdef.attidentity when 'd' then 'BY DEFAULT' when 'a' then 'ALWAYS' else 'NOT_IMPLEMENTED' end)
					else ''
				end
			) as col_create_prefix_sql,
			attrdef.attnotnull,
			attrdef.attdefault,
			attrdef.comment
		FROM attrdef
		ORDER BY attrdef.attnum;
	SELECT format('%I.%I', table_schema, table_name) INTO table_name_glob FROM shift_columns_up__columns_to_shift;
	DROP TABLE IF EXISTS shift_columns_up__views;
	CREATE TEMP TABLE shift_columns_up__views AS
        SELECT u.viewname, u.definition
        FROM pg_views u
        INNER JOIN information_schema.view_table_usage v ON V.view_name = u.viewname
        WHERE v.table_name = (SELECT relname FROM pg_class WHERE oid = param_table);
	DROP TABLE IF EXISTS shift_columns_up__triggers;
	CREATE TEMP TABLE shift_columns_up__triggers AS
        SELECT oid, tgname
        FROM pg_trigger
        WHERE tgrelid = param_table
        AND tgisinternal = false;
	-- drop views
	SELECT string_agg(format('DROP VIEW %s', viewname), E';\n') INTO drop_views FROM shift_columns_up__views;
	-- drop triggers
	SELECT string_agg(format('DROP TRIGGER %s ON %s', tgname, table_name_glob), E';\n') INTO drop_triggers FROM shift_columns_up__triggers;
	-- rename old
	SELECT string_agg(format('ALTER TABLE %s RENAME COLUMN %I TO %I', table_name_glob, column_name, substring(column_name from 1 for 59) || '_old'), E';\n') INTO rename_sql
		FROM shift_columns_up__columns_to_shift;
	-- create new columns
	SELECT format('ALTER TABLE %s%s', table_name_glob, string_agg(
			format(E'\n\tADD COLUMN %I %s', column_name, col_create_prefix_sql), ','
		)) INTO alter_create_sql FROM shift_columns_up__columns_to_shift;
	-- copy data
	SELECT format('UPDATE %s SET%s', table_name_glob, string_agg(format(E'\n\t%I = %I', column_name, substring(column_name from 1 for 59) || '_old'), ','))
		INTO set_sql FROM shift_columns_up__columns_to_shift;
	-- set not null
	SELECT format('ALTER TABLE %s%s', table_name_glob, string_agg(
			format(E'\n\tALTER COLUMN %I SET NOT NULL', column_name)
		, ',')) INTO alter_set_notnull_sql FROM shift_columns_up__columns_to_shift WHERE attnotnull;
	-- set default
	SELECT format('ALTER TABLE %s%s', table_name_glob, string_agg(
			format(E'\n\tALTER COLUMN %I SET DEFAULT %s', column_name, attdefault)
		, ',')) INTO alter_set_default_sql FROM shift_columns_up__columns_to_shift WHERE attdefault IS NOT NULL;
	-- remove old columns
	SELECT format('ALTER TABLE %s%s', table_name_glob, string_agg(format(E'\n\tDROP COLUMN %I', substring(column_name from 1 for 59) || '_old'), ','))
		INTO alter_drop_old_sql FROM shift_columns_up__columns_to_shift;
	-- recreate comments
	SELECT string_agg(format(E'COMMENT ON COLUMN %s.%I IS %L;\n', table_name_glob, column_name, comment), '') INTO set_comments
		FROM shift_columns_up__columns_to_shift WHERE comment IS NOT NULL;
	-- recreate indexes
	SELECT string_agg(regexp_replace(pg_get_indexdef(i.indexrelid), E'^(.+)INDEX', '\1INDEX IF NOT EXISTS'), E';\n')
		INTO create_indexes_sql
		FROM pg_index i
		WHERE i.indrelid = param_table;
	-- recreate check and foreign key constraints
	SELECT format('ALTER TABLE %s%s', table_name_glob, string_agg(
			format(E'\n\tADD CONSTRAINT %I %s', pgc.conname, pg_get_constraintdef(pgc.oid))
		, ','))
		INTO create_constraints_sql
		FROM pg_constraint pgc
		WHERE pgc.conrelid = param_table
		AND (pgc.contype = 'c' AND EXISTS (
			SELECT * FROM information_schema.constraint_column_usage ccu
				INNER JOIN pg_namespace nsp ON nsp.nspname = ccu.constraint_schema
				INNER JOIN shift_columns_up__columns_to_shift cts
				ON cts.column_name = ccu.column_name
				WHERE pgc.conname = ccu.constraint_name
					and nsp.oid = pgc.connamespace
		)
		OR pgc.contype = 'f' AND EXISTS (
			SELECT * FROM information_schema.key_column_usage fcu
				INNER JOIN pg_namespace nsp ON nsp.nspname = fcu.constraint_schema
				INNER JOIN shift_columns_up__columns_to_shift cts
				ON cts.column_name = fcu.column_name
				WHERE pgc.conname = fcu.constraint_name
					and nsp.oid = pgc.connamespace
		));
	-- recreate views
	SELECT string_agg(format(E'CREATE VIEW %s AS\n%s', viewname, definition), E';\n') INTO create_views_sql
	    FROM shift_columns_up__views;
	-- recreate triggers
	SELECT string_agg(pg_get_triggerdef(oid), E';\n') INTO create_triggers_sql FROM shift_columns_up__triggers;
	full_sql = format(
		E'%s;\n%s;\n%s;\n%s;\n%s;\n%s%s%s;\n%s%s%s%s\n%s',
	    drop_views,
		drop_triggers,
		rename_sql,
		alter_create_sql,
		set_sql,
		CASE WHEN position(E'\n' in alter_set_notnull_sql) > 0 THEN alter_set_notnull_sql || E';\n' ELSE '' END,
		CASE WHEN position(E'\n' in alter_set_default_sql) > 0 THEN alter_set_default_sql || E';\n' ELSE '' END,
		alter_drop_old_sql,
		set_comments,
		CASE WHEN position(E'\n' in create_indexes_sql) > 0 THEN create_indexes_sql || E';\n' ELSE '' END,
		CASE WHEN position(E'\n' in create_constraints_sql) > 0 THEN create_constraints_sql || E';\n' ELSE '' END,
		create_views_sql,
		create_triggers_sql || E';\n'
	);
	RAISE NOTICE E'Executing shift_columns_up migration query:\n%', full_sql;
	EXECUTE full_sql;
END;
$$;

alter procedure shift_columns_up(oid, text[], text) owner to romain;

