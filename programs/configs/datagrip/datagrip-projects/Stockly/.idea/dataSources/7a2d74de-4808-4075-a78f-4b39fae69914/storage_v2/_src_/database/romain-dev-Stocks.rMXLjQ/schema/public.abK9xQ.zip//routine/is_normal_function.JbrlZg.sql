create function is_normal_function(name, name[], text) returns text
    language sql
as
$$
    SELECT _func_compare(NULL, $1, $2, _type_func('f', $1, $2), $3 );
$$;

alter function is_normal_function(name, name[], text) owner to romain;

