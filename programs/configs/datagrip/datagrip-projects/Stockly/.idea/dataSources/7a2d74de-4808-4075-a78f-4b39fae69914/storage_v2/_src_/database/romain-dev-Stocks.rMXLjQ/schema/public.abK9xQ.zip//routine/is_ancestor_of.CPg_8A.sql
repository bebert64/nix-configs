create function is_ancestor_of(name, name, integer, text) returns text
    language sql
as
$$
    SELECT ok( _ancestor_of( $1, $2, $3 ), $4 );
$$;

alter function is_ancestor_of(name, name, integer, text) owner to romain;

