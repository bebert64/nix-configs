create function has_function(name, name[], text) returns text
    language sql
as
$$
    SELECT ok( _got_func($1, $2), $3 );
$$;

alter function has_function(name, name[], text) owner to romain;

