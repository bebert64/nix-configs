create function _got_func(name, name) returns boolean
    language sql
as
$$
    SELECT EXISTS( SELECT TRUE FROM tap_funky WHERE schema = $1 AND name = $2 );
$$;

alter function _got_func(name, name) owner to romain;

