create view auto_submission_fails(purchase_id, supplier_id, created_at) as
SELECT purchase_id,
       supplier_id,
       created_at
FROM (SELECT pcs.id,
             pcs.supplier_id,
             pcs.created_at
      FROM purchases pcs
               LEFT JOIN problems p ON pcs.id = p.purchase_id
               LEFT JOIN problem_tags pt ON pt.problem_id = p.id
               LEFT JOIN (SELECT purchases_auto_submit_blocked_reason_history.purchase_id,
                                 max(purchases_auto_submit_blocked_reason_history.created_at) AS created_at
                          FROM purchases_auto_submit_blocked_reason_history
                          GROUP BY purchases_auto_submit_blocked_reason_history.purchase_id) pasbrh
                         ON pcs.id = pasbrh.purchase_id
      WHERE pcs.purchases_shipping_id IS NULL AND pcs.cancellation_id IS NULL AND ((pt.value::text = ANY
                                                                                    (ARRAY ['Auto Submission'::character varying, 'Failed Auto Submission'::character varying]::text[])) AND
                                                                                   pt.removed_at IS NULL OR
                                                                                   pcs.auto_submit_blocked_reason::text ~~
                                                                                   'Auto Submit failed%'::text) AND
            (p.explanation IS NULL OR p.acknowledged_at < (CURRENT_DATE - '1 day'::interval))
         OR pcs.auto_submit_blocked_reason::text = 'Auto Submit Attempted by Operations'::text AND
            pcs.purchases_shipping_id IS NULL AND pcs.cancellation_id IS NULL AND
            pasbrh.created_at < (now() - '00:30:00'::interval)
         OR pt.value::text = 'Integrations Manual Action Required'::text AND pt.removed_at IS NULL AND
            p.resolution IS NULL AND (p.explanation IS NULL OR p.acknowledged_at < (CURRENT_DATE - '1 day'::interval))
      UNION ALL
      SELECT pcs.id,
             pcs.supplier_id,
             pcs.created_at
      FROM auto_purchase_submission_failures af
               JOIN purchases pcs ON af.purchase_id = pcs.id
      WHERE pcs.cancellation_id IS NULL
        AND pcs.purchases_shipping_id IS NULL
        AND af.reason = 'Other_GuaranteedNotSubmittedRetryable'::auto_purchase_submission_failure_reason
      GROUP BY pcs.id, pcs.supplier_id, pcs.created_at
      HAVING pcs.created_at < CURRENT_DATE
          OR count(*) >= 5) purchases_with_as_fail_to_handle(purchase_id, supplier_id, created_at);

alter table auto_submission_fails
    owner to romain;

