create function materialized_views_are(name, name[]) returns text
    language sql
as
$$
    SELECT _are(
        'Materialized views', _extras('m', $1, $2), _missing('m', $1, $2),
        'Schema ' || quote_ident($1) || ' should have the correct materialized views'
    );
$$;

alter function materialized_views_are(name, name[]) owner to romain;

