create function col_default_is(name, name, text) returns text
    language sql
as
$$
    SELECT _cdi( $1, $2, $3 );
$$;

alter function col_default_is(name, name, text) owner to romain;

