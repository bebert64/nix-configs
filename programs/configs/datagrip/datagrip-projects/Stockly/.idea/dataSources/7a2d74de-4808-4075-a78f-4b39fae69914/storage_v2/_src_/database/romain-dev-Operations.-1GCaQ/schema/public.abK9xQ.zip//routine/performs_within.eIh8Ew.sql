create function performs_within(text, numeric, numeric, integer) returns text
    language sql
as
$$
SELECT performs_within(
          $1, $2, $3, $4,
          'Should run within ' || $2 || ' +/- ' || $3 || ' ms');
$$;

alter function performs_within(text, numeric, numeric, integer) owner to romain;

