create function _lang(name, name) returns name
    language sql
as
$$
    SELECT l.lanname
      FROM tap_funky f
      JOIN pg_catalog.pg_language l ON f.langoid = l.oid
     WHERE f.schema = $1
       and f.name   = $2
$$;

alter function _lang(name, name) owner to romain;

