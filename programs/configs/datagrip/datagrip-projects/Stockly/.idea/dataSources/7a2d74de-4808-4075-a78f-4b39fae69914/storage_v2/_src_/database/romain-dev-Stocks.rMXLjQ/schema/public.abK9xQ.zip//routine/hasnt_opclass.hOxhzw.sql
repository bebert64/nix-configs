create function hasnt_opclass(name, name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _opc_exists( $1, $2 ), $3 );
$$;

alter function hasnt_opclass(name, name, text) owner to romain;

