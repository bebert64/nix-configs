create function has_table(name, name) returns text
    language sql
as
$$
    SELECT ok(
        _rexists( '{r,p}'::char[], $1, $2 ),
        'Table ' || quote_ident($1) || '.' || quote_ident($2) || ' should exist'
    );
$$;

alter function has_table(name, name) owner to romain;

