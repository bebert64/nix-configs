create function repackage_groups_parcel__repackage_group_parcels_without_from_a() returns trigger
    language plpgsql
as
$$
BEGIN
	ASSERT NOT repackage_group_parcel_without_from_address(NEW.parcel_id);
	RETURN NULL;
END
$$;

alter function repackage_groups_parcel__repackage_group_parcels_without_from_a() owner to romain;

