create function add_days(start_dt timestamp with time zone, days integer, is_working_days boolean) returns timestamp with time zone
    language plpgsql
as
$$
BEGIN
    IF is_working_days
    THEN
        RETURN add_working_days(start_dt, days);
    ELSE
        RETURN start_dt + '1 days'::Interval * days;
    END IF;
END;
$$;

alter function add_days(timestamp with time zone, integer, boolean) owner to romain;

