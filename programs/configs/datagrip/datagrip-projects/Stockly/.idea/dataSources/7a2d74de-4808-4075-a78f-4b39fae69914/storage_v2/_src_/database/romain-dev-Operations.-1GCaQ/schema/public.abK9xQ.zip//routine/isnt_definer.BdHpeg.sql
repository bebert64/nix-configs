create function isnt_definer(name, name[]) returns text
    language sql
as
$$
    SELECT ok(
        NOT _definer($1, $2),
        'Function ' || quote_ident($1) || '(' ||
        array_to_string($2, ', ') || ') should not be security definer'
    );
$$;

alter function isnt_definer(name, name[]) owner to romain;

