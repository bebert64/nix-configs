create function check_test(text, boolean, text, text) returns SETOF text
    language sql
as
$$
    SELECT * FROM check_test( $1, $2, $3, $4, NULL, FALSE );
$$;

alter function check_test(text, boolean, text, text) owner to romain;

