create function is_definer(name, name) returns text
    language sql
as
$$
    SELECT ok(
        _definer($1, $2),
        'Function ' || quote_ident($1) || '.' || quote_ident($2) || '() should be security definer'
    );
$$;

alter function is_definer(name, name) owner to romain;

