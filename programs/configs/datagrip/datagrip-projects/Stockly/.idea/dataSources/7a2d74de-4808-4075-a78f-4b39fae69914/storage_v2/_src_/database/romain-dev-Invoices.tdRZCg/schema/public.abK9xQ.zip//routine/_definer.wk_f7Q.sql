create function _definer(name) returns boolean
    language sql
as
$$
    SELECT is_definer FROM tap_funky WHERE name = $1 AND is_visible;
$$;

alter function _definer(name) owner to romain;

