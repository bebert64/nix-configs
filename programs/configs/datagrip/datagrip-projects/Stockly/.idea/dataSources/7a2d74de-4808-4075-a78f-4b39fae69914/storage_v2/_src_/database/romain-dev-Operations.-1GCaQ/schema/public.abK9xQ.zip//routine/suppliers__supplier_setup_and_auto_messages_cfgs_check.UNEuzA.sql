create function suppliers__supplier_setup_and_auto_messages_cfgs_check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF incoherent_supplier_setup_and_automated_messages_cfgs(NEW.retailer_id, NULL) THEN
		RAISE 'Incoherent supplier configuration (retailer_id = %): auto_ask_demand_for_delivery_dispute_documents is true but supply_delivery_dispute__open is not configured', NEW.retailer_id
		USING
			ERRCODE = 'check_violation',
			TABLE = 'suppliers';
	END IF;
	RETURN NULL;
END
$$;

alter function suppliers__supplier_setup_and_auto_messages_cfgs_check() owner to romain;

