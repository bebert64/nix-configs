create function check_national_identification_number() returns trigger
    language plpgsql
as
$$
DECLARE
	regex text;
	format_as_var text;
BEGIN
	SELECT ninp."regex_pattern", ninp."format_as" INTO regex, format_as_var FROM legal_entities le
		INNER JOIN national_identification_number_patterns ninp ON ninp.country_alpha3 = le.country_alpha3
		WHERE le.id = NEW.legal_entity_id;
	
	IF format_as_var IS NOT NULL THEN
		NEW.national_identification_number = regexp_replace(NEW.national_identification_number, regex, format_as_var);
	END IF;

	IF NOT COALESCE(NEW.national_identification_number ~ regex, FALSE) THEN
		RAISE EXCEPTION 'National identification number does not match required pattern for legal entity''s country';
	END IF;

	RETURN NEW;
END
$$;

alter function check_national_identification_number() owner to romain;

