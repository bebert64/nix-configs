create function policies_are(name, name, name[], text) returns text
    language sql
as
$$
    SELECT _are(
        'policies',
        ARRAY(
            SELECT p.polname
              FROM pg_catalog.pg_policy p
              JOIN pg_catalog.pg_class c     ON c.oid = p.polrelid
              JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
             WHERE n.nspname = $1
               AND c.relname = $2
            EXCEPT
            SELECT $3[i]
              FROM generate_series(1, array_upper($3, 1)) s(i)
        ),
        ARRAY(
            SELECT $3[i]
              FROM generate_series(1, array_upper($3, 1)) s(i)
            EXCEPT
            SELECT p.polname
              FROM pg_catalog.pg_policy p
              JOIN pg_catalog.pg_class c     ON c.oid = p.polrelid
              JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
             WHERE n.nspname = $1
               AND c.relname = $2
        ),
        $4
    );
$$;

alter function policies_are(name, name, name[], text) owner to romain;

