create function hasnt_sequence(name) returns text
    language sql
as
$$
    SELECT hasnt_sequence( $1, 'Sequence ' || quote_ident($1) || ' should not exist' );
$$;

alter function hasnt_sequence(name) owner to romain;

