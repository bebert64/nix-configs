create function materialized_views_are(name[]) returns text
    language sql
as
$$
    SELECT _are(
        'Materialized views', _extras('m', $1), _missing('m', $1),
        'Search path ' || pg_catalog.current_setting('search_path') || ' should have the correct materialized views'
    );
$$;

alter function materialized_views_are(name[]) owner to romain;

