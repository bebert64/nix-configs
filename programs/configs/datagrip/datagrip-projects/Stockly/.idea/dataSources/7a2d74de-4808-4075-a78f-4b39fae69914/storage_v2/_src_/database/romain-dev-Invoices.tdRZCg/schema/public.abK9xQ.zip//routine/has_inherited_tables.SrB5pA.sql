create function has_inherited_tables(name, name) returns text
    language sql
as
$$
    SELECT ok(
        _inherited( $1, $2 ),
        'Table ' || quote_ident( $1 ) || '.' || quote_ident( $2 ) || ' should have descendents'
    );
$$;

alter function has_inherited_tables(name, name) owner to romain;

