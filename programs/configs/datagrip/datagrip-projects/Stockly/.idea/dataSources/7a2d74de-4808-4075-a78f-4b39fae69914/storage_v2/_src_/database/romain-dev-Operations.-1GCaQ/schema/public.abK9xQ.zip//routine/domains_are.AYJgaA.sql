create function domains_are(name, name[]) returns text
    language sql
as
$$
    SELECT _types_are( $1, $2, 'Schema ' || quote_ident($1) || ' should have the correct domains', ARRAY['d'] );
$$;

alter function domains_are(name, name[]) owner to romain;

