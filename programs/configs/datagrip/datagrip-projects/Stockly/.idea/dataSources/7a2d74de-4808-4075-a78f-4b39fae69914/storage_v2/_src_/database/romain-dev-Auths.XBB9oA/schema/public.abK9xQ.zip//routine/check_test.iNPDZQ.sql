create function check_test(text, boolean, text) returns SETOF text
    language sql
as
$$
    SELECT * FROM check_test( $1, $2, $3, NULL, NULL, FALSE );
$$;

alter function check_test(text, boolean, text) owner to romain;

