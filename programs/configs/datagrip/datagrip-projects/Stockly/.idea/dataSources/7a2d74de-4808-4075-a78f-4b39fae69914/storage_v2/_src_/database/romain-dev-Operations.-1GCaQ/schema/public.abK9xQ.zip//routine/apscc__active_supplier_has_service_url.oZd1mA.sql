create function apscc__active_supplier_has_service_url() returns trigger
    language plpgsql
as
$$
BEGIN
	IF active_supplier_without_service_url (NEW.supplier_id) THEN
		RAISE 'Supplier ID (%) cannot be active without a service url', NEW.supplier_id
		USING ERRCODE = 'integrity_constraint_violation', CONSTRAINT = 'active_supplier_without_service_url', TABLE = 'automated_purchase_submission_cron_configs';
	END IF;
		RETURN NULL;
END
$$;

alter function apscc__active_supplier_has_service_url() owner to romain;

