create function invoice_documents__direct_to_invoice_can_not_generate(arg_invoice_id integer, arg_invoice_document_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val Boolean;
BEGIN
	SELECT INTO ret_val NOT EXISTS (
		SELECT *
		FROM "invoice_documents"
			INNER JOIN "invoices"
			ON invoices.id = invoice_documents.invoice_id
		WHERE
			(invoices.id = arg_invoice_id OR arg_invoice_id IS NULL)
			AND (invoice_documents.id = arg_invoice_document_id OR arg_invoice_document_id IS NULL)
			AND invoices.generation_format IS NOT NULL
	);
	RETURN ret_val;
END
$$;

alter function invoice_documents__direct_to_invoice_can_not_generate(integer, integer) owner to romain;

