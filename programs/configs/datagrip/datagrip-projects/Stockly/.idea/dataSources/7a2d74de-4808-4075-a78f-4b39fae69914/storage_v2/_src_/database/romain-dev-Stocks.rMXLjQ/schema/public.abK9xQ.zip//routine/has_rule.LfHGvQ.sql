create function has_rule(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _is_instead($1, $2) IS NOT NULL, $3 );
$$;

alter function has_rule(name, name, text) owner to romain;

