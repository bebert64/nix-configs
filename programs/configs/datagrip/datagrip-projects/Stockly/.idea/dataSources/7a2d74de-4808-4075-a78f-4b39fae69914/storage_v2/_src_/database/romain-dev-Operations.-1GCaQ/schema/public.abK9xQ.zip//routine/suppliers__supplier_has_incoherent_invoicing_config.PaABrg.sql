create function suppliers__supplier_has_incoherent_invoicing_config() returns trigger
    language plpgsql
as
$$
BEGIN
	IF supplier_has_incoherent_invoicing_config(NEW.retailer_id) THEN
		RAISE EXCEPTION 'suppliers__supplier_has_incoherent_invoicing_config';
	END IF;
	RETURN NULL;
END
$$;

alter function suppliers__supplier_has_incoherent_invoicing_config() owner to romain;

