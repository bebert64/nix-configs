create function fail() returns text
    language sql
as
$$
    SELECT ok( FALSE, NULL );
$$;

alter function fail() owner to romain;

