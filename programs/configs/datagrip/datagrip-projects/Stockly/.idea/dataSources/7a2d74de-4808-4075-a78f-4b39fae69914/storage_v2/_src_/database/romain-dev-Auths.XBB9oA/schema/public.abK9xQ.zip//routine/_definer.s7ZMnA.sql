create function _definer(name, name) returns boolean
    language sql
as
$$
    SELECT is_definer FROM tap_funky WHERE schema = $1 AND name = $2
$$;

alter function _definer(name, name) owner to romain;

