create function _vol(name, name, name[]) returns text
    language sql
as
$$
    SELECT _expand_vol(volatility)
      FROM tap_funky f
     WHERE f.schema = $1
       and f.name   = $2
       AND f.args   = _funkargs($3)
$$;

alter function _vol(name, name, name[]) owner to romain;

