create function hasnt_function(name) returns text
    language sql
as
$$
    SELECT ok( NOT _got_func($1), 'Function ' || quote_ident($1) || '() should not exist' );
$$;

alter function hasnt_function(name) owner to romain;

