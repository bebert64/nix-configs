create function hasnt_language(name) returns text
    language sql
as
$$
    SELECT ok( _is_trusted($1) IS NULL, 'Procedural language ' || quote_ident($1) || ' should not exist' );
$$;

alter function hasnt_language(name) owner to romain;

