create function set_ne(text, anyarray, text) returns text
    language sql
as
$$
    SELECT _relne( $1, $2, $3, '' );
$$;

alter function set_ne(text, anyarray, text) owner to romain;

