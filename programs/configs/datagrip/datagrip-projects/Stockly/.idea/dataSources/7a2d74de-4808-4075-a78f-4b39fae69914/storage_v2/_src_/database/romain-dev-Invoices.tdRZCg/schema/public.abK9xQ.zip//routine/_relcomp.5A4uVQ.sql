create function _relcomp(text, anyarray, text, text) returns text
    language sql
as
$$
    SELECT _docomp(
        _temptable( $1, '__taphave__' ),
        _temptable( $2, '__tapwant__' ),
        $3, $4
    );
$$;

alter function _relcomp(text, anyarray, text, text) owner to romain;

