create function _cdi(name, name, anyelement) returns text
    language sql
as
$$
    SELECT col_default_is(
        $1, $2, $3,
        'Column ' || quote_ident($1) || '.' || quote_ident($2) || ' should default to '
        || COALESCE( quote_literal($3), 'NULL')
    );
$$;

alter function _cdi(name, name, anyelement) owner to romain;

