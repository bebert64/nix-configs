create function foreign_tables_are(name, name[]) returns text
    language sql
as
$$
    SELECT _are(
        'foreign tables', _extras('f', $1, $2), _missing('f', $1, $2),
        'Schema ' || quote_ident($1) || ' should have the correct foreign tables'
    );
$$;

alter function foreign_tables_are(name, name[]) owner to romain;

