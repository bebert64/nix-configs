create function _returns(name, name, name[]) returns text
    language sql
as
$$
    SELECT returns
      FROM tap_funky
     WHERE schema = $1
       AND name   = $2
       AND args   = _funkargs($3)
$$;

alter function _returns(name, name, name[]) owner to romain;

