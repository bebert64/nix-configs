create function _got_func(name, name[]) returns boolean
    language sql
as
$$
    SELECT EXISTS(
        SELECT TRUE
          FROM tap_funky
         WHERE name = $1
           AND args = _funkargs($2)
           AND is_visible
    );
$$;

alter function _got_func(name, name[]) owner to romain;

