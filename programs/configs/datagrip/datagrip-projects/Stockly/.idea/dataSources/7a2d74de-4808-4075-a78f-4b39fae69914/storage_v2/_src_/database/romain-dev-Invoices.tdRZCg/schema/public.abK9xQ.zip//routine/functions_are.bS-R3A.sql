create function functions_are(name, name[]) returns text
    language sql
as
$$
    SELECT functions_are( $1, $2, 'Schema ' || quote_ident($1) || ' should have the correct functions' );
$$;

alter function functions_are(name, name[]) owner to romain;

