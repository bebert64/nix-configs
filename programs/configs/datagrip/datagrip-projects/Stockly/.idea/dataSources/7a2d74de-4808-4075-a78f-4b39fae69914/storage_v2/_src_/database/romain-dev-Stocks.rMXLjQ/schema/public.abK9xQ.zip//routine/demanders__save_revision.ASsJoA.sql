create function demanders__save_revision() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NEW.retailer_id != OLD.retailer_id) THEN
		RAISE EXCEPTION '% You can''t change a demander ID', NEW.id;
	END IF;
	IF (NEW.* IS DISTINCT FROM OLD.*) THEN
		INSERT INTO demander_revisions(
			demander_id,
			allow_filling,
			block_filling_percentage,
			default_demander_take__flat_amount_et,
			default_demander_take__rate_value,
			demander_take__rate_source, 
			answer_pricing_mode_from,
			answer_pricing_mode_to,
			answer_stockly_default_take_rate_over_cash_in,
			answer_stockly_min_take_rate_over_cash_in,
			answer_max_price_increase_ratio,
			answer_ceil_price_it_to_multiple_of,
			answer_allow_max_price_violation_for_ceiling,
			answer_min_quantity,
			answer_notifications_url,
			answer_notifications_key
		)
		VALUES(
			OLD.retailer_id, 
			OLD.allow_filling, 
			OLD.block_filling_percentage, 
			OLD.default_demander_take__flat_amount_et,
			OLD.default_demander_take__rate_value,
			OLD.demander_take__rate_source,
			OLD.answer_pricing_mode_from, 
			OLD.answer_pricing_mode_to,
			OLD.answer_stockly_default_take_rate_over_cash_in,
			OLD.answer_stockly_min_take_rate_over_cash_in, 
			OLD.answer_max_price_increase_ratio,
			OLD.answer_ceil_price_it_to_multiple_of, 
			OLD.answer_allow_max_price_violation_for_ceiling,
			OLD.answer_min_quantity, 
			OLD.answer_notifications_url, 
			OLD.answer_notifications_key
		);
	END IF;
	RETURN NULL;
END;
$$;

alter function demanders__save_revision() owner to romain;

