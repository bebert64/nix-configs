create function _type_func("char", name) returns boolean
    language sql
as
$$
    SELECT kind = $1 FROM tap_funky WHERE name = $2 AND is_visible;
$$;

alter function _type_func("char", name) owner to romain;

