create function is_strict(name, text) returns text
    language sql
as
$$
    SELECT _func_compare(NULL, $1, _strict($1), $2 );
$$;

alter function is_strict(name, text) owner to romain;

