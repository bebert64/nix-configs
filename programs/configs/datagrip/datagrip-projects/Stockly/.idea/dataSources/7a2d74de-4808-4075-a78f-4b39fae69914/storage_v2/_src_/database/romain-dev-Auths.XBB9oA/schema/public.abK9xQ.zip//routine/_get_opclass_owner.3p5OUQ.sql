create function _get_opclass_owner(name, name) returns name
    language sql
as
$$
    SELECT pg_catalog.pg_get_userbyid(opcowner)
      FROM pg_catalog.pg_opclass oc
      JOIN pg_catalog.pg_namespace n ON oc.opcnamespace = n.oid
     WHERE n.nspname = $1
       AND opcname   = $2;
$$;

alter function _get_opclass_owner(name, name) owner to romain;

