create function has_composite(name) returns text
    language sql
as
$$
    SELECT has_composite( $1, 'Composite type ' || quote_ident($1) || ' should exist' );
$$;

alter function has_composite(name) owner to romain;

