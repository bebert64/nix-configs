create function hasnt_extension(name) returns text
    language sql
as
$$
    SELECT ok(
        NOT _ext_exists( $1 ),
        'Extension ' || quote_ident($1) || ' should not exist' );
$$;

alter function hasnt_extension(name) owner to romain;

