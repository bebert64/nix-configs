create function fn_purchase_refunds__doesnt_exceed_total_refund() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (sum_of_purchase_refunds_exceeds_purchase_price_et(NEW.purchase_id)) THEN
		RAISE EXCEPTION 'Sum of refunds exceed purchase % price' , NEW.purchase_id;
	END IF;
	RETURN NULL;
END
$$;

alter function fn_purchase_refunds__doesnt_exceed_total_refund() owner to romain;

