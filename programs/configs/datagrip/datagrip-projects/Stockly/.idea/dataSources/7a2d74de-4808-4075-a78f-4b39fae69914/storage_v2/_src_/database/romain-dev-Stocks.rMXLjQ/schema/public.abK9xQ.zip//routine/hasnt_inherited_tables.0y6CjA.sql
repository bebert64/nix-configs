create function hasnt_inherited_tables(name) returns text
    language sql
as
$$
    SELECT ok(
        NOT _inherited( $1 ),
        'Table ' || quote_ident( $1 ) || ' should not have descendents'
    );
$$;

alter function hasnt_inherited_tables(name) owner to romain;

