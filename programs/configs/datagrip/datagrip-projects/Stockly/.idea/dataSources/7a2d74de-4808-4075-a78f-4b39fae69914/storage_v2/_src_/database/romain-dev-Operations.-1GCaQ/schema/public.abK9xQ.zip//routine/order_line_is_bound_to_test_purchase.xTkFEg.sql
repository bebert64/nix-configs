create function order_line_is_bound_to_test_purchase(arg_order_line_id integer, arg_purchase_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
	RETURN(
		SELECT
			EXISTS(
				SELECT
					*
				FROM
					"order_lines" ol
					INNER JOIN "test_purchases" tp ON ol.purchase_id = tp.purchase_id
				WHERE(tp.purchase_id = arg_purchase_id
					OR arg_purchase_id IS NULL)
				AND(ol.id = arg_order_line_id
					OR arg_order_line_id IS NULL)));
END
$$;

alter function order_line_is_bound_to_test_purchase(integer, integer) owner to romain;

