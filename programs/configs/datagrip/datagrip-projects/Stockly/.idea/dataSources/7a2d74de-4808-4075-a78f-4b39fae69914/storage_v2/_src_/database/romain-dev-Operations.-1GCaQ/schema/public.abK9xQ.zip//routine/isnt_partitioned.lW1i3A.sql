create function isnt_partitioned(name, name) returns text
    language sql
as
$$
    SELECT ok(
        NOT _rexists('p', $1, $2),
        'Table ' || quote_ident($1) || '.' || quote_ident($2) || ' should not be partitioned'
    );
$$;

alter function isnt_partitioned(name, name) owner to romain;

