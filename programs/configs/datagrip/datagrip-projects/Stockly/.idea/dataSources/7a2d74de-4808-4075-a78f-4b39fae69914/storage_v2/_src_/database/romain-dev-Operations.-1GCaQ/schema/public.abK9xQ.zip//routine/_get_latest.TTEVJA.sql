create function _get_latest(text, integer) returns integer
    strict
    language plpgsql
as
$$
DECLARE
    ret integer;
BEGIN
    EXECUTE 'SELECT MAX(id) FROM __tcache__ WHERE label = ' ||
    quote_literal($1) || ' AND value = ' || $2 INTO ret;
    RETURN ret;
END;
$$;

alter function _get_latest(text, integer) owner to romain;

