create function order_lines__check_integration_refunds_not_exceed_total() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (order_line_refunds__integration_refunds_exceed_total(NEW.id)) THEN
		RAISE EXCEPTION 'Integration refunds of order_line % exceed total refund (order_line trigger)', NEW.id;
	END IF;
	RETURN NULL;
END
$$;

alter function order_lines__check_integration_refunds_not_exceed_total() owner to romain;

