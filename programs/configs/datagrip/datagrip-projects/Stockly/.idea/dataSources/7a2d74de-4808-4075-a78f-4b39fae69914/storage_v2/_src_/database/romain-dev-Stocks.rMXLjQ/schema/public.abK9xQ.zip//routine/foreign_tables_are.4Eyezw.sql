create function foreign_tables_are(name[], text) returns text
    language sql
as
$$
    SELECT _are( 'foreign tables', _extras('f', $1), _missing('f', $1), $2);
$$;

alter function foreign_tables_are(name[], text) owner to romain;

