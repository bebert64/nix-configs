create function findfuncs(name, text) returns text[]
    language sql
as
$$
    SELECT findfuncs( $1, $2, NULL )
$$;

alter function findfuncs(name, text) owner to romain;

