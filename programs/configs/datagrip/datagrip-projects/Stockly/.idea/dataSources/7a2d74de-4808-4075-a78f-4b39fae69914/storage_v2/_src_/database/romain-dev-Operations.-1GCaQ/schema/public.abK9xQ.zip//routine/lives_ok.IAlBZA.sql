create function lives_ok(text) returns text
    language sql
as
$$
    SELECT lives_ok( $1, NULL );
$$;

alter function lives_ok(text) owner to romain;

