create function supply_delivery_disputes__no_pcs_cancellation_check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (exists_open_pcs_cancellation_and_delivery_dispute(NULL, NULL, NULL, NULL, NEW.id, NULL)) THEN
		RAISE EXCEPTION 'supply_delivery_disputes__no_pcs_cancellation_check FAILED';
	END IF;
	RETURN NULL;
END
$$;

alter function supply_delivery_disputes__no_pcs_cancellation_check() owner to romain;

