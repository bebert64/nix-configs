create function order_lines__check_molpbp_handled_by_coherent_with_order_line_s() returns trigger
    language plpgsql
as
$$ BEGIN
	IF NOT molpbp_handled_by_coherent_with_order_line_state(NEW.id) THEN RAISE
	EXCEPTION
		'order_line is incoherent with handled_by in table manual_order_line_purchase_binding_process';

	END IF;

	RETURN NULL;

END $$;

alter function order_lines__check_molpbp_handled_by_coherent_with_order_line_s() owner to romain;

