create function _got_func(name, name, name[]) returns boolean
    language sql
as
$$
    SELECT EXISTS(
        SELECT TRUE
          FROM tap_funky
         WHERE schema = $1
           AND name   = $2
           AND args = _funkargs($3)
    );
$$;

alter function _got_func(name, name, name[]) owner to romain;

