create function materialized_views_are(name, name[], text) returns text
    language sql
as
$$
    SELECT _are( 'Materialized views', _extras('m', $1, $2), _missing('m', $1, $2), $3);
$$;

alter function materialized_views_are(name, name[], text) owner to romain;

