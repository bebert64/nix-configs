create function retailers__check_not_demander_without_legal_entity_id() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NEW.id != OLD.id) THEN
		RAISE EXCEPTION '% You can''t change a retailer Id', NEW.id;
	END IF;
	IF (is_demander_without_legal_entity_id(NEW.id)) THEN
		RAISE 'Being a demander requires having a legal entity id'
			USING ERRCODE = 'integrity_constraint_violation',
				CONSTRAINT = 'check_not_demander_without_legal_entity_id',
				TABLE = 'retailers';
	END IF;
	RETURN NULL;
END
$$;

alter function retailers__check_not_demander_without_legal_entity_id() owner to romain;

