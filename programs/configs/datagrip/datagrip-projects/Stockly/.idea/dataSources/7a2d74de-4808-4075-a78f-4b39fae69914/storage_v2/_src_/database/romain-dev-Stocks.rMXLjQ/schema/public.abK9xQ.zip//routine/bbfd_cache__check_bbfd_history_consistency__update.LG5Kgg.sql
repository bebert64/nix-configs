create function bbfd_cache__check_bbfd_history_consistency__update() returns trigger
    language plpgsql
as
$$
BEGIN
	IF NEW.* IS DISTINCT FROM OLD.* THEN
		RAISE EXCEPTION
			'The `banned_brands_for_demanders_cache` table should not be updated directly.';
	END IF;
	RETURN NULL;
END;
$$;

alter function bbfd_cache__check_bbfd_history_consistency__update() owner to romain;

