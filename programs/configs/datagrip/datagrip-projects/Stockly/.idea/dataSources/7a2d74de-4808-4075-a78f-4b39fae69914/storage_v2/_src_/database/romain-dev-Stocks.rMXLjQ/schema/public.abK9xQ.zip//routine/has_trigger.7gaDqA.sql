create function has_trigger(name, name) returns text
    language sql
as
$$
    SELECT ok( _trig($1, $2), 'Table ' || quote_ident($1) || ' should have trigger ' || quote_ident($2));
$$;

alter function has_trigger(name, name) owner to romain;

