create function isnt_partitioned(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _rexists('p', $1), $2);
$$;

alter function isnt_partitioned(name, text) owner to romain;

