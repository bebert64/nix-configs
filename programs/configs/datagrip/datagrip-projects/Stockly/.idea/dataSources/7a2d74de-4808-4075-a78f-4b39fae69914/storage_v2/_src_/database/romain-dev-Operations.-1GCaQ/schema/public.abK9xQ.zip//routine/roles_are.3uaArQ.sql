create function roles_are(name[]) returns text
    language sql
as
$$
    SELECT roles_are( $1, 'There should be the correct roles' );
$$;

alter function roles_are(name[]) owner to romain;

