create function destock_operation_lines_update__update_total_pcs_price() returns trigger
    language plpgsql
as
$$
BEGIN
	WITH purchase_sums AS (
		SELECT
			dol.destock_operation_id,
			SUM(p.price_et) as total_purchases_price_et
		FROM destock_operation_lines dol
		INNER JOIN purchases p ON p.id = dol.purchase_id
		WHERE dol.destock_operation_id IN
			(
				SELECT destock_operation_id
				FROM
					new_table
				UNION
				SELECT destock_operation_id
				FROM
					old_table
			)
		GROUP BY dol.destock_operation_id
	)
	UPDATE destock_operations
	SET total_purchases_price_et = ps.total_purchases_price_et
	FROM purchase_sums ps
	WHERE ps.destock_operation_id = destock_operations.id;

	RETURN NULL;
END;
$$;

alter function destock_operation_lines_update__update_total_pcs_price() owner to romain;

