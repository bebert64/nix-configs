create function col_type_is(name, name, name, text) returns text
    language sql
as
$$
    SELECT col_type_is( $1, $2, $3, $4, 'Column ' || quote_ident($1) || '.' || quote_ident($2) || '.' || quote_ident($3) || ' should be type ' || $4 );
$$;

alter function col_type_is(name, name, name, text) owner to romain;

