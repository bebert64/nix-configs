create function _relne(text, text, text, text) returns text
    language sql
as
$$
    SELECT _do_ne(
        _temptable( $1, '__taphave__' ),
        _temptable( $2, '__tapwant__' ),
        $3, $4
    );
$$;

alter function _relne(text, text, text, text) owner to romain;

