create function is_indexed(name, name[]) returns text
    language sql
as
$$
   SELECT ok(
       _is_indexed(NULL, $1, $2),
       'Should have an index on ' ||  quote_ident($1) || '(' || array_to_string( $2, ', ' ) || ')'
   );
$$;

alter function is_indexed(name, name[]) owner to romain;

