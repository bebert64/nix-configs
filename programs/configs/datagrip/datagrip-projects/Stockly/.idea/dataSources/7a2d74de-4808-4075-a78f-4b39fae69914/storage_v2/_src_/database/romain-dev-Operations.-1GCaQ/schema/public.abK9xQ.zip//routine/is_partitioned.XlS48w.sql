create function is_partitioned(name) returns text
    language sql
as
$$
    SELECT ok(
        _rexists('p', $1),
        'Table ' || quote_ident($1) || ' should be partitioned'
    );
$$;

alter function is_partitioned(name) owner to romain;

