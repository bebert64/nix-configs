create function index_owner_is(name, name, name) returns text
    language sql
as
$$
    SELECT index_owner_is(
        $1, $2, $3,
        'Index ' || quote_ident($2) || ' ON '
        || quote_ident($1) || ' should be owned by ' || quote_ident($3)
    );
$$;

alter function index_owner_is(name, name, name) owner to romain;

