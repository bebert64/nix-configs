create function function_returns(name, name, name[], text) returns text
    language sql
as
$$
    SELECT function_returns(
        $1, $2, $3, $4,
        'Function ' || quote_ident($1) || '.' || quote_ident($2) || '(' ||
        array_to_string($3, ', ') || ') should return ' || $4
    );
$$;

alter function function_returns(name, name, name[], text) owner to romain;

