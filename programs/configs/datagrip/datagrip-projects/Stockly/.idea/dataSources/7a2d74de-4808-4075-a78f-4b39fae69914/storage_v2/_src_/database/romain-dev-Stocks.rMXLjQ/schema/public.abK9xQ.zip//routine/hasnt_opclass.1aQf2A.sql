create function hasnt_opclass(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _opc_exists( $1 ), $2)
$$;

alter function hasnt_opclass(name, text) owner to romain;

