create function order_lines__order_owner_represents_demander__check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NOT demand__order_owner_represents_demander__check(NULL, NULL, NULL, NEW.id)) THEN
		RAISE EXCEPTION 'order_lines__order_owner_represents_demander__check FAILED';
	END IF;
	RETURN NULL;
END
$$;

alter function order_lines__order_owner_represents_demander__check() owner to romain;

