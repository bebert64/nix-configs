create function _is_verbose() returns boolean
    stable
    language sql
as
$$
    SELECT current_setting('client_min_messages') NOT IN (
        'warning', 'error', 'fatal', 'panic'
    );
$$;

alter function _is_verbose() owner to romain;

