create function _get_rel_owner(name) returns name
    language sql
as
$$
    SELECT pg_catalog.pg_get_userbyid(c.relowner)
      FROM pg_catalog.pg_class c
     WHERE c.relname = $1
       AND pg_catalog.pg_table_is_visible(c.oid)
$$;

alter function _get_rel_owner(name) owner to romain;

