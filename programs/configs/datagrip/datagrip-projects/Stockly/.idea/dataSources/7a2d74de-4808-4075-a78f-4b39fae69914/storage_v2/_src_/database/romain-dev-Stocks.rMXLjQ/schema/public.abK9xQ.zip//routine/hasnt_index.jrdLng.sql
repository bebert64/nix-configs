create function hasnt_index(name, name) returns text
    language sql
as
$$
    SELECT ok(
        NOT _have_index( $1, $2 ),
        'Index ' || quote_ident($2) || ' should not exist'
    );
$$;

alter function hasnt_index(name, name) owner to romain;

