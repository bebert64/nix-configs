create function is_english_version_missing(arg_message_template_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
	RETURN (
		SELECT NOT (
			EXISTS (
				SELECT
					1
				FROM
					message_template_language_versions
				WHERE
					message_template_id = arg_message_template_id
					AND language_alpha2 = 'EN'
					AND deactivated_at IS NULL
			)
		)
	);
END;
$$;

alter function is_english_version_missing(integer) owner to romain;

