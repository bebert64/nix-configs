create function isnt_aggregate(name, name) returns text
    language sql
as
$$
    SELECT _func_compare(
        $1, $2, NOT _type_func('a', $1, $2),
        'Function ' || quote_ident($1) || '.' || quote_ident($2) || '() should not be an aggregate function'
    );
$$;

alter function isnt_aggregate(name, name) owner to romain;

