create function isnt_partitioned(name, name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _rexists('p', $1, $2), $3);
$$;

alter function isnt_partitioned(name, name, text) owner to romain;

