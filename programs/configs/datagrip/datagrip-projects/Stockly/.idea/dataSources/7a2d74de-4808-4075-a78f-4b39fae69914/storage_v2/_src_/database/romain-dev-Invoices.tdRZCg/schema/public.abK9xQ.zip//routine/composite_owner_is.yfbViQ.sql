create function composite_owner_is(name, name) returns text
    language sql
as
$$
    SELECT composite_owner_is(
        $1, $2,
        'Composite type ' || quote_ident($1) || ' should be owned by ' || quote_ident($2)
    );
$$;

alter function composite_owner_is(name, name) owner to romain;

