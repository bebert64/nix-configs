create function hasnt_pk(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _hasc( $1, 'p' ), $2 );
$$;

alter function hasnt_pk(name, text) owner to romain;

