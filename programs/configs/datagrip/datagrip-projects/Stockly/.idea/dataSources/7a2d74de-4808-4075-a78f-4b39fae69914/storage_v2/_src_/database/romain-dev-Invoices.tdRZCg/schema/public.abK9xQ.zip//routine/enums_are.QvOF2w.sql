create function enums_are(name[], text) returns text
    language sql
as
$$
    SELECT _types_are( $1, $2, ARRAY['e'] );
$$;

alter function enums_are(name[], text) owner to romain;

