create function is_descendent_of(name, name, name, name, text) returns text
    language sql
as
$$
    SELECT ok( _ancestor_of( $3, $4, $1, $2, NULL ), $5 );
$$;

alter function is_descendent_of(name, name, name, name, text) owner to romain;

