create function add_working_days(start_dt timestamp with time zone, days integer) returns timestamp with time zone
    language plpgsql
as
$$
DECLARE
    num_days_from_monday Integer;
    new_date Timestamptz;
BEGIN
    IF days = 0
    THEN
        RETURN start_dt;
    END IF;

    num_days_from_monday := date_part('isodow', start_dt)::Integer - 1;

    IF num_days_from_monday = 5
    THEN
        num_days_from_monday = 4;
        start_dt := start_dt - '1 day'::Interval;
    ELSIF num_days_from_monday = 6
    THEN
        num_days_from_monday = 4;
        start_dt := start_dt - '2 days'::Interval;
    END IF;

    new_date := start_dt + '1 day'::Interval * (((num_days_from_monday + days) / 5) * 2 + days);

    RETURN  date_trunc('day', new_date) + '18:30:00';
END;
$$;

alter function add_working_days(timestamp with time zone, integer) owner to romain;

