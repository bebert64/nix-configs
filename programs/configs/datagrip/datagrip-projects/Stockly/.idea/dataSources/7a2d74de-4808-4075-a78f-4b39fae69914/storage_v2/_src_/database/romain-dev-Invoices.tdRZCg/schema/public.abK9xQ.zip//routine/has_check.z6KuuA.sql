create function has_check(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _hasc( $1, $2, 'c' ), $3 );
$$;

alter function has_check(name, name, text) owner to romain;

