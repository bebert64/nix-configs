create function problem_tags__check_problem_already_has_tag() returns trigger
    language plpgsql
as
$$
BEGIN
	IF problem_already_has_tag (NEW.problem_id, NEW.value) THEN
		RAISE 'Problem id (%) already has active value (%)', NEW.problem_id, NEW.value
		USING ERRCODE = 'unique_violation', CONSTRAINT = 'problem_tags__check_problem_already_has_tag', TABLE = 'problem_tags';
	END IF;
		RETURN NULL;
END
$$;

alter function problem_tags__check_problem_already_has_tag() owner to romain;

