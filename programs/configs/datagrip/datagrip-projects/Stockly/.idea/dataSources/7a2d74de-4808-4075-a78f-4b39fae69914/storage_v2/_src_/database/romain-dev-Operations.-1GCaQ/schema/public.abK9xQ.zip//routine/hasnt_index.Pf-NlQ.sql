create function hasnt_index(name, name, name) returns text
    language sql
as
$$
    SELECT ok(
        NOT _have_index( $1, $2, $3 ),
        'Index ' || quote_ident($3) || ' should not exist'
    );
$$;

alter function hasnt_index(name, name, name) owner to romain;

