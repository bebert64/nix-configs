create function hasnt_view(name) returns text
    language sql
as
$$
    SELECT hasnt_view( $1, 'View ' || quote_ident($1) || ' should not exist' );
$$;

alter function hasnt_view(name) owner to romain;

