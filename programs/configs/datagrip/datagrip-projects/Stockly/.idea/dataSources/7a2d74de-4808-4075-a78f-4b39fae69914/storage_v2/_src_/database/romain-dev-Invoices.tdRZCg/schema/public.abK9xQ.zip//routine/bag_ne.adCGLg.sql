create function bag_ne(text, text) returns text
    language sql
as
$$
    SELECT _relne( $1, $2, NULL::text, 'ALL ' );
$$;

alter function bag_ne(text, text) owner to romain;

