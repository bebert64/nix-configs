create function do_tap(name) returns SETOF text
    language sql
as
$$
    SELECT * FROM _runem( findfuncs($1, '^test'), _is_verbose() );
$$;

alter function do_tap(name) owner to romain;

