create function order_shippings__check_integration_refunds_not_exceed_total() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (order_shipping_refunds__integration_refunds_exceed_total(NEW.id)) THEN
		RAISE 'The new total price (%) for order shipping (%) is lower that the sum of existing integration refunds', NEW.client_price_et, NEW.id
			USING ERRCODE = 'invalid_parameter_value', CONSTRAINT =
					'order_shippings__check_integration_refunds_not_exceed_total', TABLE = 'order_shippings';
	END IF;
	RETURN NULL;
END
$$;

alter function order_shippings__check_integration_refunds_not_exceed_total() owner to romain;

