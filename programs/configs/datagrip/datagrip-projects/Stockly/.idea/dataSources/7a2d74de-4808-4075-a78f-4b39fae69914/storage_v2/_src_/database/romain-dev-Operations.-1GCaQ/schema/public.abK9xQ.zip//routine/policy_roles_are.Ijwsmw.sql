create function policy_roles_are(name, name, name, name[]) returns text
    language sql
as
$$
    SELECT policy_roles_are( $1, $2, $3, $4, 'Policy ' || quote_ident($3) || ' for table ' || quote_ident($1) || '.' || quote_ident($2) || ' should have the correct roles' );
$$;

alter function policy_roles_are(name, name, name, name[]) owner to romain;

