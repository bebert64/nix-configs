create function order_lines__acceptable_loss_is_coherent() returns trigger
    language plpgsql
as
$$
BEGIN
	IF incoherent_acceptable_loss (NULL, NEW.id, NULL, NULL) THEN
		RAISE 'Problem with acceptable loss linked to order_line id (%): either no purchase shipping, no order_line cancellation, or order_line cancellation was refused', NEW.id
		USING ERRCODE = 'integrity_constraint_violation', CONSTRAINT = 'acceptable_loss_is_coherent', TABLE = 'order_lines';
	END IF;
	RETURN NULL;
END
$$;

alter function order_lines__acceptable_loss_is_coherent() owner to romain;

