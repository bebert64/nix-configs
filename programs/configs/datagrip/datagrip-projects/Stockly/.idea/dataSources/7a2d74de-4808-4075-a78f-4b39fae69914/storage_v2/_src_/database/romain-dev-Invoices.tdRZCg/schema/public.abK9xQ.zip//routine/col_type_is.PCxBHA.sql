create function col_type_is(name, name, text) returns text
    language sql
as
$$
    SELECT col_type_is( $1, $2, $3, 'Column ' || quote_ident($1) || '.' || quote_ident($2) || ' should be type ' || $3 );
$$;

alter function col_type_is(name, name, text) owner to romain;

