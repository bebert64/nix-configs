create function has_rule(name, name) returns text
    language sql
as
$$
    SELECT ok( _is_instead($1, $2) IS NOT NULL, 'Relation ' || quote_ident($1) || ' should have rule ' || quote_ident($2) );
$$;

alter function has_rule(name, name) owner to romain;

