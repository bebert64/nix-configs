create function hasnt_rule(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _is_instead($1, $2) IS NULL, $3 );
$$;

alter function hasnt_rule(name, name, text) owner to romain;

