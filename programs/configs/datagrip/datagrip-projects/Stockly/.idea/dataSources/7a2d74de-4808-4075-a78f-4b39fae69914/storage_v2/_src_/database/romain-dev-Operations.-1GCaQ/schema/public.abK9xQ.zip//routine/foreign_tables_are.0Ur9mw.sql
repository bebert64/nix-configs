create function foreign_tables_are(name[]) returns text
    language sql
as
$$
    SELECT _are(
        'foreign tables', _extras('f', $1), _missing('f', $1),
        'Search path ' || pg_catalog.current_setting('search_path') || ' should have the correct foreign tables'
    );
$$;

alter function foreign_tables_are(name[]) owner to romain;

