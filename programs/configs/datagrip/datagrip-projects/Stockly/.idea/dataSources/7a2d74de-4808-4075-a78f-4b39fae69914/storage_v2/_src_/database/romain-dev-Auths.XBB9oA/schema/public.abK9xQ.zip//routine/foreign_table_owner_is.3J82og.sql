create function foreign_table_owner_is(name, name, name) returns text
    language sql
as
$$
    SELECT foreign_table_owner_is(
        $1, $2, $3,
        'Foreign table ' || quote_ident($1) || '.' || quote_ident($2) || ' should be owned by ' || quote_ident($3)
    );
$$;

alter function foreign_table_owner_is(name, name, name) owner to romain;

