create function invoices__check_invoice_document_direct_can_not_generate() returns trigger
    language plpgsql
as
$$
BEGIN
	IF NOT invoice_documents__direct_to_invoice_can_not_generate(NEW.id, NULL) THEN
		RAISE EXCEPTION 'invoices__check_invoice_document_direct_can_not_generate';
	END IF;
	RETURN NULL;
END
$$;

alter function invoices__check_invoice_document_direct_can_not_generate() owner to romain;

