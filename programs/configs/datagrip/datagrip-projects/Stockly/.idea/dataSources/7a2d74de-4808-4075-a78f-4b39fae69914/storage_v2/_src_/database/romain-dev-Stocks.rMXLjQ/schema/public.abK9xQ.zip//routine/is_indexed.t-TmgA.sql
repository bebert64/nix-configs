create function is_indexed(name, name) returns text
    language sql
as
$$
   SELECT ok ( _is_indexed( NULL, $1, ARRAY[$2]::NAME[]) );
$$;

alter function is_indexed(name, name) owner to romain;

