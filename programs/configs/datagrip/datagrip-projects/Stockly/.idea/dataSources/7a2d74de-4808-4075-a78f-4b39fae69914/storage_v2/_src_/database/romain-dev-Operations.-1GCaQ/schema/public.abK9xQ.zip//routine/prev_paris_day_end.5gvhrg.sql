create function prev_paris_day_end(start_dt timestamp with time zone) returns timestamp with time zone
    language plpgsql
as
$$
BEGIN RETURN prev_time_occurrence(start_dt, 'Europe/Paris', 18, 30, '{}'); END;
$$;

alter function prev_paris_day_end(timestamp with time zone) owner to romain;

