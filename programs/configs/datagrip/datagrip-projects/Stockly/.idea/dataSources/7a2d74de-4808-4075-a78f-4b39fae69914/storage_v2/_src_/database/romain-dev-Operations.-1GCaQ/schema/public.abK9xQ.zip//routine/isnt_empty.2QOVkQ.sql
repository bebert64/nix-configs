create function isnt_empty(text, text) returns text
    language plpgsql
as
$$
DECLARE
    res  BOOLEAN := FALSE;
    rec  RECORD;
BEGIN
    -- Find extra records.
    FOR rec in EXECUTE _query($1) LOOP
        res := TRUE;
        EXIT;
    END LOOP;

    RETURN ok(res, $2);
END;
$$;

alter function isnt_empty(text, text) owner to romain;

