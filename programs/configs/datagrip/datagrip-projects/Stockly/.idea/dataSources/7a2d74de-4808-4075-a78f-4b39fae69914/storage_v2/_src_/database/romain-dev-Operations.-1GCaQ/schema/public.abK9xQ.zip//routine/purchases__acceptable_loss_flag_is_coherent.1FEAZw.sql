create function purchases__acceptable_loss_flag_is_coherent() returns trigger
    language plpgsql
as
$$
BEGIN
	IF incoherent_acceptable_loss (NEW.id, NULL, NULL, NULL) THEN
		RAISE 'Problem with acceptable loss flag id (%): either no purchase shipping, no order_line cancellation, or order_line cancellation was refused', NEW.acceptable_loss_flag_id
		USING ERRCODE = 'integrity_constraint_violation', CONSTRAINT = 'acceptable_loss_flag_is_coherent', TABLE = 'purchases';
	END IF;
	RETURN NULL;
END
$$;

alter function purchases__acceptable_loss_flag_is_coherent() owner to romain;

