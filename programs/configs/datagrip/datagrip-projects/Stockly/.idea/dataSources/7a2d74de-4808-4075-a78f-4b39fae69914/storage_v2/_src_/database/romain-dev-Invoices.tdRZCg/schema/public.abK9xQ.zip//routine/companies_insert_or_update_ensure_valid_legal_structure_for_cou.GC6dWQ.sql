create function companies_insert_or_update_ensure_valid_legal_structure_for_cou() returns trigger
    language plpgsql
as
$$
DECLARE
    company_country VARCHAR(3);
BEGIN
    SELECT country_alpha3 INTO company_country
    FROM legal_entities
    WHERE id = NEW.legal_entity_id;

    IF NOT EXISTS (
        SELECT 1
        FROM country_legal_structures
        WHERE country = company_country
        AND legal_structure = NEW.legal_structure
    ) THEN
        RAISE EXCEPTION 'Invalid legal structure "%" for country "%"',
            NEW.legal_structure,
            company_country;
    END IF;

    RETURN NEW;
END;
$$;

alter function companies_insert_or_update_ensure_valid_legal_structure_for_cou() owner to romain;

