create function companies_insert_or_update_ensure_valid_legal_structure_for_cou() returns trigger
    language plpgsql
as
$$
DECLARE
    company_country Varchar(3);
BEGIN
    SELECT country_alpha3 INTO company_country
    FROM legal_entities
    WHERE id = NEW.legal_entity_id;

    IF NEW.active_in_stockly_network THEN
        IF NOT EXISTS (
            SELECT 1
            FROM country_legal_structures cls
            WHERE cls.country = company_country
            AND cls.legal_structure = NEW.legal_structure
            AND cls.invalidated_at IS NULL
        ) THEN
            RAISE EXCEPTION 'Legal structure "%" is either invalid or non-existant for country "%"',
                NEW.legal_structure,
                company_country;
        END IF;
    ELSE
        IF NOT EXISTS (
            SELECT 1
            FROM country_legal_structures cls
            WHERE cls.country = company_country
            AND cls.legal_structure = NEW.legal_structure
        ) THEN
            RAISE EXCEPTION 'Legal structure "%" does not exist for country "%"',
                NEW.legal_structure,
                company_country;
        END IF;
    END IF;

    RETURN NEW;
END;
$$;

alter function companies_insert_or_update_ensure_valid_legal_structure_for_cou() owner to romain;

