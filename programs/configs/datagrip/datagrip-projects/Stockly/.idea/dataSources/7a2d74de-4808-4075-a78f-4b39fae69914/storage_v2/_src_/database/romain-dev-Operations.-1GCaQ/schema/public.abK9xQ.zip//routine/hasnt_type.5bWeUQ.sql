create function hasnt_type(name, name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _has_type( $1, $2, NULL ), $3 );
$$;

alter function hasnt_type(name, name, text) owner to romain;

