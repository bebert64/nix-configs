create function hasnt_opclass(name, name) returns text
    language sql
as
$$
    SELECT ok( NOT _opc_exists( $1, $2 ), 'Operator class ' || quote_ident($1) || '.' || quote_ident($2) || ' should not exist' );
$$;

alter function hasnt_opclass(name, name) owner to romain;

