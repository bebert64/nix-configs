create function purchases__supplier_inconsistent_with_pcs_submission(arg_purchase_id integer, arg_purchases_shipping_id integer, arg_purchases_submission_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
	RETURN (SELECT
		EXISTS (
			SELECT 1
			FROM
				purchases p
				INNER JOIN purchases_shippings pship ON p.purchases_shipping_id = pship.id
				INNER JOIN purchases_submissions psub ON pship.submission_id = psub.id
			WHERE
				psub.supplier_id != p.supplier_id
				AND (p.id = arg_purchase_id
					OR arg_purchase_id IS NULL)
				AND (pship.id = arg_purchases_shipping_id
					OR arg_purchases_shipping_id IS NULL)
				AND (psub.id = arg_purchases_submission_id
					OR arg_purchases_submission_id IS NULL)));
END
$$;

alter function purchases__supplier_inconsistent_with_pcs_submission(integer, integer, integer) owner to romain;

