create function isnt_normal_function(name) returns text
    language sql
as
$$
    SELECT _func_compare(
        NULL, $1, NOT _type_func('f', $1),
        'Function ' || quote_ident($1) || '() should not be a normal function'
    );
$$;

alter function isnt_normal_function(name) owner to romain;

