create function hasnt_inherited_tables(name, name, text) returns text
    language sql
as
$$
       SELECT ok( NOT _inherited( $1, $2 ), $3 );
$$;

alter function hasnt_inherited_tables(name, name, text) owner to romain;

