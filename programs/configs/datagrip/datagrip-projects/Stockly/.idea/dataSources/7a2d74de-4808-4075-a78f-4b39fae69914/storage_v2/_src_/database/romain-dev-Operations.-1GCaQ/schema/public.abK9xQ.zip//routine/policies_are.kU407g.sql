create function policies_are(name, name, name[]) returns text
    language sql
as
$$
    SELECT policies_are( $1, $2, $3, 'Table ' || quote_ident($1) || '.' || quote_ident($2) || ' should have the correct policies' );
$$;

alter function policies_are(name, name, name[]) owner to romain;

