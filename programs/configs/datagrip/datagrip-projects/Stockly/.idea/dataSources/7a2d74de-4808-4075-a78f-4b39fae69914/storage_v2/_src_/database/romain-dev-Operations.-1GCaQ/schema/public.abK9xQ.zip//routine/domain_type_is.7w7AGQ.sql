create function domain_type_is(text, text) returns text
    language sql
as
$$
    SELECT domain_type_is(
        $1, $2,
        'Domain ' || $1 || ' should extend type ' || $2
    );
$$;

alter function domain_type_is(text, text) owner to romain;

