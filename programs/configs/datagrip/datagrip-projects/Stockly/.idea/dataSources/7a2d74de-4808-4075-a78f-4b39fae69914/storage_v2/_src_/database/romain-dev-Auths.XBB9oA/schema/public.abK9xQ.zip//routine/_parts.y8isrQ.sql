create function _parts(name) returns SETOF name
    language sql
as
$$
    SELECT i.inhrelid::regclass::name
      FROM pg_catalog.pg_class c
      JOIN pg_catalog.pg_inherits i ON c.oid = i.inhparent
     WHERE c.relname = $1
       AND c.relkind = 'p'
       AND pg_catalog.pg_table_is_visible(c.oid)
$$;

alter function _parts(name) owner to romain;

