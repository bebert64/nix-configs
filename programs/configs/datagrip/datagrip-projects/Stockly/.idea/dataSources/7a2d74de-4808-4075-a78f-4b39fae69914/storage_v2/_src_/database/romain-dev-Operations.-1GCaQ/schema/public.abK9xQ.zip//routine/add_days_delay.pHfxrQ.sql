create function add_days_delay(start_dt timestamp with time zone, days integer, is_working_days boolean, raw_tz text) returns timestamp with time zone
    language plpgsql
as
$$
BEGIN
	IF is_working_days
	THEN
		RETURN add_working_days_delay(start_dt, days, raw_tz);
	ELSE
		RETURN start_dt + '1 days'::Interval * days;
	END IF;
END;
$$;

alter function add_days_delay(timestamp with time zone, integer, boolean, text) owner to romain;

