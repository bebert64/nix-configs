create function _get_opclass_owner(name) returns name
    language sql
as
$$
    SELECT pg_catalog.pg_get_userbyid(opcowner)
      FROM pg_catalog.pg_opclass
     WHERE opcname = $1
       AND pg_catalog.pg_opclass_is_visible(oid);
$$;

alter function _get_opclass_owner(name) owner to romain;

