create function stockly_programmatic_entities__domain_conflicts_with_pol_dsgntn(arg_stockly_programmatic_entity_id integer) returns boolean
    language sql
as
$$
	SELECT
		EXISTS(
			SELECT 1
			FROM "stockly_programmatic_entities" spe
			INNER JOIN "policies" p ON p.designation LIKE format('%s.%%', spe.domain) OR p.designation = spe.domain
			LEFT JOIN "programmatic_entities" pe ON pe.entity_id = p.created_by
			WHERE
			(spe.entity_id = arg_stockly_programmatic_entity_id OR arg_stockly_programmatic_entity_id IS NULL)
			AND pe.entity_id IS NULL -- otherwise this is checked by the unique index on policies("designation", "created_by")
		);
$$;

alter function stockly_programmatic_entities__domain_conflicts_with_pol_dsgntn(integer) owner to romain;

