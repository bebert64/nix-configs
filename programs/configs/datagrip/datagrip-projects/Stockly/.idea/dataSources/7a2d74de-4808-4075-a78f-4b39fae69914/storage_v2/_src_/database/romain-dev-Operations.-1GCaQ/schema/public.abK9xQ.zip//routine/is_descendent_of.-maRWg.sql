create function is_descendent_of(name, name, name, name, integer, text) returns text
    language sql
as
$$
    SELECT ok( _ancestor_of( $3, $4, $1, $2, $5 ), $6 );
$$;

alter function is_descendent_of(name, name, name, name, integer, text) owner to romain;

