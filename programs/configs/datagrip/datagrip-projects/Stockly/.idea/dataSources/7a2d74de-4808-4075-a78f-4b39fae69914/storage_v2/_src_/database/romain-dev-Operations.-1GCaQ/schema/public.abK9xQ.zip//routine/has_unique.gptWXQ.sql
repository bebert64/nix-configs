create function has_unique(text, text, text) returns text
    language sql
as
$$
    SELECT ok( _hasc( $1, $2, 'u' ), $3 );
$$;

alter function has_unique(text, text, text) owner to romain;

