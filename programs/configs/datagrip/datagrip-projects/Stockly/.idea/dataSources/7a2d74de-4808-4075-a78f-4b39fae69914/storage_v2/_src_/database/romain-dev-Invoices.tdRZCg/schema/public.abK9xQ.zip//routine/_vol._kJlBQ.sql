create function _vol(name) returns text
    language sql
as
$$
    SELECT _expand_vol(volatility) FROM tap_funky f
     WHERE f.name = $1 AND f.is_visible;
$$;

alter function _vol(name) owner to romain;

