create function _cast_exists(name, name) returns boolean
    language sql
as
$$
    SELECT EXISTS (
       SELECT TRUE
         FROM pg_catalog.pg_cast c
        WHERE _cmp_types(castsource, $1)
          AND _cmp_types(casttarget, $2)
   );
$$;

alter function _cast_exists(name, name) owner to romain;

