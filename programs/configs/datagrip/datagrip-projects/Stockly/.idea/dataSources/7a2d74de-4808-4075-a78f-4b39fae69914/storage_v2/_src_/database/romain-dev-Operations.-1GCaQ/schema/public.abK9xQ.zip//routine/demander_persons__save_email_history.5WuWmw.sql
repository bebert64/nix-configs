create function demander_persons__save_email_history() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NEW.id != OLD.id) THEN
		RAISE EXCEPTION '% You can''t change a demander person ID', NEW.id;
	END IF;
	IF NEW.email IS DISTINCT FROM OLD.email THEN
		INSERT INTO demander_persons_email_history (demander_person_id, previous_email)
			VALUES (OLD.id, OLD.email);
	END IF;
	RETURN NULL;
END;
$$;

alter function demander_persons__save_email_history() owner to romain;

