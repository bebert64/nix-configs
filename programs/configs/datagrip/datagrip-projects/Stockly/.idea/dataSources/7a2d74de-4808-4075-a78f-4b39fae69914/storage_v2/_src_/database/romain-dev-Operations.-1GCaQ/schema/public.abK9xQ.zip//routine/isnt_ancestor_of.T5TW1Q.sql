create function isnt_ancestor_of(name, name) returns text
    language sql
as
$$
    SELECT ok(
        NOT  _ancestor_of( $1, $2, NULL ),
        'Table ' || quote_ident( $1 ) || ' should not be an ancestor of ' || quote_ident( $2)
    );
$$;

alter function isnt_ancestor_of(name, name) owner to romain;

