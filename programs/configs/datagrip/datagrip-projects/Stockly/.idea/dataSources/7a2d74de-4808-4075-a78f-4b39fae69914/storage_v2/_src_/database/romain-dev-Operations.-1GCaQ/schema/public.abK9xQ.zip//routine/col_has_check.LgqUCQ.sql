create function col_has_check(name, name[], text) returns text
    language sql
as
$$
    SELECT _constraint( $1, 'c', $2, $3, 'check' );
$$;

alter function col_has_check(name, name[], text) owner to romain;

