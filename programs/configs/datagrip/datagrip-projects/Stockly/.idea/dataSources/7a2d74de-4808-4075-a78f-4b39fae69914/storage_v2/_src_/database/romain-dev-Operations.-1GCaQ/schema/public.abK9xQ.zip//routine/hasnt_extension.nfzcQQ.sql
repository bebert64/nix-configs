create function hasnt_extension(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _ext_exists( $1 ), $2)
$$;

alter function hasnt_extension(name, text) owner to romain;

