create function _extras(character, name[]) returns name[]
    language sql
as
$$
SELECT _extras(ARRAY[$1], $2);
$$;

alter function _extras(char, name[]) owner to romain;

