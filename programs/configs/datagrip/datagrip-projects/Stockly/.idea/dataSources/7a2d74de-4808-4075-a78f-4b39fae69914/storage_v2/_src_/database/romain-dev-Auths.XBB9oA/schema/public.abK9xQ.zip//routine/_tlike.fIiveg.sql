create function _tlike(boolean, text, text, text) returns text
    language sql
as
$$
    SELECT ok( $1, $4 ) || CASE WHEN $1 THEN '' ELSE E'\n' || diag(
           '   error message: ' || COALESCE( quote_literal($2), 'NULL' ) ||
       E'\n   doesn''t match: ' || COALESCE( quote_literal($3), 'NULL' )
    ) END;
$$;

alter function _tlike(boolean, text, text, text) owner to romain;

