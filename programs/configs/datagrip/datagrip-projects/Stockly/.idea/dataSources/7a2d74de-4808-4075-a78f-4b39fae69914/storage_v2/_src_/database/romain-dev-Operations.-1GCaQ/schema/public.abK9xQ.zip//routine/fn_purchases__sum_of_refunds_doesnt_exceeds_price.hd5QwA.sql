create function fn_purchases__sum_of_refunds_doesnt_exceeds_price() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (sum_of_purchase_refunds_exceeds_purchase_price_et(NEW.id)) THEN
		RAISE EXCEPTION 'Sum of refunds exceed purchase % price' , NEW.id;
	END IF;
	RETURN NULL;
END
$$;

alter function fn_purchases__sum_of_refunds_doesnt_exceeds_price() owner to romain;

