create function problem_already_has_tag(arg_problem_id integer, arg_value character varying) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val boolean := FALSE;
BEGIN
	SELECT
		INTO ret_val EXISTS (
			SELECT
				COUNT(*) AS count
			FROM
				"problem_tags"
			WHERE ("problem_id" = arg_problem_id
				OR arg_problem_id IS NULL)
			AND ("value" = arg_value
				OR arg_value IS NULL)
			AND "removed_at" IS NULL
		GROUP BY
			problem_id,
			"value"
		HAVING
			COUNT(*) > 1);
	RETURN ret_val;
END
$$;

alter function problem_already_has_tag(integer, varchar) owner to romain;

