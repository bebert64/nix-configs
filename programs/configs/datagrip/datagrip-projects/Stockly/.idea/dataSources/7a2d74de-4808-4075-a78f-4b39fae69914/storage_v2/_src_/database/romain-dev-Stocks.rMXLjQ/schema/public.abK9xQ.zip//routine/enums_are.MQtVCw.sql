create function enums_are(name, name[], text) returns text
    language sql
as
$$
    SELECT _types_are( $1, $2, $3, ARRAY['e'] );
$$;

alter function enums_are(name, name[], text) owner to romain;

