create function is_descendent_of(name, name, integer) returns text
    language sql
as
$$
    SELECT ok(
        _ancestor_of( $2, $1, $3 ),
        'Table ' || quote_ident( $1 ) || ' should be descendent ' || $3 || ' from ' || quote_ident( $2)
    );
$$;

alter function is_descendent_of(name, name, integer) owner to romain;

