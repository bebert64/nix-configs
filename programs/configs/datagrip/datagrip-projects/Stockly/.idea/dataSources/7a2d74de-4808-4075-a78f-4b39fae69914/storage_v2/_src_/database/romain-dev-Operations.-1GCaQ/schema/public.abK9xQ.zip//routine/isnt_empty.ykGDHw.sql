create function isnt_empty(text) returns text
    language sql
as
$$
    SELECT isnt_empty( $1, NULL );
$$;

alter function isnt_empty(text) owner to romain;

