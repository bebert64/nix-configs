create function domain_type_is(name, text, text) returns text
    language sql
as
$$
    SELECT domain_type_is(
        $1, $2, $3,
        'Domain ' || quote_ident($1) || '.' || $2
        || ' should extend type ' || $3
    );
$$;

alter function domain_type_is(name, text, text) owner to romain;

