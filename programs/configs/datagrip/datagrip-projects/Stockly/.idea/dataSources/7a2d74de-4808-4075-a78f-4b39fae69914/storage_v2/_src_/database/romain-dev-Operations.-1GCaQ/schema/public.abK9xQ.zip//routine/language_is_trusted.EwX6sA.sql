create function language_is_trusted(name) returns text
    language sql
as
$$
    SELECT language_is_trusted($1, 'Procedural language ' || quote_ident($1) || ' should be trusted' );
$$;

alter function language_is_trusted(name) owner to romain;

