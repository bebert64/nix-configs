create function alpha3_array(arg_array text[]) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val NOT EXISTS (
		SELECT * FROM unnest(arg_array) AS elem
		WHERE
			elem !~ '^[A-Z]{3}$'
	);

	RETURN ret_val;
END
$$;

alter function alpha3_array(text[]) owner to romain;

