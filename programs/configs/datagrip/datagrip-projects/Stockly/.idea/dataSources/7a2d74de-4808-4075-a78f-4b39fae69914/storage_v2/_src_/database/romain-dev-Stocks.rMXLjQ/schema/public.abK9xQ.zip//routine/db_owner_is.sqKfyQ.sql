create function db_owner_is(name, name) returns text
    language sql
as
$$
    SELECT db_owner_is(
        $1, $2,
        'Database ' || quote_ident($1) || ' should be owned by ' || quote_ident($2)
    );
$$;

alter function db_owner_is(name, name) owner to romain;

