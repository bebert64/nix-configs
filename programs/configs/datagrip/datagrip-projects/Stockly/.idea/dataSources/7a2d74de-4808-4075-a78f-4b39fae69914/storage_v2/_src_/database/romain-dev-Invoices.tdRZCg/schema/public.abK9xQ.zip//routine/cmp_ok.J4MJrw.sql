create function cmp_ok(anyelement, text, anyelement) returns text
    language sql
as
$$
    SELECT cmp_ok( $1, $2, $3, NULL );
$$;

alter function cmp_ok(anyelement, text, anyelement) owner to romain;

