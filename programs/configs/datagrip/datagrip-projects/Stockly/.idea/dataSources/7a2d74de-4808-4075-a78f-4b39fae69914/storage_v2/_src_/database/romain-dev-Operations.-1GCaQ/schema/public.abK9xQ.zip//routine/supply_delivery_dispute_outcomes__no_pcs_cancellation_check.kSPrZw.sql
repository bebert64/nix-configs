create function supply_delivery_dispute_outcomes__no_pcs_cancellation_check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (exists_open_pcs_cancellation_and_delivery_dispute(NULL, NULL, NULL, NULL, NULL, NEW.id)) THEN
		RAISE EXCEPTION 'supply_delivery_dispute_outcomes__no_pcs_cancellation_check FAILED';
	END IF;
	RETURN NULL;
END
$$;

alter function supply_delivery_dispute_outcomes__no_pcs_cancellation_check() owner to romain;

