create function bag_ne(text, anyarray) returns text
    language sql
as
$$
    SELECT _relne( $1, $2, NULL::text, 'ALL ' );
$$;

alter function bag_ne(text, anyarray) owner to romain;

