create function function_returns(name, name[], text) returns text
    language sql
as
$$
    SELECT function_returns(
        $1, $2, $3,
        'Function ' || quote_ident($1) || '(' ||
        array_to_string($2, ', ') || ') should return ' || $3
    );
$$;

alter function function_returns(name, name[], text) owner to romain;

