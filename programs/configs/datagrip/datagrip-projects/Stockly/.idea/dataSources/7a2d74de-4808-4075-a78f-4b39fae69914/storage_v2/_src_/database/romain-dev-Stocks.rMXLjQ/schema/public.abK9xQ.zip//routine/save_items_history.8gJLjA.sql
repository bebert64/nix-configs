create function save_items_history() returns trigger
    language plpgsql
as
$$
BEGIN
	-- DROP TABLE IF EXISTS displays a NOTICE but we can't really do much about it
	DROP TABLE IF EXISTS __save_items_history_temp_retailers_table;
	CREATE TEMP TABLE __save_items_history_temp_retailers_table AS SELECT DISTINCT
		i.retailer_id
	FROM
		new_table i;
	DELETE FROM __save_items_history_temp_retailers_table t
	WHERE NOT EXISTS(
			SELECT
				*
			FROM
				retailers r
			WHERE
				r.id = t.retailer_id
				AND r.items_history_enabled_since IS NOT NULL);
	IF(EXISTS(
		SELECT
			*
		FROM
			__save_items_history_temp_retailers_table)) THEN
		IF(TG_OP = 'INSERT') THEN
			INSERT INTO items_history(item_id, retailer_id, quantity)
			SELECT
				i.id,
				i.retailer_id,
				i.quantity
			FROM
				new_table i
				INNER JOIN __save_items_history_temp_retailers_table t ON t.retailer_id = i.retailer_id;
		ELSE
			INSERT INTO items_history(item_id, retailer_id, quantity)
			SELECT
				i.id,
				i.retailer_id,
				i.quantity
			FROM
				new_table i
			LEFT JOIN old_table i_old ON i_old.id = i.id -- LEFT in case of id update
			INNER JOIN __save_items_history_temp_retailers_table t ON t.retailer_id = i.retailer_id
		WHERE
			i.quantity IS DISTINCT FROM i_old.quantity;
		END IF;
	END IF;
	DROP TABLE __save_items_history_temp_retailers_table;
	RETURN NULL;
	-- result is ignored since this is an AFTER trigger
END;
$$;

alter function save_items_history() owner to romain;

