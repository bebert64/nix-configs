create function isnt_strict(name) returns text
    language sql
as
$$
    SELECT ok( NOT _strict($1), 'Function ' || quote_ident($1) || '() should not be strict' );
$$;

alter function isnt_strict(name) owner to romain;

