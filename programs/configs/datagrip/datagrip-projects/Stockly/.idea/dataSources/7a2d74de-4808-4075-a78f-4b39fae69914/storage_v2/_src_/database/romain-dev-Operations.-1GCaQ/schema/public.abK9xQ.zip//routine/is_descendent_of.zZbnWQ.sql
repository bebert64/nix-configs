create function is_descendent_of(name, name, name, name, integer) returns text
    language sql
as
$$
    SELECT ok(
        _ancestor_of( $3, $4, $1, $2, $5 ),
        'Table ' || quote_ident( $1 ) || '.' || quote_ident( $2 )
        || ' should be descendent ' || $5 || ' from '
        || quote_ident( $3 ) || '.' || quote_ident( $4 )
    );
$$;

alter function is_descendent_of(name, name, name, name, integer) owner to romain;

