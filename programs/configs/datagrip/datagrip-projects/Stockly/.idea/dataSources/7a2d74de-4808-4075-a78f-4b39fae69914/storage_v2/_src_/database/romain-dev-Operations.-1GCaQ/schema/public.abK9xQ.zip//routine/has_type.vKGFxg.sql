create function has_type(name, text) returns text
    language sql
as
$$
    SELECT ok( _has_type( $1, NULL ), $2 );
$$;

alter function has_type(name, text) owner to romain;

