create function add_company_fields_to_history() returns trigger
    language plpgsql
as
$$
BEGIN
    IF OLD.vat_number IS DISTINCT FROM NEW.vat_number THEN
        INSERT INTO company_vat_number_history(company_id, previous_vat_number)
        VALUES (NEW.legal_entity_id, OLD.vat_number);
    END IF;

    IF OLD.national_identification_number IS DISTINCT FROM NEW.national_identification_number THEN
        INSERT INTO company_national_id_history(company_id, previous_national_identification_number)
        VALUES (NEW.legal_entity_id, OLD.national_identification_number);
    END IF;

    IF OLD.share_capital IS DISTINCT FROM NEW.share_capital THEN
        INSERT INTO company_share_capital_history(company_id, previous_share_capital)
        VALUES (NEW.legal_entity_id, OLD.share_capital);
    END IF;

    IF OLD.legal_structure IS DISTINCT FROM NEW.legal_structure THEN
        INSERT INTO company_legal_structure_history(company_id, previous_legal_structure)
        VALUES (NEW.legal_entity_id, OLD.legal_structure);
    END IF;

    IF OLD.registration_city IS DISTINCT FROM NEW.registration_city THEN
        INSERT INTO company_registration_city_history(company_id, previous_registration_city)
        VALUES (NEW.legal_entity_id, OLD.registration_city);
    END IF;


    IF OLD.shipments_head_office_address_id IS DISTINCT FROM NEW.shipments_head_office_address_id THEN
        INSERT INTO company_head_office_address_history(company_id, previous_shipments_head_office_address_id)
        VALUES (NEW.legal_entity_id, OLD.shipments_head_office_address_id);
    END IF;

    IF OLD.active_in_stockly_network IS DISTINCT FROM NEW.active_in_stockly_network THEN
        INSERT INTO company_active_in_stockly_network_history(company_id, previous_active_in_stockly_network)
        VALUES (NEW.legal_entity_id, OLD.previous_active_in_stockly_network);
    END IF;

    RETURN NEW;
END;
$$;

alter function add_company_fields_to_history() owner to romain;

