create function is_indexed(name, name, name[]) returns text
    language sql
as
$$
   SELECT ok(
       _is_indexed($1, $2, $3),
       'Should have an index on ' ||  quote_ident($1) || '.' || quote_ident($2) || '(' || array_to_string( $3, ', ' ) || ')'
    );
$$;

alter function is_indexed(name, name, name[]) owner to romain;

