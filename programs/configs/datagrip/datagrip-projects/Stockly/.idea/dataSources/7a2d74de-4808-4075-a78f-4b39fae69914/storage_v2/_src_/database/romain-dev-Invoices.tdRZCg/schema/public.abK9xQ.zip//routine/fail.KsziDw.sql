create function fail(text) returns text
    language sql
as
$$
    SELECT ok( FALSE, $1 );
$$;

alter function fail(text) owner to romain;

