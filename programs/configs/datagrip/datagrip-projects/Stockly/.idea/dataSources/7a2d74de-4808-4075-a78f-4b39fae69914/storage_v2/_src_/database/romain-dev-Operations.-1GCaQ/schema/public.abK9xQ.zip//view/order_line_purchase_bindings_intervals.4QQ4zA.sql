create view order_line_purchase_bindings_intervals(order_line_id, purchase_id, bound_at, unbound_at) as
SELECT olpih.order_line_id,
       olpih.previous_purchase_id                                                                           AS purchase_id,
       lag(olpih.created_at, 1) OVER (PARTITION BY olpih.order_line_id ORDER BY olpih.created_at, olpih.id) AS bound_at,
       olpih.created_at                                                                                     AS unbound_at
FROM order_lines_purchase_id_history olpih
UNION ALL
(SELECT DISTINCT ON (ol.id) ol.id                          AS order_line_id,
                            ol.purchase_id,
                            olpih_latest.created_at        AS bound_at,
                            NULL::timestamp with time zone AS unbound_at
 FROM order_lines ol
          LEFT JOIN order_lines_purchase_id_history olpih_latest ON olpih_latest.order_line_id = ol.id
 ORDER BY ol.id, olpih_latest.created_at DESC, olpih_latest.id DESC);

alter table order_line_purchase_bindings_intervals
    owner to romain;

