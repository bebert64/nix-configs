create function exists_open_pcs_cancellation_and_delivery_dispute(arg_pcs_cancellation_decision_id integer, arg_pcs_cancellation_id integer, arg_pcs_id integer, arg_parcel_item_id integer, arg_supply_delivery_dispute_id integer, arg_supply_delivery_dispute_decision_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT
			*
		FROM
			"supply_delivery_disputes"
			LEFT JOIN "supply_delivery_dispute_outcomes"
				ON supply_delivery_disputes.outcome_id = supply_delivery_dispute_outcomes.id
			INNER JOIN "parcel_items"
				ON parcel_items.parcel_id = supply_delivery_disputes.parcel_id
			INNER JOIN "purchases"
				ON parcel_items.purchase_id = purchases.id
			INNER JOIN "purchase_cancellations"
				ON purchases.cancellation_id = purchase_cancellations.id
			LEFT JOIN "purchase_cancellation_decisions"
				ON purchase_cancellations.decision_id = purchase_cancellation_decisions.id
		WHERE
			supply_delivery_disputes.supplier_id = purchases.supplier_id
			AND parcel_items.flagged_as_erroneous_at IS NULL
			AND (supply_delivery_dispute_outcomes.id IS NULL OR supply_delivery_dispute_outcomes.outcome = 'accepted')
			AND purchase_cancellation_decisions.refused_reason IS NULL
			AND NOT (supply_delivery_dispute_outcomes.id IS NOT NULL AND purchase_cancellations.supplier_reason = 'lost')
			AND ("arg_pcs_cancellation_decision_id" IS NULL OR "arg_pcs_cancellation_decision_id" = purchase_cancellation_decisions.id)
			AND ("arg_pcs_cancellation_id" IS NULL OR "arg_pcs_cancellation_id" = purchase_cancellations.id)
			AND ("arg_pcs_id" IS NULL OR "arg_pcs_id" = purchases.id)
			AND ("arg_parcel_item_id" IS NULL OR "arg_parcel_item_id" = parcel_items.id)
			AND ("arg_supply_delivery_dispute_id" IS NULL OR "arg_supply_delivery_dispute_id" = supply_delivery_disputes.id)
			AND ("arg_supply_delivery_dispute_decision_id" IS NULL OR "arg_supply_delivery_dispute_decision_id" = supply_delivery_dispute_outcomes.id)
	);

	RETURN ret_val;
END
$$;

alter function exists_open_pcs_cancellation_and_delivery_dispute(integer, integer, integer, integer, integer, integer) owner to romain;

