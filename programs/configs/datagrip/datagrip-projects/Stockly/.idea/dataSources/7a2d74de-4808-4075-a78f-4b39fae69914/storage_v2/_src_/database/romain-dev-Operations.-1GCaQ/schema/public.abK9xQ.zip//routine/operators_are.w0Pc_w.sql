create function operators_are(name, text[]) returns text
    language sql
as
$$
    SELECT operators_are($1, $2, 'Schema ' || quote_ident($1) || ' should have the correct operators' );
$$;

alter function operators_are(name, text[]) owner to romain;

