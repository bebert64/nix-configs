create function hasnt_opclass(name) returns text
    language sql
as
$$
    SELECT ok( NOT _opc_exists( $1 ), 'Operator class ' || quote_ident($1) || ' should not exist' );
$$;

alter function hasnt_opclass(name) owner to romain;

