create function demand__order_owner_represents_demander__check(arg_order_owner_id integer, arg_order_id integer, arg_order_shipping_id integer, arg_order_line_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
SELECT INTO ret_val NOT EXISTS (
		SELECT *
		FROM "order_owners" oo
		INNER JOIN orders o on oo.demander_person_id = o.owner_id
		INNER JOIN order_shippings os on o.id = os.order_id
		INNER JOIN order_lines ol on os.id = ol.order_shipping_id
		WHERE ((
			oo.represents_demander
			AND (
				os.commission_et_override IS NOT NULL OR os.expected_commission__flat_amount_et != 0 OR os.expected_commission__rate_value != 0
				OR ol.commission_et_override IS NOT NULL OR ol.expected_commission__flat_amount_et != 0 OR ol.expected_commission__rate_value != 0
			)
		) OR (
			NOT oo.represents_demander
			AND (
				os.consumer_price_et IS NULL OR os.consumer_price_et != os.client_price_et
				OR os.consumer_vat_rate IS NULL OR os.consumer_vat_rate != os.client_vat_rate
				OR ol.consumer_price_et IS NULL OR ol.consumer_price_et != ol.client_price_et
				OR ol.consumer_vat_rate IS NULL OR ol.consumer_vat_rate != ol.client_vat_rate
				OR ol.consumer_extra_shipping_price_et IS NULL OR ol.consumer_extra_shipping_price_et != ol.client_extra_shipping_price_et
			)
		))
		AND ("arg_order_owner_id" IS NULL OR "arg_order_owner_id" = oo.demander_person_id)
		AND ("arg_order_id" IS NULL OR "arg_order_id" = o.id)
		AND ("arg_order_shipping_id" IS NULL OR "arg_order_shipping_id" = os.id)
		AND ("arg_order_line_id" IS NULL OR "arg_order_line_id" = ol.id)
	);
RETURN ret_val;
END
$$;

alter function demand__order_owner_represents_demander__check(integer, integer, integer, integer) owner to romain;

