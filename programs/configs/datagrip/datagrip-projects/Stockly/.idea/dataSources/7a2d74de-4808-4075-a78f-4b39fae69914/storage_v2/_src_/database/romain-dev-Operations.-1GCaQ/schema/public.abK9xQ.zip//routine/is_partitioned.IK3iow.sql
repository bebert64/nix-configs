create function is_partitioned(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _rexists('p', $1, $2), $3);
$$;

alter function is_partitioned(name, name, text) owner to romain;

