create function _get_func_owner(name, name, name[]) returns name
    language sql
as
$$
    SELECT owner
      FROM tap_funky
     WHERE schema = $1
       AND name   = $2
       AND args   = _funkargs($3)
$$;

alter function _get_func_owner(name, name, name[]) owner to romain;

