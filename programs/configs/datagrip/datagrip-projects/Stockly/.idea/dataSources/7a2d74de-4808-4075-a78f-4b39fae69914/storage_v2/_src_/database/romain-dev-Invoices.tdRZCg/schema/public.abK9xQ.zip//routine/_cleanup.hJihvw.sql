create function _cleanup() returns boolean
    language sql
as
$$
    DROP SEQUENCE __tresults___numb_seq;
    DROP TABLE __tcache__;
    DROP SEQUENCE __tcache___id_seq;
    SELECT TRUE;
$$;

alter function _cleanup() owner to romain;

