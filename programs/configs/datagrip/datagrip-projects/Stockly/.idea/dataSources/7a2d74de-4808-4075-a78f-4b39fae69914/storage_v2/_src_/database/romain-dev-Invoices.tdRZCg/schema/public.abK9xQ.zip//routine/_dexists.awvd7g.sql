create function _dexists(name) returns boolean
    language sql
as
$$
   SELECT EXISTS(
       SELECT true
         FROM pg_catalog.pg_type t
        WHERE t.typname = $1
          AND pg_catalog.pg_type_is_visible(t.oid)
   );
$$;

alter function _dexists(name) owner to romain;

