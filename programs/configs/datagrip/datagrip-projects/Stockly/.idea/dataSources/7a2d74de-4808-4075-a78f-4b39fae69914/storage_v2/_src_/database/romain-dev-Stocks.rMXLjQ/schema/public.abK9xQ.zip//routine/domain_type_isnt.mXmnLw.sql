create function domain_type_isnt(name, text, name, text) returns text
    language sql
as
$$
    SELECT domain_type_isnt(
        $1, $2, $3, $4,
        'Domain ' || quote_ident($1) || '.' || $2
        || ' should not extend type ' || quote_ident($3) || '.' || $4
    );
$$;

alter function domain_type_isnt(name, text, name, text) owner to romain;

