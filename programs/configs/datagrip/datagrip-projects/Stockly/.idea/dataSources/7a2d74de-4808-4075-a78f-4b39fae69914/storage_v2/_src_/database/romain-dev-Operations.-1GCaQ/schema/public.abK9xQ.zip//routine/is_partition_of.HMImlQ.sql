create function is_partition_of(name, name) returns text
    language sql
as
$$
    SELECT ok(
        _partof($1, $2),
        'Table ' || quote_ident($1) || ' should be a partition of ' || quote_ident($2)
    );
$$;

alter function is_partition_of(name, name) owner to romain;

