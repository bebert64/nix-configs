create function is_ancestor_of(name, name) returns text
    language sql
as
$$
    SELECT ok(
        _ancestor_of( $1, $2, NULL ),
        'Table ' || quote_ident( $1 ) || ' should be an ancestor of ' || quote_ident( $2)
    );
$$;

alter function is_ancestor_of(name, name) owner to romain;

