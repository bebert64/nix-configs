create function _is_trusted(name) returns boolean
    language sql
as
$$
    SELECT lanpltrusted FROM pg_catalog.pg_language WHERE lanname = $1;
$$;

alter function _is_trusted(name) owner to romain;

