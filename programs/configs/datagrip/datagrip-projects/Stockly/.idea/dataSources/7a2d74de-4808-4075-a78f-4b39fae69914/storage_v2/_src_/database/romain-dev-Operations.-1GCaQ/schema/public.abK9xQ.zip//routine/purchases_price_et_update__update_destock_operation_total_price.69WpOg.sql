create function purchases_price_et_update__update_destock_operation_total_price() returns trigger
    language plpgsql
as
$$
BEGIN
	UPDATE destock_operations
	SET total_purchases_price_et = destock_operations.total_purchases_price_et - OLD.price_et + NEW.price_et
	FROM destock_operation_lines dol
	WHERE dol.purchase_id = NEW.id
	AND destock_operations.id = dol.destock_operation_id;

	RETURN NEW;
END;
$$;

alter function purchases_price_et_update__update_destock_operation_total_price() owner to romain;

