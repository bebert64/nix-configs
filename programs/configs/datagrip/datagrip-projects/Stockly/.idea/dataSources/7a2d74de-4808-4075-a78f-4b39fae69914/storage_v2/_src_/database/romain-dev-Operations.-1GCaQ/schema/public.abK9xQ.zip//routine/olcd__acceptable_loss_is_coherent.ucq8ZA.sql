create function olcd__acceptable_loss_is_coherent() returns trigger
    language plpgsql
as
$$
BEGIN
	IF incoherent_acceptable_loss (NULL, NULL, NEW.id, NULL) THEN
		RAISE 'Problem with acceptable loss linked to order_line_cancellation_decision id (%): either no purchase shipping, no order_line cancellation, or order_line cancellation was refused', NEW.id
		USING ERRCODE = 'integrity_constraint_violation', CONSTRAINT = 'acceptable_loss_is_coherent', TABLE = 'order_line_cancellation_decisions';
	END IF;
	RETURN NULL;
END
$$;

alter function olcd__acceptable_loss_is_coherent() owner to romain;

