create function automated_order_messages_configs__ensure_precedence__trig() returns trigger
    language plpgsql
as
$$
BEGIN
	RAISE EXCEPTION 'automated_order_messages_configs__ensure_precedence__trig';
	RETURN NULL;
END
$$;

alter function automated_order_messages_configs__ensure_precedence__trig() owner to romain;

