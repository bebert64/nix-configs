create function _expand_vol(character) returns text
    immutable
    language sql
as
$$
   SELECT CASE $1
          WHEN 'i' THEN 'IMMUTABLE'
          WHEN 's' THEN 'STABLE'
          WHEN 'v' THEN 'VOLATILE'
          ELSE          'UNKNOWN' END
$$;

alter function _expand_vol(char) owner to romain;

