create function is_ancestor_of(name, name, integer) returns text
    language sql
as
$$
    SELECT ok(
        _ancestor_of( $1, $2, $3 ),
        'Table ' || quote_ident( $1 ) || ' should be ancestor ' || $3 || ' of ' || quote_ident( $2)
    );
$$;

alter function is_ancestor_of(name, name, integer) owner to romain;

