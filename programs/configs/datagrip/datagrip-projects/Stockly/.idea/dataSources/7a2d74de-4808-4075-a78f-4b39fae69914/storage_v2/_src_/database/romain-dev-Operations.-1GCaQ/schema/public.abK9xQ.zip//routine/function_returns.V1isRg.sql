create function function_returns(name, name, text, text) returns text
    language sql
as
$$
    SELECT _func_compare($1, $2, _returns($1, $2), _retval($3), $4 );
$$;

alter function function_returns(name, name, text, text) owner to romain;

