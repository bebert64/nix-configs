create function _get_type_owner(name, name) returns name
    language sql
as
$$
    SELECT pg_catalog.pg_get_userbyid(t.typowner)
      FROM pg_catalog.pg_type t
      JOIN pg_catalog.pg_namespace n ON n.oid = t.typnamespace
     WHERE n.nspname = $1
       AND t.typname = $2
$$;

alter function _get_type_owner(name, name) owner to romain;

