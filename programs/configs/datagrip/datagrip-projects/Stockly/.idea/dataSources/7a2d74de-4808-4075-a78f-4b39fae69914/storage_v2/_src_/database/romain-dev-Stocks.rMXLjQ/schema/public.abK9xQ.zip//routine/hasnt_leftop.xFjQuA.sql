create function hasnt_leftop(name, name, name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _op_exists(NULL, $1, $2, $3), $4 );
$$;

alter function hasnt_leftop(name, name, name, text) owner to romain;

