create function isnt_window(name, text) returns text
    language sql
as
$$
    SELECT _func_compare(NULL, $1, NOT _type_func('w', $1), $2 );
$$;

alter function isnt_window(name, text) owner to romain;

