create function purchases__is_in_incoherent_refund_state(arg_purchase_id integer, arg_pcs_cancellation_id integer, arg_pcs_cancellation_decision_id integer, arg_pcs_refund_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
	RETURN (SELECT EXISTS (
		SELECT
				*
			FROM
				"purchases" p
			LEFT JOIN "purchase_cancellations" pc ON pc.id = p.cancellation_id
			LEFT JOIN "purchase_cancellation_decisions" pcd ON pcd.id = pc.decision_id
			INNER JOIN "purchase_refunds" pr ON p.id = pr.purchase_id
		WHERE
			(p.id = arg_purchase_id OR arg_purchase_id IS NULL)
			AND (pc.id = arg_pcs_cancellation_id OR arg_pcs_cancellation_id IS NULL)
			AND (pcd.id = arg_pcs_cancellation_decision_id OR arg_pcs_cancellation_decision_id IS NULL)
			AND (pr.id = arg_pcs_refund_id OR arg_pcs_refund_id IS NULL)
			AND pr.flagged_as_erroneous_at IS NULL
			AND NOT (
				p.purchases_shipping_id IS NOT NULL -- Submitted
				AND NOT ( -- If the reason for the refund is cancellation, make sure there is indeed a cancellation
					pr.reason = 'cancellation'
					AND (
						pc.id IS NULL -- No cancellation
						OR NOT ( -- Cancellation is not accepted
							pc.supplier_reason IS NOT NULL
							OR (pcd.id IS NOT NULL AND pcd.refused_reason IS NULL)
						)
					)
				)
			)
	));
END;
$$;

alter function purchases__is_in_incoherent_refund_state(integer, integer, integer, integer) owner to romain;

