create function columns_are(name, name[]) returns text
    language sql
as
$$
    SELECT columns_are( $1, $2, 'Table ' || quote_ident($1) || ' should have the correct columns' );
$$;

alter function columns_are(name, name[]) owner to romain;

