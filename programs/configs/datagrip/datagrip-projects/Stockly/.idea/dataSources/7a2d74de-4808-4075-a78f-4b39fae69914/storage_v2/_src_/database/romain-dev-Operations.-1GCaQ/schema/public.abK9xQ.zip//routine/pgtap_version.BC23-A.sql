create function pgtap_version() returns numeric
    immutable
    language sql
as
$$SELECT 1.3;$$;

alter function pgtap_version() owner to romain;

