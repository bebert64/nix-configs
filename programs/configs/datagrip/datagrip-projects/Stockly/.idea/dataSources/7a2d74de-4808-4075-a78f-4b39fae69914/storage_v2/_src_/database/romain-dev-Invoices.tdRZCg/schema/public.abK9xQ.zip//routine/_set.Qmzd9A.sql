create function _set(integer, integer) returns integer
    language plpgsql
as
$$
BEGIN
    EXECUTE 'UPDATE __tcache__ SET value = ' || $2
        || ' WHERE id = ' || $1;
    RETURN $2;
END;
$$;

alter function _set(integer, integer) owner to romain;

