create function is_ancestor_of(name, name, name, name, text) returns text
    language sql
as
$$
    SELECT ok( _ancestor_of( $1, $2, $3, $4, NULL ), $5 );
$$;

alter function is_ancestor_of(name, name, name, name, text) owner to romain;

