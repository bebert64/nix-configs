create function partitions_are(name, name[], text) returns text
    language sql
as
$$
    SELECT _are(
        'partitions',
        ARRAY(SELECT _parts($1) EXCEPT SELECT unnest($2)),
        ARRAY(SELECT unnest($2) EXCEPT SELECT _parts($1)),
        $3
    );
$$;

alter function partitions_are(name, name[], text) owner to romain;

