create function domains_are(name[], text) returns text
    language sql
as
$$
    SELECT _types_are( $1, $2, ARRAY['d'] );
$$;

alter function domains_are(name[], text) owner to romain;

