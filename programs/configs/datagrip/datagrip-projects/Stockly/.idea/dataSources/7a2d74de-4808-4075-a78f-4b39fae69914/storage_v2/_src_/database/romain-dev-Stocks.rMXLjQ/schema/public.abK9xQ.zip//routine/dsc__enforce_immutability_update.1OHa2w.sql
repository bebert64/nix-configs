create function dsc__enforce_immutability_update() returns trigger
    language plpgsql
as
$$
BEGIN
	OLD.deactivated_reason = NEW.deactivated_reason;
	OLD.updated_at = NEW.updated_at;
	OLD.retailer_specific_name = NEW.retailer_specific_name;
	IF (NEW IS NOT DISTINCT FROM OLD) THEN
		RETURN NEW;
	ELSE
		RAISE EXCEPTION 'Cannot update demander_shipping_contract.id = % since it may appear in the table invalidated_answer_demander_shipping_contracts. Consider deactivating, and creating a new one.', OLD.id;
	END IF;
END;
$$;

alter function dsc__enforce_immutability_update() owner to romain;

