create function hasnt_materialized_view(name, name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _rexists( 'm', $1, $2 ), $3 );
$$;

alter function hasnt_materialized_view(name, name, text) owner to romain;

