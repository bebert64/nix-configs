create function has_rule(name, name, name, text) returns text
    language sql
as
$$
    SELECT ok( _is_instead($1, $2, $3) IS NOT NULL, $4 );
$$;

alter function has_rule(name, name, name, text) owner to romain;

