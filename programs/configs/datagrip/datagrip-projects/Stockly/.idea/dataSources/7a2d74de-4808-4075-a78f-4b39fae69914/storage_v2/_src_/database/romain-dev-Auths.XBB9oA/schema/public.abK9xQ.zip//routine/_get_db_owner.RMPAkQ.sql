create function _get_db_owner(name) returns name
    language sql
as
$$
    SELECT pg_catalog.pg_get_userbyid(datdba)
      FROM pg_catalog.pg_database
     WHERE datname = $1;
$$;

alter function _get_db_owner(name) owner to romain;

