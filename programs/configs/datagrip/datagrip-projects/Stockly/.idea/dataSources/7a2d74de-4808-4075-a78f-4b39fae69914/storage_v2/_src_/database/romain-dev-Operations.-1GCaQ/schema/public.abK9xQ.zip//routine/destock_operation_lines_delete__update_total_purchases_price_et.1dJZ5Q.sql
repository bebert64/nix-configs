create function destock_operation_lines_delete__update_total_purchases_price_et() returns trigger
    language plpgsql
as
$$
BEGIN
	WITH removed_purchases_sum AS (
		SELECT
			dol.destock_operation_id,
			SUM(p.price_et) as total_removed_purchases_price_et
		FROM old_table dol
		INNER JOIN purchases p ON p.id = dol.purchase_id
		GROUP BY dol.destock_operation_id
	)
	UPDATE destock_operations
	SET total_purchases_price_et = destock_operations.total_purchases_price_et - rps.total_removed_purchases_price_et
	FROM removed_purchases_sum rps
	WHERE rps.destock_operation_id = destock_operations.id;

	RETURN NULL;
END;
$$;

alter function destock_operation_lines_delete__update_total_purchases_price_et() owner to romain;

