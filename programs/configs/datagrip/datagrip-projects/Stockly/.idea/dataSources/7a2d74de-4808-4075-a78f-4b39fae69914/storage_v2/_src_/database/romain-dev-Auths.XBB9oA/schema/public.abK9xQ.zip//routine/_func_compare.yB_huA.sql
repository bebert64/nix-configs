create function _func_compare(name, name, name[], boolean, text) returns text
    language sql
as
$$
    SELECT CASE WHEN $4 IS NULL
      THEN ok( FALSE, $5 ) || _nosuch($1, $2, $3)
      ELSE ok( $4, $5 )
      END;
$$;

alter function _func_compare(name, name, name[], boolean, text) owner to romain;

