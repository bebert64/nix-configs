create function hasnt_relation(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _relexists( $1 ), $2 );
$$;

alter function hasnt_relation(name, text) owner to romain;

