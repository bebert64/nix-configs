create function incoherent_acceptable_loss(arg_purchase_id integer, arg_ol_id integer, arg_olc_id integer, arg_olcd_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
	RETURN (
		SELECT
			EXISTS (
				SELECT
					*
				FROM
					"order_lines" ol
				LEFT JOIN "order_line_cancellations" olc ON ol.cancellation_id = olc.id
				LEFT JOIN "order_line_cancellation_decisions" olcd ON olcd.id = olc.decision_id
				INNER JOIN "purchases" p ON ol.purchase_id = p.id
			WHERE
				p.acceptable_loss_flag_id IS NOT NULL
				AND (p.purchases_shipping_id IS NULL
					OR ol.cancellation_id IS NULL
					OR olcd.refused_reason IS NOT NULL)
				AND (p.id = arg_purchase_id
					OR arg_purchase_id IS NULL)
				AND (ol.id = arg_ol_id OR arg_ol_id IS NULL)
				AND (olc.id = arg_olc_id OR arg_olc_id IS NULL)
				AND (olc.decision_id = arg_olcd_id
					OR arg_olcd_id IS NULL)));
END
$$;

alter function incoherent_acceptable_loss(integer, integer, integer, integer) owner to romain;

