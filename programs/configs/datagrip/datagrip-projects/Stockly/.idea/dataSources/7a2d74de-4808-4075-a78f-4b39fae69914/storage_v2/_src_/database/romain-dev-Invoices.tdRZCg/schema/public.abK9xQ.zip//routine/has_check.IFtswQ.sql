create function has_check(name, text) returns text
    language sql
as
$$
    SELECT ok( _hasc( $1, 'c' ), $2 );
$$;

alter function has_check(name, text) owner to romain;

