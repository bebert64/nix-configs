create function is_empty(text) returns text
    language sql
as
$$
    SELECT is_empty( $1, NULL );
$$;

alter function is_empty(text) owner to romain;

