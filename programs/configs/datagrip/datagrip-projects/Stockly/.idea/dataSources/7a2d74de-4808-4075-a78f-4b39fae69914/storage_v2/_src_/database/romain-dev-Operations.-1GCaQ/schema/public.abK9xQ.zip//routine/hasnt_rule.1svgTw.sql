create function hasnt_rule(name, name) returns text
    language sql
as
$$
    SELECT ok( _is_instead($1, $2) IS NULL, 'Relation ' || quote_ident($1) || ' should not have rule ' || quote_ident($2) );
$$;

alter function hasnt_rule(name, name) owner to romain;

