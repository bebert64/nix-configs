create function _partof(name, name, name, name) returns boolean
    language sql
as
$$
    SELECT EXISTS(
        SELECT true
          FROM pg_catalog.pg_namespace cn
          JOIN pg_catalog.pg_class cc ON cn.oid = cc.relnamespace
          JOIN pg_catalog.pg_inherits i ON cc.oid = i.inhrelid
          JOIN pg_catalog.pg_class pc ON i.inhparent = pc.oid
          JOIN pg_catalog.pg_namespace pn ON pc.relnamespace = pn.oid
         WHERE cn.nspname = $1
           AND cc.relname = $2
           AND cc.relispartition
           AND pn.nspname = $3
           AND pc.relname = $4
           AND pc.relkind = 'p'
    )
$$;

alter function _partof(name, name, name, name) owner to romain;

