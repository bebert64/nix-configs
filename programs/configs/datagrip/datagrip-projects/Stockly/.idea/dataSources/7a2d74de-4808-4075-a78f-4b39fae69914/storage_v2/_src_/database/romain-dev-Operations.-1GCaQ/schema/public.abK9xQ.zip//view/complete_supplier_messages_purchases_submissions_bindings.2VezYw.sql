create view complete_supplier_messages_purchases_submissions_bindings(supplier_message_id, purchases_submission_id, purchase_id) as
SELECT supplier_message_purchases_submissions_bindings.supplier_message_id,
       supplier_message_purchases_submissions_bindings.purchases_submission_id,
       NULL::integer AS purchase_id
FROM supplier_message_purchases_submissions_bindings
UNION
SELECT smpb.supplier_message_id,
       ps.submission_id AS purchases_submission_id,
       smpb.purchase_id
FROM supplier_message_purchases_bindings smpb
         JOIN purchases p ON p.id = smpb.purchase_id
         JOIN purchases_shippings ps ON ps.id = p.purchases_shipping_id;

alter table complete_supplier_messages_purchases_submissions_bindings
    owner to romain;

