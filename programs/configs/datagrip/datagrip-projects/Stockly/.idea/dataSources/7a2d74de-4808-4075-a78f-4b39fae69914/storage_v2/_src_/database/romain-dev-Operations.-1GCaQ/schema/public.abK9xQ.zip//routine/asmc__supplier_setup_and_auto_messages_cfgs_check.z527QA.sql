create function asmc__supplier_setup_and_auto_messages_cfgs_check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF incoherent_supplier_setup_and_automated_messages_cfgs(NULL, NEW.id) THEN
		RAISE 'Incoherent supplier configuration: at least one supplier using automated_supplier_config_id = % has auto_demand_for_delivery_dispute_documents set to true, but supply_delivery_dispute__open is not configured', NEW.id
		USING
			ERRCODE = 'check_violation',
			TABLE = 'automated_supplier_messages_configs';
	END IF;
	RETURN NULL;
END
$$;

alter function asmc__supplier_setup_and_auto_messages_cfgs_check() owner to romain;

