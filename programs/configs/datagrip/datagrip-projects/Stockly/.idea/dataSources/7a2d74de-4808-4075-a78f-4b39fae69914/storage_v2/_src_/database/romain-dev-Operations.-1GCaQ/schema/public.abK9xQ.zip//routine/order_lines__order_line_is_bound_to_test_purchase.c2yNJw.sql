create function order_lines__order_line_is_bound_to_test_purchase() returns trigger
    language plpgsql
as
$$
BEGIN
	IF NEW.purchase_id IS NOT NULL AND order_line_is_bound_to_test_purchase(NEW.id, NEW.purchase_id) THEN
		RAISE 'Order line %s should not be bound to test purchase %s', NEW.id, NEW.purchase_id
		USING ERRCODE = 'integrity_constraint_violation', CONSTRAINT = 'order_line_is_bound_to_test_purchase', TABLE = 'order_lines';
	END IF;
		RETURN NULL;
END
$$;

alter function order_lines__order_line_is_bound_to_test_purchase() owner to romain;

