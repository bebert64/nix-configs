create function pcs_cancellation_decisions__no_dd_check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (exists_open_pcs_cancellation_and_delivery_dispute(NEW.id, NULL, NULL, NULL, NULL, NULL)) THEN
		RAISE EXCEPTION 'pcs_cancellation_decisions__no_dd_check FAILED';
	END IF;
	RETURN NULL;
END
$$;

alter function pcs_cancellation_decisions__no_dd_check() owner to romain;

