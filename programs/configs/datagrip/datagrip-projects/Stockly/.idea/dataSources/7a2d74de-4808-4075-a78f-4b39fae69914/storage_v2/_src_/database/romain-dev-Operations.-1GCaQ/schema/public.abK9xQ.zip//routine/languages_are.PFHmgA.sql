create function languages_are(name[]) returns text
    language sql
as
$$
    SELECT languages_are( $1, 'There should be the correct procedural languages' );
$$;

alter function languages_are(name[]) owner to romain;

