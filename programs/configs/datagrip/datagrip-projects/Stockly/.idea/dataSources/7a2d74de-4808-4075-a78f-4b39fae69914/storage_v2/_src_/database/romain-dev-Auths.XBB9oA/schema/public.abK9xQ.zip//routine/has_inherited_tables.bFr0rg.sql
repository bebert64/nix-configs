create function has_inherited_tables(name, text) returns text
    language sql
as
$$
    SELECT ok( _inherited( $1 ), $2 );
$$;

alter function has_inherited_tables(name, text) owner to romain;

