create function incoherent_stocks_item_id_in_matching_checks__matching_checks() returns trigger
    language plpgsql
as
$$
BEGIN
	IF incoherent_stocks_item_id_in_matching_checks(NEW.id, NULL, NULL) THEN
		RAISE 'Incoherent stocks_item_id, either on demander_stocks_item_id or supplier_stocks_item_id'
		USING ERRCODE = 'check_violation', CONSTRAINT = 'matching_checks__incoherent_stocks_item_id', TABLE = 'matching_checks';
	END IF;
		RETURN NULL;
END
$$;

alter function incoherent_stocks_item_id_in_matching_checks__matching_checks() owner to romain;

