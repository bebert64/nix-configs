create function _returns(name, name) returns text
    language sql
as
$$
    SELECT returns FROM tap_funky WHERE schema = $1 AND name = $2
$$;

alter function _returns(name, name) owner to romain;

