create function isnt_procedure(name) returns text
    language sql
as
$$
    SELECT _func_compare(
        NULL, $1, NOT _type_func('p', $1),
        'Function ' || quote_ident($1) || '() should not be a procedure'
    );
$$;

alter function isnt_procedure(name) owner to romain;

