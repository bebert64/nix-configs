create function col_is_unique(name, name, name) returns text
    language sql
as
$$
    SELECT col_is_unique( $1, $2, ARRAY[$3], 'Column ' || quote_ident($2) || '(' || quote_ident($3) || ') should have a unique constraint' );
$$;

alter function col_is_unique(name, name, name) owner to rdsadmin;

