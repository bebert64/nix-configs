create function programmatic_entities__policy_designation_conflicts_with_spe() returns trigger
    language plpgsql
as
$$
BEGIN
	IF policies__designatn_conflicts_with_stockly_programmatic_entity(NULL, OLD.entity_id) THEN
		RAISE 'Policy designation created by this entity (%) conflicts with stockly programmatic entity domain', OLD.entity_id
		USING ERRCODE = 'unique_violation', CONSTRAINT = 'programmatic_entities__policy_designation_conflicts_with_spe', TABLE = 'policies';
	END IF;
		RETURN NULL;
END
$$;

alter function programmatic_entities__policy_designation_conflicts_with_spe() owner to master;

