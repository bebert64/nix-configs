create function policy_sub_policies__check_no_cycle() returns trigger
    language plpgsql
as
$$
BEGIN
	IF EXISTS (
		WITH RECURSIVE sub_policies_rec AS (
				SELECT sub.policy_id
				FROM policy_sub_policies AS sub
				WHERE sub.sub_policy_id = NEW.policy_id
			UNION ALL
				SELECT sub.policy_id
				FROM policy_sub_policies AS sub, sub_policies_rec as sub_rec
				WHERE sub.sub_policy_id = sub_rec.policy_id
		) CYCLE policy_id SET is_cycle USING cycle_path
		SELECT * FROM sub_policies_rec WHERE is_cycle = true
	)
	THEN
		RAISE EXCEPTION 'policy_sub_policies cycle detected';
	ELSE
		RETURN NEW;
	END IF;
END
$$;

alter function policy_sub_policies__check_no_cycle() owner to master;

