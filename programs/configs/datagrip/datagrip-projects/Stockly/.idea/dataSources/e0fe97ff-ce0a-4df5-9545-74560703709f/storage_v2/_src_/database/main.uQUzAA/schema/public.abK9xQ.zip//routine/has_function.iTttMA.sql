create function has_function(name, name, name[]) returns text
    language sql
as
$$
    SELECT ok(
        _got_func($1, $2, $3),
        'Function ' || quote_ident($1) || '.' || quote_ident($2) || '(' ||
        array_to_string($3, ', ') || ') should exist'
    );
$$;

alter function has_function(name, name, name[]) owner to rdsadmin;

