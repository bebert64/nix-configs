create function _cmp_types(oid, name) returns boolean
    language sql
as
$$
    SELECT pg_catalog.format_type($1, NULL) = _typename($2);
$$;

alter function _cmp_types(oid, name) owner to rdsadmin;

