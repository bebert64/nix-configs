create function enum_has_labels(name, name, name[]) returns text
    language sql
as
$$
    SELECT enum_has_labels(
        $1, $2, $3,
        'Enum ' || quote_ident($1) || '.' || quote_ident($2) || ' should have labels (' || array_to_string( $3, ', ' ) || ')'
    );
$$;

alter function enum_has_labels(name, name, name[]) owner to rdsadmin;

