create function has_relation(name, text) returns text
    language sql
as
$$
    SELECT ok( _relexists( $1 ), $2 );
$$;

alter function has_relation(name, text) owner to rdsadmin;

