create function policies__designation_conflicts_with_spe() returns trigger
    language plpgsql
as
$$
BEGIN
	IF policies__designatn_conflicts_with_stockly_programmatic_entity(NEW.id, NULL) THEN
		RAISE 'Policy designation (%) conflicts with stockly programmatic entity domain', NEW.designation
		USING ERRCODE = 'unique_violation', CONSTRAINT = 'policies__designation_conflicts_with_spe', TABLE = 'policies';
	END IF;
		RETURN NULL;
END
$$;

alter function policies__designation_conflicts_with_spe() owner to master;

