create function throws_ok(text, integer, text) returns text
    language sql
as
$$
    SELECT throws_ok( $1, $2::char(5), $3, NULL );
$$;

alter function throws_ok(text, integer, text) owner to rdsadmin;

