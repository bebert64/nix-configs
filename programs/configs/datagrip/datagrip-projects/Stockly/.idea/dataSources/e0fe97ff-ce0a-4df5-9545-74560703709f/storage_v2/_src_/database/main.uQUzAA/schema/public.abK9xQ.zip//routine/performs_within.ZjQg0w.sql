create function performs_within(text, numeric, numeric) returns text
    language sql
as
$$
SELECT performs_within(
          $1, $2, $3, 10,
          'Should run within ' || $2 || ' +/- ' || $3 || ' ms');
$$;

alter function performs_within(text, numeric, numeric) owner to rdsadmin;

