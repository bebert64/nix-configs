create function schemas_are(name[]) returns text
    language sql
as
$$
    SELECT schemas_are( $1, 'There should be the correct schemas' );
$$;

alter function schemas_are(name[]) owner to rdsadmin;

