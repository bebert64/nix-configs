create function has_view(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _rexists( 'v', $1, $2 ), $3 );
$$;

alter function has_view(name, name, text) owner to rdsadmin;

