create function alike(anyelement, text) returns text
    language sql
as
$$
    SELECT _alike( $1 ~~ $2, $1, $2, NULL );
$$;

alter function alike(anyelement, text) owner to rdsadmin;

