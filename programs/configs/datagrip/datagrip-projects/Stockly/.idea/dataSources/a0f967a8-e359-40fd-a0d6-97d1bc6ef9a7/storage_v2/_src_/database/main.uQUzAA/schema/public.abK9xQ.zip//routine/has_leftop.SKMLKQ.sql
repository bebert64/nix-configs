create function has_leftop(name, name) returns text
    language sql
as
$$
    SELECT ok(
         _op_exists(NULL, $1, $2 ),
        'Left operator ' || $1 || '(NONE,' || $2 || ') should exist'
    );
$$;

alter function has_leftop(name, name) owner to rdsadmin;

