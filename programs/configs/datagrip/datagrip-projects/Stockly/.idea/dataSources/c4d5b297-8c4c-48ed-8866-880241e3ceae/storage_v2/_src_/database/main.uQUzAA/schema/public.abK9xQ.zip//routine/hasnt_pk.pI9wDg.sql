create function hasnt_pk(name) returns text
    language sql
as
$$
    SELECT hasnt_pk( $1, 'Table ' || quote_ident($1) || ' should not have a primary key' );
$$;

alter function hasnt_pk(name) owner to rdsadmin;

