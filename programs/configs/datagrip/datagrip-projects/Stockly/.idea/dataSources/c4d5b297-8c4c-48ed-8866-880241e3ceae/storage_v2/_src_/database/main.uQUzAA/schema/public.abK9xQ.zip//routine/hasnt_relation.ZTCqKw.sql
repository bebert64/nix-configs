create function hasnt_relation(name) returns text
    language sql
as
$$
    SELECT hasnt_relation( $1, 'Relation ' || quote_ident($1) || ' should not exist' );
$$;

alter function hasnt_relation(name) owner to rdsadmin;

