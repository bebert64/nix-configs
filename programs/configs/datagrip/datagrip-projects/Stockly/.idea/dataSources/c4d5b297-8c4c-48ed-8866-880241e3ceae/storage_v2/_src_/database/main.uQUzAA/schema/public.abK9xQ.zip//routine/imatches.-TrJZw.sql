create function imatches(anyelement, text, text) returns text
    language sql
as
$$
    SELECT _alike( $1 ~* $2, $1, $2, $3 );
$$;

alter function imatches(anyelement, text, text) owner to rdsadmin;

