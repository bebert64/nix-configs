create function hasnt_table(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _rexists( '{r,p}'::char[], $1 ), $2 );
$$;

alter function hasnt_table(name, text) owner to rdsadmin;

