create function hasnt_function(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _got_func($1), $2 );
$$;

alter function hasnt_function(name, text) owner to rdsadmin;

