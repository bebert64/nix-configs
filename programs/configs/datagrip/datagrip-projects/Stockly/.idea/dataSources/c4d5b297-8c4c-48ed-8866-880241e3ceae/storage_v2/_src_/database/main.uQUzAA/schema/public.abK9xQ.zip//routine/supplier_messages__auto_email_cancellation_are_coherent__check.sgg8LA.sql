create function supplier_messages__auto_email_cancellation_are_coherent__check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (exists_incoherent_supplier_auto_email_cancellation_config(NULL, NEW.id)) THEN
		RAISE EXCEPTION SQLSTATE '23514' USING
			CONSTRAINT = 'auto_email_cancellation_are_coherent',
			TABLE = 'automated_supplier_messages_configs',
			MESSAGE = 'supplier_messages__auto_email_cancellation_are_coherent__check FAILED';
	END IF;
	RETURN NULL;
END
$$;

alter function supplier_messages__auto_email_cancellation_are_coherent__check() owner to master;

