create function doesnt_match(anyelement, text, text) returns text
    language sql
as
$$
    SELECT _unalike( $1 !~ $2, $1, $2, $3 );
$$;

alter function doesnt_match(anyelement, text, text) owner to rdsadmin;

