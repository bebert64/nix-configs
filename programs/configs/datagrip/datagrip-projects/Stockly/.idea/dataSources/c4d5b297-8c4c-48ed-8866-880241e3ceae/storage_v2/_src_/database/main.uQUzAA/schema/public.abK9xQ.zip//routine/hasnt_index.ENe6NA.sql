create function hasnt_index(name, name, name, text) returns text
    language plpgsql
as
$$
BEGIN
    RETURN ok( NOT _have_index( $1, $2, $3 ), $4 );
END;
$$;

alter function hasnt_index(name, name, name, text) owner to rdsadmin;

