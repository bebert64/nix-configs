create function has_domain(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _has_type( $1, $2, ARRAY['d'] ), $3 );
$$;

alter function has_domain(name, name, text) owner to rdsadmin;

