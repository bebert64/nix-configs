create function order_owners__order_owner_represents_demander__check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NOT demand__order_owner_represents_demander__check(NEW.demander_person_id, NULL, NULL, NULL)) THEN
		RAISE EXCEPTION 'order_owners__order_owner_represents_demander__check FAILED';
	END IF;
	RETURN NULL;
END
$$;

alter function order_owners__order_owner_represents_demander__check() owner to master;

