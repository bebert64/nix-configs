create function purchases_to_cancel(for_which_panel text)
    returns TABLE(title text, demanderusername text, consumer text, addtime timestamp with time zone)
    language plpgsql
as
$$
    -- DECLARE specific_cancellation_retailer_ids integer;
    BEGIN
        -- specific_cancellation_retailer_ids := (684,710,890,1057);
        RETURN QUERY (SELECT
            FORMAT('%s(%s) %s', r_sup.username, s.retailer_id, pcs.id)::TEXT,
            r_dmd.username::TEXT,
            person_consumer.display_name::TEXT,
            pcs.created_at
        FROM
                        purchases pcs
            INNER JOIN  suppliers s                             ON pcs.supplier_id = s.retailer_id
            INNER JOIN  retailers r_sup                         ON r_sup.id = s.retailer_id
            INNER JOIN  order_lines ol                          ON ol.purchase_id = pcs.id
            INNER JOIN  order_shippings o_s                     ON o_s.id = ol.order_shipping_id
            INNER JOIN  orders o                                ON o.id = o_s.order_id
            INNER JOIN  demander_persons person_consumer        ON o.consumer_id = person_consumer.id
            INNER JOIN  demander_persons person_owner           ON o.owner_id = person_owner.id
            INNER JOIN  retailers r_dmd                         ON person_owner.demander_id = r_dmd.id
            INNER JOIN  order_line_cancellations ol_c           ON ol.cancellation_id = ol_c.id
            LEFT  JOIN  demand_delivery_disputes d_dd           ON d_dd.order_id = o_s.order_id

            LEFT  JOIN  parcel_items pi                         ON pi.purchase_id = pcs.id
            LEFT  JOIN  parcels p                               ON p.id = pi.parcel_id
            LEFT  JOIN  supply_delivery_disputes s_dd           ON s_dd.parcel_id = p.id
            LEFT  JOIN  supply_delivery_dispute_outcomes s_dd_o ON s_dd_o.id = s_dd.outcome_id
        WHERE
                ol_c.decision_id IS NULL
            AND (CASE WHEN for_which_panel = 'specific' THEN s.retailer_id IN (684,710,890,1057) ELSE s.retailer_id NOT IN (684,710,890,1057) END)
            AND (for_which_panel = 'specific' OR s.manual_stockly_cancellation_method = 'retailer_specific_backoffice')
            AND pcs.purchases_shipping_id IS NOT NULL
            AND pcs.cancellation_id IS NULL
            AND (pi.internal_description IS NULL OR pi.internal_description = 'SUPPLIER_INITIAL_ON_SUBMISSION')
            AND (d_dd.order_id IS NULL OR d_dd.closed_at IS NOT NULL)
            AND (s_dd.id IS NULL OR (s_dd_o.id IS NOT NULL AND s_dd_o.outcome = 'aborted'))
        ORDER BY
            pcs.id ASC);
    END;
$$;

alter function purchases_to_cancel(text) owner to rw;

