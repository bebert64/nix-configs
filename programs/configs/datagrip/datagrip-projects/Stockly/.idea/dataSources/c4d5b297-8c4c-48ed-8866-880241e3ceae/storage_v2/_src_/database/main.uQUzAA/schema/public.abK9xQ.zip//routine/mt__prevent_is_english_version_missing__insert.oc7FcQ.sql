create function mt__prevent_is_english_version_missing__insert() returns trigger
    language plpgsql
as
$$
BEGIN
	IF is_english_version_missing(NEW.id) THEN
		RAISE EXCEPTION 'message_templates.id = % is missing an English version', NEW.id;
	END IF;
	RETURN NEW;
END;
$$;

alter function mt__prevent_is_english_version_missing__insert() owner to master;

