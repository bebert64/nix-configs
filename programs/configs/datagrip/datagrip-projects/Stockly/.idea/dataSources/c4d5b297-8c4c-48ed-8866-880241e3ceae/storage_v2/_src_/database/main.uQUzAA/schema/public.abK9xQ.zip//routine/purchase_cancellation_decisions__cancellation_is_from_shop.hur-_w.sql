create function purchase_cancellation_decisions__cancellation_is_from_shop(arg_purchase_cancellation_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT * FROM "purchase_cancellations" pc
		WHERE
			pc.id = arg_purchase_cancellation_id
			AND pc.from_shop = TRUE
	);

	RETURN ret_val;
END
$$;

alter function purchase_cancellation_decisions__cancellation_is_from_shop(integer) owner to master;

