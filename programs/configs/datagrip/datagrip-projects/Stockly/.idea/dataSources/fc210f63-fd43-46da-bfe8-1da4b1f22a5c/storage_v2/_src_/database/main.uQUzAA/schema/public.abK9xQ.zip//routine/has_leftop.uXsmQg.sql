create function has_leftop(name, name, name, name, text) returns text
    language sql
as
$$
    SELECT ok( _op_exists(NULL, $1, $2, $3, $4), $5 );
$$;

alter function has_leftop(name, name, name, name, text) owner to rdsadmin;

