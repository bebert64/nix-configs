create function label_access_tokens__is_coherent__check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (exists_incoherent_label_access_token(NEW.parcel_id, NEW.access_token)) THEN
		RAISE EXCEPTION 'label_access_tokens__is_coherent__check FAILED';
	END IF;
	RETURN NULL;
END
$$;

alter function label_access_tokens__is_coherent__check() owner to master;

