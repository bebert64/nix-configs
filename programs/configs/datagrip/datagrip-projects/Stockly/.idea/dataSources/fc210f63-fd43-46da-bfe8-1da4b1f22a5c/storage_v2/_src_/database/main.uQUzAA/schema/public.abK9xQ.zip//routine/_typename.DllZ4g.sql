create function _typename(name) returns text
    stable
    language plpgsql
as
$$
BEGIN RETURN $1::REGTYPE;
EXCEPTION WHEN undefined_object THEN RETURN $1;
END;
$$;

alter function _typename(name) owner to rdsadmin;

