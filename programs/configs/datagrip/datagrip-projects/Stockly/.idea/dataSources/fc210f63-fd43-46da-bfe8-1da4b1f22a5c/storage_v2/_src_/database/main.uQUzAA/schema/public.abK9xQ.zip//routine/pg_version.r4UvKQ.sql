create function pg_version() returns text
    immutable
    language sql
as
$$SELECT current_setting('server_version')$$;

alter function pg_version() owner to rdsadmin;

