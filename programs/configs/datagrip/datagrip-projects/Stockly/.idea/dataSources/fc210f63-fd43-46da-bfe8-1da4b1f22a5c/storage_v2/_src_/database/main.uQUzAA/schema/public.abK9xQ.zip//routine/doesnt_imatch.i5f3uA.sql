create function doesnt_imatch(anyelement, text, text) returns text
    language sql
as
$$
    SELECT _unalike( $1 !~* $2, $1, $2, $3 );
$$;

alter function doesnt_imatch(anyelement, text, text) owner to rdsadmin;

