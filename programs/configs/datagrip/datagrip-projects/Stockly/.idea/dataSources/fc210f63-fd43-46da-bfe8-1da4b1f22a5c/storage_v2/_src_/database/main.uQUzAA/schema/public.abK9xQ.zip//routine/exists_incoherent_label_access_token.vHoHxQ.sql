create function exists_incoherent_label_access_token(arg_parcel_id integer, arg_access_token character varying) returns boolean
    language plpgsql
as
$$
DECLARE
	ret_val BOOLEAN := FALSE;
BEGIN
	SELECT INTO ret_val EXISTS (
		SELECT
			*
		FROM
			"parcels" p
			INNER JOIN "label_access_tokens" lat
			ON p.id = lat.parcel_id
		WHERE
			p.has_label_on_aws = FALSE
			AND ("arg_parcel_id" IS NULL OR "arg_parcel_id" = p.id)
			AND ("arg_access_token" IS NULL OR "arg_access_token" = lat.access_token)
	);

	RETURN ret_val;
END
$$;

alter function exists_incoherent_label_access_token(integer, varchar) owner to master;

