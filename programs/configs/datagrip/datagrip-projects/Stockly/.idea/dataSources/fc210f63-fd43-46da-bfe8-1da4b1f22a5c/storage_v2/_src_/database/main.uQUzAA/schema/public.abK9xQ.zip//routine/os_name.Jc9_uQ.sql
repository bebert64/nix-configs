create function os_name() returns text
    immutable
    language sql
as
$$SELECT 'linux'::text;$$;

alter function os_name() owner to rdsadmin;

