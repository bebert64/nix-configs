create function hasnt_type(name) returns text
    language sql
as
$$
    SELECT ok( NOT _has_type( $1, NULL ), ('Type ' || quote_ident($1) || ' should not exist')::text );
$$;

alter function hasnt_type(name) owner to rdsadmin;

