create function _relexists(name) returns boolean
    language sql
as
$$
    SELECT EXISTS(
        SELECT true
          FROM pg_catalog.pg_class c
         WHERE pg_catalog.pg_table_is_visible(c.oid)
           AND c.relname = $1
    );
$$;

alter function _relexists(name) owner to rdsadmin;

