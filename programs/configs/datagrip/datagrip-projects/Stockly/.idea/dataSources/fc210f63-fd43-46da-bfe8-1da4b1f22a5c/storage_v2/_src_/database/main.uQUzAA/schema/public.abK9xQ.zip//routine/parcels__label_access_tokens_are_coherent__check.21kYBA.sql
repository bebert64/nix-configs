create function parcels__label_access_tokens_are_coherent__check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (exists_incoherent_label_access_token(NEW.id, NULL)) THEN
		RAISE EXCEPTION 'parcels__label_access_tokens_are_coherent__check FAILED';
	END IF;
	RETURN NULL;
END
$$;

alter function parcels__label_access_tokens_are_coherent__check() owner to master;

